import express from "express";
import path from "path";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "20mb" }));

// Server-side Gemini initialization helper
function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

// Health Check
app.get("/api/health", (_req, res) => {
  res.json({
    status: "ok",
    hasGeminiKey: Boolean(process.env.GEMINI_API_KEY),
    timestamp: new Date().toISOString(),
  });
});

// API: AI Diagnostic & Root Cause Assistant
app.post("/api/ai/diagnose", async (req, res) => {
  try {
    const { title, errorCode, equipmentId, domain, symptoms, imageBase64 } = req.body;
    const ai = getGeminiClient();

    if (!ai) {
      // Graceful fallback for offline / development without key
      return res.json({
        success: true,
        source: "fallback",
        analysis: {
          probableCause: `Hardware/Software discrepancy on ${equipmentId || "equipment"} (${domain || "General"}) related to error ${errorCode || "reported symptom"}.`,
          diagnosticSteps: [
            "Verify power rails and safety interlock state (LOTO if high voltage).",
            "Check communication wiring, harness connectors, and terminating resistors.",
            "Inspect physical sensors (LiDAR optical cover, proximity switch gap, or motor encoder).",
            "Clear diagnostic fault buffer and execute cold restart."
          ],
          safetyWarnings: [
            "Wear standard PPE (Level 2 Arc Flash / Safety Glasses).",
            "Verify mechanical zero and e-stop circuit prior to live testing."
          ],
          recommendedTools: ["Digital Multimeter (CAT III)", "Ethernet Cable Tester", "Torque Wrench", "Diagnostic Handheld Terminal"],
          confidenceScore: 88
        }
      });
    }

    const promptText = `You are a Senior Industrial Automation & Shop-Floor Lead Engineer specializing in Autonomous Mobile Robots (AMRs), Industrial Networking, Line Commissioning, and Electric Forklifts.

Analyze this shop floor issue:
- Title: ${title || "N/A"}
- Error Code: ${errorCode || "N/A"}
- Equipment ID / Model: ${equipmentId || "N/A"}
- Domain: ${domain || "Unknown"}
- Observed Symptoms: ${Array.isArray(symptoms) ? symptoms.join(", ") : symptoms || "N/A"}

Provide a direct, practical, shop-floor actionable diagnostic analysis in JSON format:
{
  "probableCause": "Concise technical root cause hypothesis",
  "diagnosticSteps": ["Step 1...", "Step 2...", "Step 3...", "Step 4..."],
  "safetyWarnings": ["Safety notice 1...", "Safety notice 2..."],
  "recommendedTools": ["Tool 1", "Tool 2", "Tool 3"],
  "confidenceScore": 92
}`;

    const parts: any[] = [];
    if (imageBase64 && imageBase64.includes("base64,")) {
      const split = imageBase64.split("base64,");
      const mimeMatch = imageBase64.match(/data:([a-zA-Z0-9]+\/[a-zA-Z0-9-.+]+);base64,/);
      const mimeType = mimeMatch ? mimeMatch[1] : "image/jpeg";
      parts.push({
        inlineData: {
          mimeType,
          data: split[1],
        },
      });
    }
    parts.push({ text: promptText });

    const response = await ai.models.generateContent({
      model: "gemini-3.7-flash",
      contents: { parts },
      config: {
        responseMimeType: "application/json",
      },
    });

    const rawText = response.text || "{}";
    const parsed = JSON.parse(rawText);

    res.json({
      success: true,
      source: "gemini",
      analysis: parsed,
    });
  } catch (error: any) {
    console.error("Diagnostic AI Error:", error);
    res.status(500).json({
      success: false,
      error: error.message || "Failed to generate diagnostic analysis",
    });
  }
});

// API: Smart Auto-Categorization & Tagging from Raw Notes or Symptoms
app.post("/api/ai/categorize", async (req, res) => {
  try {
    const { rawNote, equipmentHint } = req.body;
    const ai = getGeminiClient();

    if (!ai) {
      // Deterministic rule-based fallback
      const text = (rawNote + " " + equipmentHint).toLowerCase();
      let domain = "COMMISSIONING";
      if (text.includes("amr") || text.includes("mir") || text.includes("lidar") || text.includes("slam") || text.includes("fleet") || text.includes("robot")) {
        domain = "AMR";
      } else if (text.includes("switch") || text.includes("vlan") || text.includes("ip") || text.includes("wifi") || text.includes("ping") || text.includes("moxa") || text.includes("cisco") || text.includes("profinet")) {
        domain = "NETWORKING";
      } else if (text.includes("forklift") || text.includes("toyota") || text.includes("mast") || text.includes("curtis") || text.includes("hydraulic") || text.includes("crown") || text.includes("reach truck")) {
        domain = "FORKLIFT";
      }

      return res.json({
        success: true,
        source: "fallback",
        result: {
          domain,
          subsystem: "General Subsystem",
          suggestedTitle: rawNote.slice(0, 50) || "Floor Troubleshooting Report",
          extractedErrorCode: "N/A",
          tags: [domain.toLowerCase(), "shop-floor", "quick-fix"],
          severity: "MEDIUM_WARNING",
          estimatedMinutes: 20
        }
      });
    }

    const promptText = `You are an AI assistant for factory floor maintenance.
Analyze this quick note from a technician:
"""
${rawNote}
Equipment hint: ${equipmentHint || "N/A"}
"""

Categorize into one of 4 strict Domains: 'AMR', 'NETWORKING', 'COMMISSIONING', 'FORKLIFT'.
Extract the subsystem, structured title, any error code, relevant tags, severity ('CRITICAL_STOP' | 'HIGH_DEGRADED' | 'MEDIUM_WARNING' | 'LOW_MAINTENANCE'), and estimated fix time in minutes.

Return valid JSON:
{
  "domain": "AMR" | "NETWORKING" | "COMMISSIONING" | "FORKLIFT",
  "subsystem": "e.g. LiDAR Optical System, Hydraulic Tilt Valve, Moxa Industrial Switch",
  "suggestedTitle": "Crisp 5-8 word title",
  "extractedErrorCode": "e.g. ERR-E301 or N/A",
  "tags": ["tag1", "tag2", "tag3"],
  "severity": "CRITICAL_STOP" | "HIGH_DEGRADED" | "MEDIUM_WARNING" | "LOW_MAINTENANCE",
  "estimatedMinutes": 15
}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.7-flash",
      contents: promptText,
      config: {
        responseMimeType: "application/json",
      },
    });

    const parsed = JSON.parse(response.text || "{}");
    res.json({
      success: true,
      source: "gemini",
      result: parsed,
    });
  } catch (error: any) {
    console.error("Categorize AI Error:", error);
    res.status(500).json({
      success: false,
      error: error.message || "Failed to categorize notes",
    });
  }
});

// API: Format Quick Notes into Standard Shop Floor SOP / KB Entry
app.post("/api/ai/format-sop", async (req, res) => {
  try {
    const { rawText, domain, equipmentId } = req.body;
    const ai = getGeminiClient();

    if (!ai) {
      return res.json({
        success: true,
        source: "fallback",
        formatted: {
          title: "Quick Floor Resolution",
          rootCause: rawText,
          steps: [
            "Inspect physical assembly and connectors.",
            "Verify supply voltage and calibration offsets.",
            "Test operation in manual mode before resuming production."
          ],
          safetyNotice: "Observe standard LOTO lockouts before mechanical adjustment.",
          toolsRequired: ["Multimeter", "Hex Key Set", "Cleaning Isopropanol"]
        }
      });
    }

    const promptText = `Convert these rough field notes into a clean, structured Shop-Floor Standard Resolution (SOP) for technicians and Graduate Engineer Trainees (GETs).
Notes:
"""
${rawText}
Domain: ${domain || "General"}
Equipment: ${equipmentId || "Industrial Equipment"}
"""

Return valid JSON:
{
  "title": "Clean standard title",
  "rootCause": "Clear explanation of technical root cause",
  "steps": ["Step 1 with concise instruction", "Step 2...", "Step 3..."],
  "safetyNotice": "Key safety warning or LOTO requirement",
  "toolsRequired": ["Tool 1", "Tool 2"]
}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.7-flash",
      contents: promptText,
      config: {
        responseMimeType: "application/json",
      },
    });

    const parsed = JSON.parse(response.text || "{}");
    res.json({
      success: true,
      source: "gemini",
      formatted: parsed,
    });
  } catch (error: any) {
    console.error("Format SOP AI Error:", error);
    res.status(500).json({
      success: false,
      error: error.message || "Failed to format SOP",
    });
  }
});

// Vite middleware for dev / static for prod
async function setupViteOrStatic() {
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[ShopFloor Hub] Server running on http://0.0.0.0:${PORT}`);
  });
}

setupViteOrStatic().catch((err) => {
  console.error("Failed to start server:", err);
});
