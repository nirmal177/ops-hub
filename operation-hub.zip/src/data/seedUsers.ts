import { User, UserRole } from "../types";

export const ROLE_CONFIG: Record<
  UserRole,
  {
    label: string;
    badgeLabel: string;
    description: string;
    color: string;
    badgeBg: string;
    badgeBorder: string;
    permissions: {
      canVerifySolutions: boolean;
      canDeleteEntries: boolean;
      canManageUsers: boolean;
      canDeleteUsers: boolean;
      canExportData: boolean;
      canEditSafetyLOTO: boolean;
      canPublishDirectly: boolean;
    };
  }
> = {
  GET_TRAINEE: {
    label: "Graduate Engineering Trainee",
    badgeLabel: "GET TRAINEE",
    description: "Trainee engineer executing standard SOPs, diagnostic practice quizzes, and drafting problem resolutions",
    color: "#fb923c",
    badgeBg: "bg-orange-950/60",
    badgeBorder: "border-orange-700",
    permissions: {
      canVerifySolutions: false,
      canDeleteEntries: false,
      canManageUsers: false,
      canDeleteUsers: false,
      canExportData: false,
      canEditSafetyLOTO: false,
      canPublishDirectly: false,
    },
  },
  ASSISTANT_MANAGER: {
    label: "Assistant Manager",
    badgeLabel: "ASST. MGR",
    description: "Operational support leadership, SOP peer review, maintenance oversight, and line shift coordination",
    color: "#60a5fa",
    badgeBg: "bg-blue-950/60",
    badgeBorder: "border-blue-700",
    permissions: {
      canVerifySolutions: true,
      canDeleteEntries: false,
      canManageUsers: false,
      canDeleteUsers: false,
      canExportData: true,
      canEditSafetyLOTO: true,
      canPublishDirectly: true,
    },
  },
  MANAGER: {
    label: "Manager",
    badgeLabel: "MANAGER",
    description: "Plant & operational line manager supervising shifts, approving safety LOTO overrides, and managing personnel records",
    color: "#c084fc",
    badgeBg: "bg-purple-950/60",
    badgeBorder: "border-purple-700",
    permissions: {
      canVerifySolutions: true,
      canDeleteEntries: true,
      canManageUsers: true,
      canDeleteUsers: false,
      canExportData: true,
      canEditSafetyLOTO: true,
      canPublishDirectly: true,
    },
  },
  ADMIN: {
    label: "Admin",
    badgeLabel: "ADMIN",
    description: "Full administrative access, user lifecycle management, employee decommissioning, audit reviews, and system exports",
    color: "#FACC15",
    badgeBg: "bg-yellow-950/60",
    badgeBorder: "border-yellow-700",
    permissions: {
      canVerifySolutions: true,
      canDeleteEntries: true,
      canManageUsers: true,
      canDeleteUsers: true,
      canExportData: true,
      canEditSafetyLOTO: true,
      canPublishDirectly: true,
    },
  },
  MAINTENANCE_ENGINEER: {
    label: "Maintenance Engineer",
    badgeLabel: "MAINT. ENG",
    description: "Specialist engineer responsible for equipment triage, sensor diagnostics, and direct hardware resolution publishing",
    color: "#4ade80",
    badgeBg: "bg-emerald-950/60",
    badgeBorder: "border-emerald-700",
    permissions: {
      canVerifySolutions: true,
      canDeleteEntries: false,
      canManageUsers: false,
      canDeleteUsers: false,
      canExportData: true,
      canEditSafetyLOTO: true,
      canPublishDirectly: true,
    },
  },
  NONE: {
    label: "None / Unassigned",
    badgeLabel: "NONE",
    description: "General profile with standard field viewing access",
    color: "#94a3b8",
    badgeBg: "bg-slate-800/80",
    badgeBorder: "border-slate-700",
    permissions: {
      canVerifySolutions: false,
      canDeleteEntries: false,
      canManageUsers: false,
      canDeleteUsers: false,
      canExportData: false,
      canEditSafetyLOTO: false,
      canPublishDirectly: false,
    },
  },
};

export const INITIAL_USERS: User[] = [
  {
    id: "usr-admin-01",
    name: "Dave Sterling",
    username: "admin",
    password: "password123",
    email: "d.sterling@plantops.internal",
    badgeId: "ADM-001",
    role: "ADMIN",
    status: "ACTIVE",
    facility: "GIGA-FACTORY-01",
    line: "Line 4 (AMR & Logistics)",
    specialties: ["AMR", "NETWORKING", "COMMISSIONING", "FORKLIFT"],
    phone: "+1 (555) 019-2831",
    avatarColor: "#FACC15",
    createdAt: "2025-11-01T08:00:00.000Z",
    lastActive: "Just now",
    stats: {
      solutionsLogged: 24,
      verificationsPerformed: 48,
      helpfulVotesReceived: 112,
      quizScorePercent: 98,
    },
  },
  {
    id: "usr-mgr-02",
    name: "Elena Rostova",
    username: "elena",
    password: "password123",
    email: "e.rostova@plantops.internal",
    badgeId: "MGR-104",
    role: "MANAGER",
    status: "ACTIVE",
    facility: "GIGA-FACTORY-01",
    line: "Line 2 (Battery Pack Assembly)",
    specialties: ["COMMISSIONING", "NETWORKING"],
    phone: "+1 (555) 019-3329",
    avatarColor: "#c084fc",
    createdAt: "2025-12-10T08:00:00.000Z",
    lastActive: "12m ago",
    stats: {
      solutionsLogged: 18,
      verificationsPerformed: 36,
      helpfulVotesReceived: 89,
      quizScorePercent: 95,
    },
  },
  {
    id: "usr-am-03",
    name: "Dr. Tariq Al-Mansoor",
    username: "tariq",
    password: "password123",
    email: "t.almansoor@plantops.internal",
    badgeId: "AM-088",
    role: "ASSISTANT_MANAGER",
    status: "ACTIVE",
    facility: "GIGA-FACTORY-01",
    line: "Line 1 (Body & Chassis)",
    specialties: ["COMMISSIONING", "AMR"],
    phone: "+1 (555) 019-7412",
    avatarColor: "#60a5fa",
    createdAt: "2026-01-05T08:00:00.000Z",
    lastActive: "25m ago",
    stats: {
      solutionsLogged: 14,
      verificationsPerformed: 19,
      helpfulVotesReceived: 67,
      quizScorePercent: 100,
    },
  },
  {
    id: "usr-me-04",
    name: "Marcus Chen",
    username: "marcus",
    password: "password123",
    email: "m.chen@plantops.internal",
    badgeId: "ME-209",
    role: "MAINTENANCE_ENGINEER",
    status: "ACTIVE",
    facility: "GIGA-FACTORY-01",
    line: "Line 4 (AMR & Logistics)",
    specialties: ["AMR", "FORKLIFT"],
    phone: "+1 (555) 019-9941",
    avatarColor: "#4ade80",
    createdAt: "2026-01-20T08:00:00.000Z",
    lastActive: "5m ago",
    stats: {
      solutionsLogged: 31,
      verificationsPerformed: 12,
      helpfulVotesReceived: 145,
      quizScorePercent: 92,
    },
  },
  {
    id: "usr-get-05",
    name: "Alex Vance",
    username: "alex",
    password: "password123",
    email: "a.vance@plantops.internal",
    badgeId: "GET-512",
    role: "GET_TRAINEE",
    status: "ACTIVE",
    facility: "GIGA-FACTORY-01",
    line: "Line 4 (AMR & Logistics)",
    specialties: ["AMR", "NETWORKING"],
    phone: "+1 (555) 019-4820",
    avatarColor: "#fb923c",
    createdAt: "2026-06-15T08:00:00.000Z",
    lastActive: "Active Now",
    stats: {
      solutionsLogged: 6,
      verificationsPerformed: 0,
      helpfulVotesReceived: 28,
      quizScorePercent: 88,
    },
  },
  {
    id: "usr-me-06",
    name: "Kenji Sato",
    username: "kenji",
    password: "password123",
    email: "k.sato@plantops.internal",
    badgeId: "ME-341",
    role: "MAINTENANCE_ENGINEER",
    status: "ON_LEAVE",
    facility: "GIGA-FACTORY-02",
    line: "Line 1 (Powertrain Assembly)",
    specialties: ["COMMISSIONING", "NETWORKING"],
    phone: "+1 (555) 019-6638",
    avatarColor: "#4ade80",
    createdAt: "2026-02-14T08:00:00.000Z",
    lastActive: "3 days ago",
    stats: {
      solutionsLogged: 19,
      verificationsPerformed: 2,
      helpfulVotesReceived: 73,
      quizScorePercent: 90,
    },
  },
];

export const AVAILABLE_FACILITIES = [
  "GIGA-FACTORY-01",
  "GIGA-FACTORY-02",
  "PILOT-PLANT-EAST",
  "LOGISTICS-HUB-SOUTH",
];

export const AVAILABLE_LINES = [
  "Line 1 (Powertrain Assembly)",
  "Line 2 (Battery Pack Integration)",
  "Line 3 (Final Quality & Shipping)",
  "Line 4 (AMR & Logistics)",
  "Line 5 (Chassis & Welding)",
  "Autonomous Yard",
];

export const AVAILABLE_DEPARTMENTS = [
  "Field Engineering & Maintenance",
  "Robotics & AMR Fleet Operations",
  "Industrial Automation & Controls",
  "Quality Assurance & Commissioning",
  "Plant Safety & Environmental (EHS)",
];
