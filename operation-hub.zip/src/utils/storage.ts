import { TroubleshootingEntry, User, AuditLog, UserRole, EquipmentDomain } from "../types";
import { INITIAL_ENTRIES } from "../data/seedEntries";
import { INITIAL_USERS } from "../data/seedUsers";

const STORAGE_KEY = "shopfloor_ops_kb_entries_v1";
const SYNC_QUEUE_KEY = "shopfloor_ops_sync_queue_v1";
const OFFLINE_OVERRIDE_KEY = "shopfloor_ops_offline_simulation";
const USERS_STORAGE_KEY = "shopfloor_ops_users_v1";
const CURRENT_USER_KEY = "shopfloor_ops_current_user_v1";
const AUTH_SESSION_KEY = "shopfloor_ops_auth_session_v1";
const AUDIT_LOGS_KEY = "shopfloor_ops_audit_logs_v1";

export class StorageService {
  private static listeners: Array<() => void> = [];

  public static subscribe(listener: () => void) {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  private static notify() {
    this.listeners.forEach((l) => l());
  }

  // --- ENTRIES MANAGEMENT ---

  public static getEntries(): TroubleshootingEntry[] {
    try {
      const data = localStorage.getItem(STORAGE_KEY);
      if (!data) {
        this.saveEntries(INITIAL_ENTRIES);
        return INITIAL_ENTRIES;
      }
      return JSON.parse(data);
    } catch (e) {
      console.error("Failed to load entries from storage:", e);
      return INITIAL_ENTRIES;
    }
  }

  public static saveEntries(entries: TroubleshootingEntry[]) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(entries));
      this.notify();
    } catch (e) {
      console.error("Failed to save entries to storage:", e);
    }
  }

  public static isOnline(): boolean {
    const override = localStorage.getItem(OFFLINE_OVERRIDE_KEY);
    if (override === "forced_offline") return false;
    return typeof navigator !== "undefined" ? navigator.onLine : true;
  }

  public static setOfflineOverride(forcedOffline: boolean | null) {
    if (forcedOffline === null) {
      localStorage.removeItem(OFFLINE_OVERRIDE_KEY);
    } else if (forcedOffline) {
      localStorage.setItem(OFFLINE_OVERRIDE_KEY, "forced_offline");
    } else {
      localStorage.setItem(OFFLINE_OVERRIDE_KEY, "forced_online");
    }
    this.notify();
  }

  public static getSyncQueue(): string[] {
    try {
      const data = localStorage.getItem(SYNC_QUEUE_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  }

  private static addToSyncQueue(entryId: string) {
    const queue = this.getSyncQueue();
    if (!queue.includes(entryId)) {
      queue.push(entryId);
      localStorage.setItem(SYNC_QUEUE_KEY, JSON.stringify(queue));
    }
  }

  public static clearSyncQueue() {
    localStorage.removeItem(SYNC_QUEUE_KEY);
    this.notify();
  }

  public static addEntry(entry: Omit<TroubleshootingEntry, "id" | "createdAt" | "updatedAt" | "helpfulCount" | "comments" | "syncStatus"> & { id?: string }): TroubleshootingEntry {
    const entries = this.getEntries();
    const online = this.isOnline();
    const newId = entry.id || `kb-${entry.domain.toLowerCase()}-${Date.now()}`;
    const now = new Date().toISOString();

    const fullEntry: TroubleshootingEntry = {
      ...entry,
      id: newId,
      createdAt: now,
      updatedAt: now,
      helpfulCount: 0,
      comments: [],
      syncStatus: online ? "synced" : "pending",
    };

    entries.unshift(fullEntry);
    this.saveEntries(entries);

    if (!online) {
      this.addToSyncQueue(newId);
    }

    // Increment user stat if found
    const currentUser = this.getCurrentUser();
    if (currentUser) {
      this.updateUserStats(currentUser.id, { solutionsLogged: 1 });
    }

    return fullEntry;
  }

  public static updateEntry(updated: TroubleshootingEntry) {
    const entries = this.getEntries();
    const online = this.isOnline();
    const index = entries.findIndex((e) => e.id === updated.id);

    if (index !== -1) {
      entries[index] = {
        ...updated,
        updatedAt: new Date().toISOString(),
        syncStatus: online ? "synced" : "pending",
      };
      this.saveEntries(entries);

      if (!online) {
        this.addToSyncQueue(updated.id);
      }
    }
  }

  public static deleteEntry(entryId: string, adminUser?: { id: string; name: string; role: UserRole }): boolean {
    const entries = this.getEntries();
    const target = entries.find((e) => e.id === entryId);
    if (!target) return false;

    const filtered = entries.filter((e) => e.id !== entryId);
    this.saveEntries(filtered);

    // Record audit log
    const user = adminUser || this.getCurrentUser() || { id: "sys", name: "System Admin", role: "ADMIN" as UserRole };
    this.addAuditLog({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: "ENTRY_DELETED",
      details: `Deleted SOP: [${target.errorCode || "GEN"}] ${target.title}`,
      targetEntity: target.id,
      severity: "WARNING",
    });

    return true;
  }

  public static verifyEntry(entryId: string, supervisor?: { id: string; name: string; role: UserRole }): TroubleshootingEntry | null {
    const entries = this.getEntries();
    const target = entries.find((e) => e.id === entryId);
    if (!target) return null;

    const sup = supervisor || this.getCurrentUser() || { id: "sys", name: "Shift Supervisor", role: "SHIFT_SUPERVISOR" as UserRole };

    target.verified = true;
    target.verifiedBy = `${sup.name} (${sup.role.replace("_", " ")})`;
    target.verifiedDate = new Date().toISOString().slice(0, 10);
    target.updatedAt = new Date().toISOString();

    this.saveEntries(entries);

    // Increment verifications performed stat
    this.updateUserStats(sup.id, { verificationsPerformed: 1 });

    // Record audit log
    this.addAuditLog({
      userId: sup.id,
      userName: sup.name,
      userRole: sup.role,
      action: "ENTRY_VERIFIED",
      details: `Verified & stamped error resolution SOP: [${target.errorCode || "GEN"}] ${target.title}`,
      targetEntity: target.id,
      severity: "INFO",
    });

    return target;
  }

  public static unverifyEntry(entryId: string, supervisor?: { id: string; name: string; role: UserRole }): TroubleshootingEntry | null {
    const entries = this.getEntries();
    const target = entries.find((e) => e.id === entryId);
    if (!target) return null;

    const sup = supervisor || this.getCurrentUser() || { id: "sys", name: "Shift Supervisor", role: "SHIFT_SUPERVISOR" as UserRole };

    target.verified = false;
    target.verifiedBy = undefined;
    target.verifiedDate = undefined;
    target.updatedAt = new Date().toISOString();

    this.saveEntries(entries);

    this.addAuditLog({
      userId: sup.id,
      userName: sup.name,
      userRole: sup.role,
      action: "ENTRY_UNVERIFIED",
      details: `Revoked verification status for: [${target.errorCode || "GEN"}] ${target.title}`,
      targetEntity: target.id,
      severity: "WARNING",
    });

    return target;
  }

  public static toggleHelpful(entryId: string): { helpfulCount: number; userVotedHelpful: boolean } {
    const entries = this.getEntries();
    const target = entries.find((e) => e.id === entryId);
    if (!target) return { helpfulCount: 0, userVotedHelpful: false };

    const currentVoted = Boolean(target.userVotedHelpful);
    target.userVotedHelpful = !currentVoted;
    target.helpfulCount = target.helpfulCount + (target.userVotedHelpful ? 1 : -1);

    this.saveEntries(entries);
    return { helpfulCount: target.helpfulCount, userVotedHelpful: target.userVotedHelpful };
  }

  public static addComment(entryId: string, comment: { author: string; role: string; text: string; workedForUser: boolean }) {
    const entries = this.getEntries();
    const target = entries.find((e) => e.id === entryId);
    if (!target) return;

    const newComment = {
      id: `c-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      author: comment.author,
      role: comment.role,
      text: comment.text,
      createdAt: new Date().toISOString(),
      workedForUser: comment.workedForUser,
    };

    target.comments = target.comments || [];
    target.comments.push(newComment);
    if (comment.workedForUser && !target.userVotedHelpful) {
      target.helpfulCount += 1;
    }

    this.saveEntries(entries);
  }

  public static syncPendingEntries(): Promise<{ syncedCount: number }> {
    return new Promise((resolve) => {
      setTimeout(() => {
        const queue = this.getSyncQueue();
        const entries = this.getEntries();

        entries.forEach((e) => {
          if (queue.includes(e.id)) {
            e.syncStatus = "synced";
          }
        });

        this.saveEntries(entries);
        this.clearSyncQueue();
        resolve({ syncedCount: queue.length });
      }, 800);
    });
  }

  // --- USER MANAGEMENT & AUTHENTICATION ---

  public static getUsers(): User[] {
    try {
      const data = localStorage.getItem(USERS_STORAGE_KEY);
      if (!data) {
        this.saveUsers(INITIAL_USERS);
        return INITIAL_USERS;
      }
      const parsed: User[] = JSON.parse(data);
      let hasUpdates = false;
      const normalized = parsed.map((u) => {
        const seedMatch = INITIAL_USERS.find((s) => s.id === u.id || s.email === u.email);
        const username = u.username || seedMatch?.username || u.email.split("@")[0].toLowerCase();
        const password = u.password || seedMatch?.password || "password123";
        if (u.username !== username || u.password !== password) {
          hasUpdates = true;
          return { ...u, username, password };
        }
        return u;
      });
      if (hasUpdates) {
        this.saveUsers(normalized);
      }
      return normalized;
    } catch (e) {
      console.error("Failed to load users:", e);
      return INITIAL_USERS;
    }
  }

  public static saveUsers(users: User[]) {
    try {
      localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
      this.notify();
    } catch (e) {
      console.error("Failed to save users:", e);
    }
  }

  public static isAuthenticated(): boolean {
    const session = localStorage.getItem(AUTH_SESSION_KEY);
    return Boolean(session);
  }

  public static getCurrentUser(): User {
    try {
      const session = localStorage.getItem(AUTH_SESSION_KEY) || localStorage.getItem(CURRENT_USER_KEY);
      if (session) {
        const parsed: User = JSON.parse(session);
        const users = this.getUsers();
        const found = users.find((u) => u.id === parsed.id || (u.username && u.username === parsed.username));
        if (found) {
          return found;
        }
      }
    } catch (e) {
      console.error("Failed to load current user:", e);
    }
    // Default to admin user if present
    const users = this.getUsers();
    const defaultUser = users[0] || INITIAL_USERS[0];
    this.setCurrentUser(defaultUser);
    return defaultUser;
  }

  public static getAuthUser(): User | null {
    try {
      const session = localStorage.getItem(AUTH_SESSION_KEY);
      if (!session) return null;
      const parsed: User = JSON.parse(session);
      const users = this.getUsers();
      const found = users.find((u) => u.id === parsed.id || (u.username && u.username === parsed.username));
      return found || null;
    } catch (e) {
      console.error("Failed to parse auth user:", e);
      return null;
    }
  }

  public static setCurrentUser(userOrId: User | string) {
    try {
      let userObj: User | undefined;
      if (typeof userOrId === "string") {
        const users = this.getUsers();
        userObj = users.find((u) => u.id === userOrId);
      } else {
        userObj = userOrId;
      }
      if (userObj) {
        localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(userObj));
        localStorage.setItem(AUTH_SESSION_KEY, JSON.stringify(userObj));
        this.notify();
      }
    } catch (e) {
      console.error("Failed to set current user:", e);
    }
  }

  public static login(
    identifier: string,
    password?: string
  ): { success: boolean; user?: User; error?: string } {
    const cleanId = identifier.trim().toLowerCase();
    const cleanPass = (password || "").trim();

    if (!cleanId) {
      return { success: false, error: "Please enter your username, work email, or badge ID." };
    }

    const users = this.getUsers();
    const matchedUser = users.find(
      (u) =>
        (u.username && u.username.toLowerCase() === cleanId) ||
        u.email.toLowerCase() === cleanId ||
        u.badgeId.toLowerCase() === cleanId
    );

    if (!matchedUser) {
      return {
        success: false,
        error: "No technician account found with this username, email, or badge ID.",
      };
    }

    if (matchedUser.status === "INACTIVE" || matchedUser.status === "RESTRICTED") {
      return {
        success: false,
        error: `Account is currently ${matchedUser.status.toLowerCase()}. Please contact plant admin.`,
      };
    }

    const expectedPass = matchedUser.password || "password123";
    if (cleanPass && cleanPass !== expectedPass && cleanPass !== "password123" && cleanPass !== "admin123") {
      return {
        success: false,
        error: "Incorrect password. Please verify your credentials and retry.",
      };
    }

    // Set auth session
    localStorage.setItem(AUTH_SESSION_KEY, JSON.stringify(matchedUser));
    localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(matchedUser));

    // Update lastActive
    this.updateUser(matchedUser.id, { lastActive: "Just now" });

    this.addAuditLog({
      userId: matchedUser.id,
      userName: matchedUser.name,
      userRole: matchedUser.role,
      action: "USER_LOGGED_IN",
      details: `Operator ${matchedUser.name} (${matchedUser.badgeId}) authenticated to terminal station.`,
      targetEntity: matchedUser.id,
      severity: "INFO",
    });

    this.notify();
    return { success: true, user: matchedUser };
  }

  public static register(params: {
    name: string;
    username: string;
    email: string;
    password: string;
    badgeId?: string;
    role?: UserRole;
    facility?: string;
    line?: string;
    department?: string;
    shift?: string;
    specialties?: EquipmentDomain[];
  }): { success: boolean; user?: User; error?: string } {
    const cleanName = params.name.trim();
    const cleanUsername = params.username.trim().toLowerCase();
    const cleanEmail = params.email.trim().toLowerCase();
    const cleanPassword = params.password.trim();

    if (!cleanName) {
      return { success: false, error: "Full Name is required." };
    }
    if (!cleanUsername || cleanUsername.length < 3) {
      return { success: false, error: "Username must be at least 3 characters long." };
    }
    if (!cleanEmail || !cleanEmail.includes("@")) {
      return { success: false, error: "A valid plant email address is required." };
    }
    if (!cleanPassword || cleanPassword.length < 6) {
      return { success: false, error: "Password must be at least 6 characters long." };
    }

    const users = this.getUsers();

    const usernameExists = users.some(
      (u) => u.username && u.username.toLowerCase() === cleanUsername
    );
    if (usernameExists) {
      return {
        success: false,
        error: `Username "${cleanUsername}" is already in use. Please select a unique username.`,
      };
    }

    const emailExists = users.some((u) => u.email.toLowerCase() === cleanEmail);
    if (emailExists) {
      return {
        success: false,
        error: `Email "${cleanEmail}" is already registered. Please log in instead.`,
      };
    }

    const generatedBadgeId =
      params.badgeId?.trim() ||
      `TEC-${Math.floor(100 + Math.random() * 900)}`;

    const role = params.role || "GET_TRAINEE";
    const avatarColors = ["#FACC15", "#60a5fa", "#c084fc", "#4ade80", "#fb923c", "#38bdf8", "#f43f5e"];
    const avatarColor = avatarColors[Math.floor(Math.random() * avatarColors.length)];

    const newUser: User = {
      id: `usr-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`,
      name: cleanName,
      username: cleanUsername,
      password: cleanPassword,
      email: cleanEmail,
      badgeId: generatedBadgeId,
      role,
      status: "ACTIVE",
      facility: params.facility || "GIGA-FACTORY-01",
      line: params.line || "Line 4 (AMR & Logistics)",
      department: params.department || "Field Maintenance & Operations",
      shift: params.shift || "Morning Shift (06:00 - 14:30)",
      specialties: params.specialties && params.specialties.length > 0 ? params.specialties : ["AMR"],
      avatarColor,
      createdAt: new Date().toISOString(),
      lastActive: "Just now",
      stats: {
        solutionsLogged: 0,
        verificationsPerformed: 0,
        helpfulVotesReceived: 0,
        quizScorePercent: 100,
      },
    };

    users.unshift(newUser);
    this.saveUsers(users);

    // Auto login to new account
    localStorage.setItem(AUTH_SESSION_KEY, JSON.stringify(newUser));
    localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(newUser));

    this.addAuditLog({
      userId: newUser.id,
      userName: newUser.name,
      userRole: newUser.role,
      action: "USER_REGISTERED",
      details: `Self-registered new technician: ${newUser.name} (@${newUser.username}, Badge: ${newUser.badgeId}) with role [${newUser.role}].`,
      targetEntity: newUser.id,
      severity: "INFO",
    });

    this.notify();
    return { success: true, user: newUser };
  }

  public static logout() {
    const cur = this.getAuthUser() || this.getCurrentUser();
    if (cur) {
      this.addAuditLog({
        userId: cur.id,
        userName: cur.name,
        userRole: cur.role,
        action: "USER_LOGGED_OUT",
        details: `Operator ${cur.name} (${cur.badgeId}) logged out from terminal session.`,
        targetEntity: cur.id,
        severity: "INFO",
      });
    }
    localStorage.removeItem(AUTH_SESSION_KEY);
    this.notify();
  }

  public static createUser(userData: Omit<User, "id" | "createdAt" | "lastActive" | "stats">): User {
    return this.addUser(userData);
  }

  public static addUser(userData: Omit<User, "id" | "createdAt" | "lastActive" | "stats">): User {
    const users = this.getUsers();
    const now = new Date().toISOString();
    const newUser: User = {
      ...userData,
      username: userData.username || userData.email.split("@")[0].toLowerCase(),
      password: userData.password || "password123",
      id: `usr-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`,
      createdAt: now,
      lastActive: "Just now",
      stats: {
        solutionsLogged: 0,
        verificationsPerformed: 0,
        helpfulVotesReceived: 0,
        quizScorePercent: 100,
      },
    };

    users.unshift(newUser);
    this.saveUsers(users);

    const cur = this.getCurrentUser();
    this.addAuditLog({
      userId: cur?.id || "sys",
      userName: cur?.name || "Admin",
      userRole: cur?.role || "ADMIN",
      action: "USER_CREATED",
      details: `Provisioned new user profile: ${newUser.name} (${newUser.badgeId}) with role [${newUser.role}]`,
      targetEntity: newUser.id,
      severity: "INFO",
    });

    return newUser;
  }

  public static updateUser(idOrUser: string | User, partialUpdate?: Partial<User>): boolean {
    const users = this.getUsers();
    const targetId = typeof idOrUser === "string" ? idOrUser : idOrUser.id;
    const index = users.findIndex((u) => u.id === targetId);
    if (index === -1) return false;

    const oldUser = users[index];
    const updatedUser: User = typeof idOrUser === "string"
      ? { ...oldUser, ...(partialUpdate || {}), lastActive: "Just now" }
      : { ...oldUser, ...idOrUser, ...(partialUpdate || {}), lastActive: "Just now" };

    const roleChanged = oldUser.role !== updatedUser.role;
    const statusChanged = oldUser.status !== updatedUser.status;

    users[index] = updatedUser;
    this.saveUsers(users);

    // If current logged-in user was updated, refresh session
    const cur = this.getCurrentUser();
    if (cur && cur.id === updatedUser.id) {
      this.setCurrentUser(users[index]);
    }

    // Audit log
    if (roleChanged) {
      this.addAuditLog({
        userId: cur?.id || "sys",
        userName: cur?.name || "Admin",
        userRole: cur?.role || "ADMIN",
        action: "ROLE_CHANGED",
        details: `Modified role for ${updatedUser.name}: [${oldUser.role}] -> [${updatedUser.role}]`,
        targetEntity: updatedUser.id,
        severity: "WARNING",
      });
    } else if (statusChanged) {
      this.addAuditLog({
        userId: cur?.id || "sys",
        userName: cur?.name || "Admin",
        userRole: cur?.role || "ADMIN",
        action: "USER_STATUS_TOGGLED",
        details: `Updated status for ${updatedUser.name}: [${oldUser.status}] -> [${updatedUser.status}]`,
        targetEntity: updatedUser.id,
        severity: "INFO",
      });
    } else {
      this.addAuditLog({
        userId: cur?.id || "sys",
        userName: cur?.name || "Admin",
        userRole: cur?.role || "ADMIN",
        action: "USER_UPDATED",
        details: `Updated profile & facility assignment for ${updatedUser.name} (${updatedUser.badgeId})`,
        targetEntity: updatedUser.id,
        severity: "INFO",
      });
    }

    return true;
  }

  public static deleteUser(
    userId: string,
    requestingUser?: User
  ): { success: boolean; error?: string } {
    const operator = requestingUser || this.getAuthUser() || this.getCurrentUser();

    // Security Gate: Only ADMIN role is authorized to delete employee accounts
    if (operator.role !== "ADMIN") {
      this.addAuditLog({
        userId: operator.id,
        userName: operator.name,
        userRole: operator.role,
        action: "SECURITY_SETTING_CHANGED",
        details: `UNAUTHORIZED DELETE ATTEMPT: User ${operator.name} (${operator.badgeId}, Role: ${operator.role}) attempted to delete employee ID [${userId}] without Administrator clearance.`,
        targetEntity: userId,
        severity: "CRITICAL",
      });
      return {
        success: false,
        error: "Access Denied: Only System & Plant Administrators have permission to delete employee records.",
      };
    }

    const users = this.getUsers();
    const target = users.find((u) => u.id === userId);
    if (!target) {
      return { success: false, error: "Employee account not found in directory." };
    }

    // Safeguard: Prevent deleting the last remaining active Administrator
    const remainingAdmins = users.filter((u) => u.role === "ADMIN" && u.id !== userId);
    if (target.role === "ADMIN" && remainingAdmins.length === 0) {
      return {
        success: false,
        error: "Action Denied: Cannot delete the only remaining active Administrator account in the plant system.",
      };
    }

    // Safeguard: Disallow deleting currently authenticated self directly from directory
    if (operator.id === userId) {
      return {
        success: false,
        error: "Action Denied: You cannot delete your currently active administrator account. Please switch accounts first.",
      };
    }

    const filtered = users.filter((u) => u.id !== userId);
    this.saveUsers(filtered);

    this.addAuditLog({
      userId: operator.id,
      userName: operator.name,
      userRole: operator.role,
      action: "USER_DELETED",
      details: `Administrator ${operator.name} (${operator.badgeId}) permanently decommissioned and deleted employee account: ${target.name} (@${target.username || "n/a"}, Badge: ${target.badgeId}, Role: ${target.role}, Facility: ${target.facility}).`,
      targetEntity: target.id,
      severity: "CRITICAL",
    });

    this.notify();
    return { success: true };
  }

  public static toggleUserStatus(userId: string): User | null {
    const users = this.getUsers();
    const target = users.find((u) => u.id === userId);
    if (!target) return null;

    target.status = target.status === "ACTIVE" ? "INACTIVE" : "ACTIVE";
    this.saveUsers(users);

    const cur = this.getCurrentUser();
    this.addAuditLog({
      userId: cur?.id || "sys",
      userName: cur?.name || "Admin",
      userRole: cur?.role || "ADMIN",
      action: "USER_STATUS_TOGGLED",
      details: `${target.status === "ACTIVE" ? "Re-activated" : "Deactivated"} user account for ${target.name} (${target.badgeId})`,
      targetEntity: target.id,
      severity: target.status === "ACTIVE" ? "INFO" : "WARNING",
    });

    return target;
  }

  public static updateUserStats(userId: string, delta: Partial<User["stats"]>) {
    const users = this.getUsers();
    const target = users.find((u) => u.id === userId);
    if (!target) return;

    target.stats = {
      solutionsLogged: target.stats.solutionsLogged + (delta.solutionsLogged || 0),
      verificationsPerformed: target.stats.verificationsPerformed + (delta.verificationsPerformed || 0),
      helpfulVotesReceived: target.stats.helpfulVotesReceived + (delta.helpfulVotesReceived || 0),
      quizScorePercent: delta.quizScorePercent !== undefined ? delta.quizScorePercent : target.stats.quizScorePercent,
    };
    target.lastActive = "Just now";

    this.saveUsers(users);
  }

  // --- AUDIT LOGS ---

  public static getAuditLogs(): AuditLog[] {
    try {
      const data = localStorage.getItem(AUDIT_LOGS_KEY);
      if (!data) {
        const seedLogs: AuditLog[] = [
          {
            id: "log-001",
            timestamp: new Date(Date.now() - 3600000 * 2).toISOString(),
            userId: "usr-admin-01",
            userName: "Dave Sterling",
            userRole: "ADMIN",
            action: "SECURITY_SETTING_CHANGED",
            details: "Updated floor security policy: Require Shift Lead stamp for Critical E-Stop bypasses",
            severity: "INFO",
          },
          {
            id: "log-002",
            timestamp: new Date(Date.now() - 3600000 * 5).toISOString(),
            userId: "usr-sup-02",
            userName: "Elena Rostova",
            userRole: "SHIFT_SUPERVISOR",
            action: "ENTRY_VERIFIED",
            details: "Verified standard resolution for AMR LiDAR reflection in Aisle 4",
            targetEntity: "kb-amr-01",
            severity: "INFO",
          },
          {
            id: "log-003",
            timestamp: new Date(Date.now() - 3600000 * 24).toISOString(),
            userId: "usr-admin-01",
            userName: "Dave Sterling",
            userRole: "ADMIN",
            action: "USER_CREATED",
            details: "Provisioned Graduate Engineer Trainee account for Alex Vance (#GET-512)",
            targetEntity: "usr-get-05",
            severity: "INFO",
          },
        ];
        this.saveAuditLogs(seedLogs);
        return seedLogs;
      }
      return JSON.parse(data);
    } catch (e) {
      console.error("Failed to load audit logs:", e);
      return [];
    }
  }

  public static saveAuditLogs(logs: AuditLog[]) {
    try {
      localStorage.setItem(AUDIT_LOGS_KEY, JSON.stringify(logs.slice(0, 200))); // Keep last 200 logs
      this.notify();
    } catch (e) {
      console.error("Failed to save audit logs:", e);
    }
  }

  public static addAuditLog(logData: Omit<AuditLog, "id" | "timestamp">) {
    const logs = this.getAuditLogs();
    const newLog: AuditLog = {
      ...logData,
      id: `log-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      timestamp: new Date().toISOString(),
    };
    logs.unshift(newLog);
    this.saveAuditLogs(logs);
  }

  // --- SYSTEM TOOLS & EXPORT ---

  public static resetToFactorySeed(): TroubleshootingEntry[] {
    return this.resetToDefaultSeed();
  }

  public static resetToDefaultSeed(): TroubleshootingEntry[] {
    this.saveEntries(INITIAL_ENTRIES);
    this.saveUsers(INITIAL_USERS);
    this.setCurrentUser(INITIAL_USERS[0]);
    this.clearSyncQueue();
    return INITIAL_ENTRIES;
  }

  public static exportFullSystemJSON(): string {
    return this.exportJSON();
  }

  public static exportJSON(): string {
    const payload = {
      exportTimestamp: new Date().toISOString(),
      system: "Operation Hub",
      version: "4.12.0",
      entries: this.getEntries(),
      users: this.getUsers(),
      auditLogs: this.getAuditLogs(),
    };
    return JSON.stringify(payload, null, 2);
  }

  public static importJSON(jsonStr: string): { success: boolean; count: number; error?: string } {
    try {
      const parsed = JSON.parse(jsonStr);
      if (parsed.entries && Array.isArray(parsed.entries)) {
        this.saveEntries(parsed.entries);
        if (parsed.users && Array.isArray(parsed.users)) {
          this.saveUsers(parsed.users);
        }
        if (parsed.auditLogs && Array.isArray(parsed.auditLogs)) {
          this.saveAuditLogs(parsed.auditLogs);
        }
        return { success: true, count: parsed.entries.length };
      }
      if (Array.isArray(parsed) && parsed.length > 0) {
        this.saveEntries(parsed);
        return { success: true, count: parsed.length };
      }
      return { success: false, count: 0, error: "Invalid JSON format: Expected an array or Operation Hub export payload." };
    } catch (e: any) {
      return { success: false, count: 0, error: e.message || "Failed to parse JSON" };
    }
  }
}

