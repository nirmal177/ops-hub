export type EquipmentDomain = "AMR" | "NETWORKING" | "COMMISSIONING" | "FORKLIFT" | "NONE";

export type Severity = "CRITICAL_STOP" | "HIGH_DEGRADED" | "MEDIUM_WARNING" | "LOW_MAINTENANCE" | "NONE";

export type SyncStatus = "synced" | "pending" | "failed";

export type UserRole =
  | "GET_TRAINEE"
  | "ASSISTANT_MANAGER"
  | "MANAGER"
  | "ADMIN"
  | "MAINTENANCE_ENGINEER"
  | "NONE";

export type UserStatus = "ACTIVE" | "INACTIVE" | "ON_LEAVE" | "RESTRICTED" | "NONE";

export interface User {
  id: string;
  name: string;
  username?: string;
  password?: string;
  email: string;
  badgeId: string;
  role: UserRole;
  status: UserStatus;
  facility: string;
  line: string;
  shift?: string;
  department?: string;
  specialties: EquipmentDomain[];
  phone?: string;
  avatarColor?: string;
  createdAt: string;
  lastActive: string;
  stats: {
    solutionsLogged: number;
    verificationsPerformed: number;
    helpfulVotesReceived: number;
    quizScorePercent: number;
  };
  permissions?: {
    canVerifySolutions: boolean;
    canDeleteEntries: boolean;
    canManageUsers: boolean;
    canDeleteUsers: boolean;
    canExportData: boolean;
    canEditSafetyLOTO: boolean;
    canPublishDirectly: boolean;
  };
}

export interface AuditLog {
  id: string;
  timestamp: string;
  userId: string;
  userName: string;
  userRole: UserRole;
  action:
    | "USER_CREATED"
    | "USER_UPDATED"
    | "USER_DELETED"
    | "ROLE_CHANGED"
    | "ENTRY_VERIFIED"
    | "ENTRY_UNVERIFIED"
    | "ENTRY_DELETED"
    | "SYSTEM_EXPORTED"
    | "SECURITY_SETTING_CHANGED"
    | "USER_STATUS_TOGGLED"
    | "USER_LOGGED_IN"
    | "USER_LOGGED_OUT"
    | "USER_REGISTERED";
  details: string;
  targetEntity?: string;
  severity: "INFO" | "WARNING" | "CRITICAL";
}

export interface CommentEntry {
  id: string;
  author: string;
  role: string;
  text: string;
  createdAt: string;
  workedForUser: boolean;
}

export interface TroubleshootingEntry {
  id: string;
  title: string;
  errorCode: string;
  equipmentId: string;
  equipmentModel: string;
  domain: EquipmentDomain;
  subsystem: string;
  severity: Severity;
  symptoms: string[];
  rootCause: string;
  stepsToResolve: string[];
  toolsRequired: string[];
  safetyPrecaution: string;
  images: string[];
  author: {
    name: string;
    role: string;
    badge?: string;
  };
  createdAt: string;
  updatedAt: string;
  verified: boolean;
  verifiedBy?: string;
  verifiedDate?: string;
  helpfulCount: number;
  userVotedHelpful?: boolean;
  estimatedFixTimeMinutes: number;
  tags: string[];
  comments: CommentEntry[];
  syncStatus: SyncStatus;
}

export interface DomainMeta {
  id: EquipmentDomain;
  label: string;
  shortCode: string;
  description: string;
  color: string;
  bgColor: string;
  borderColor: string;
  badgeClass: string;
  iconName: string;
  subsystems: string[];
  commonErrorCodes: string[];
}

export interface QuickFilterState {
  searchQuery: string;
  selectedDomain: EquipmentDomain | "ALL";
  selectedSeverity: Severity | "ALL";
  verifiedOnly: boolean;
  hasImagesOnly: boolean;
  quickFixOnly: boolean; // < 15 min
  sortBy: "newest" | "helpful" | "fastest" | "none";
}

export interface DiagnosticSession {
  id: string;
  title: string;
  equipmentId: string;
  domain: EquipmentDomain;
  errorCode?: string;
  symptoms: string[];
  analysis?: {
    probableCause: string;
    diagnosticSteps: string[];
    safetyWarnings: string[];
    recommendedTools: string[];
    confidenceScore: number;
  };
}

export interface ShiftInfo {
  shiftName: "Morning (06:00-14:00)" | "Evening (14:00-22:00)" | "Night (22:00-06:00)";
  facility: string;
  line: string;
  userName: string;
  userRole: "Graduate Engineer Trainee (GET)" | "Senior Maintenance Tech" | "Commissioning Lead" | "Shift Supervisor";
}
