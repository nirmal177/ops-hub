import React, { useState, useEffect } from "react";
import {
  X,
  User as UserIcon,
  Shield,
  Building,
  Mail,
  Phone,
  Tag,
  Check,
  AlertTriangle,
} from "lucide-react";
import { User, UserRole, UserStatus, EquipmentDomain } from "../types";
import { ROLE_CONFIG } from "../data/seedUsers";

interface UserEditModalProps {
  isOpen: boolean;
  onClose: () => void;
  userToEdit: User | null; // null means create new user
  onSave: (user: Omit<User, "id" | "createdAt" | "lastActive" | "stats"> & { id?: string }) => void;
}

const AVAILABLE_FACILITIES = [
  "GIGA-FACTORY-01",
  "GIGA-FACTORY-02",
  "NORTH-PLANT-ALPHA",
  "CENTRAL-LOGISTICS-HUB",
];

const AVAILABLE_LINES = [
  "Line 1 (Body & Chassis)",
  "Line 2 (Battery Pack Assembly)",
  "Line 3 (Final Quality & Shipping)",
  "Line 4 (AMR & Logistics)",
  "Commissioning Staging Area",
];

const ALL_DOMAINS: EquipmentDomain[] = ["AMR", "NETWORKING", "COMMISSIONING", "FORKLIFT"];

export const UserEditModal: React.FC<UserEditModalProps> = ({
  isOpen,
  onClose,
  userToEdit,
  onSave,
}) => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [badgeId, setBadgeId] = useState("");
  const [role, setRole] = useState<UserRole>("GET_TRAINEE");
  const [status, setStatus] = useState<UserStatus>("ACTIVE");
  const [facility, setFacility] = useState(AVAILABLE_FACILITIES[0]);
  const [line, setLine] = useState(AVAILABLE_LINES[0]);
  const [specialties, setSpecialties] = useState<EquipmentDomain[]>(["AMR"]);
  const [phone, setPhone] = useState("");
  const [avatarColor, setAvatarColor] = useState("#FACC15");

  useEffect(() => {
    if (userToEdit) {
      setName(userToEdit.name);
      setEmail(userToEdit.email);
      setBadgeId(userToEdit.badgeId);
      setRole(userToEdit.role);
      setStatus(userToEdit.status);
      setFacility(userToEdit.facility);
      setLine(userToEdit.line);
      setSpecialties(userToEdit.specialties || ["AMR"]);
      setPhone(userToEdit.phone || "");
      setAvatarColor(userToEdit.avatarColor || "#FACC15");
    } else {
      setName("");
      setEmail("");
      setBadgeId(`TEC-${Math.floor(100 + Math.random() * 900)}`);
      setRole("GET_TRAINEE");
      setStatus("ACTIVE");
      setFacility(AVAILABLE_FACILITIES[0]);
      setLine(AVAILABLE_LINES[0]);
      setSpecialties(["AMR"]);
      setPhone("");
      setAvatarColor("#FACC15");
    }
  }, [userToEdit, isOpen]);

  if (!isOpen) return null;

  const handleToggleSpecialty = (dom: EquipmentDomain) => {
    if (specialties.includes(dom)) {
      if (specialties.length > 1) {
        setSpecialties(specialties.filter((s) => s !== dom));
      }
    } else {
      setSpecialties([...specialties, dom]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !badgeId.trim()) return;

    onSave({
      ...(userToEdit ? { id: userToEdit.id } : {}),
      name: name.trim(),
      email: email.trim(),
      badgeId: badgeId.trim().toUpperCase(),
      role,
      status,
      facility,
      line,
      specialties,
      phone: phone.trim(),
      avatarColor,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-[#1a1d23] border border-[#2d323b] rounded-2xl w-full max-w-xl max-h-[90vh] flex flex-col shadow-2xl text-gray-200 overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-[#2d323b] flex items-center justify-between bg-[#121417]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#2d323b] text-[#FACC15] flex items-center justify-center border border-[#3d424d]">
              <UserIcon className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white font-mono uppercase tracking-wider">
                {userToEdit ? "Edit Staff Profile & Role" : "Provision New Staff & Operator Profile"}
              </h3>
              <p className="text-xs text-gray-400 font-mono">
                Configure role capabilities, badge credentials, and line assignment
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white p-1.5 rounded-lg hover:bg-[#2d323b] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-gray-400 mb-1 font-mono uppercase text-[11px]">
                Full Name *
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Marcus Chen"
                required
                className="w-full text-xs font-mono font-bold bg-[#121417] text-white border border-[#3d424d] rounded-lg p-2.5 focus:border-[#FACC15] focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-400 mb-1 font-mono uppercase text-[11px]">
                Badge ID / Operator Code *
              </label>
              <input
                type="text"
                value={badgeId}
                onChange={(e) => setBadgeId(e.target.value)}
                placeholder="e.g. TEC-209"
                required
                className="w-full text-xs font-mono font-bold bg-[#121417] text-white border border-[#3d424d] rounded-lg p-2.5 focus:border-[#FACC15] focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-gray-400 mb-1 font-mono uppercase text-[11px]">
                Internal Email *
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="m.chen@plantops.internal"
                required
                className="w-full text-xs font-mono font-bold bg-[#121417] text-white border border-[#3d424d] rounded-lg p-2.5 focus:border-[#FACC15] focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-400 mb-1 font-mono uppercase text-[11px]">
                Phone / Radio Channel
              </label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+1 (555) 019-9941"
                className="w-full text-xs font-mono font-bold bg-[#121417] text-white border border-[#3d424d] rounded-lg p-2.5 focus:border-[#FACC15] focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-gray-400 mb-1 font-mono uppercase text-[11px]">
                Assigned Role *
              </label>
              <select
                value={role}
                onChange={(e) => setRole(e.target.value as UserRole)}
                className="w-full text-xs font-mono font-bold bg-[#121417] text-white border border-[#3d424d] rounded-lg p-2.5 focus:border-[#FACC15] focus:outline-none"
              >
                <option value="GET_TRAINEE">1. Graduate Engineering Trainee (GET)</option>
                <option value="ASSISTANT_MANAGER">2. Assistant Manager</option>
                <option value="MANAGER">3. Manager</option>
                <option value="ADMIN">4. Admin</option>
                <option value="MAINTENANCE_ENGINEER">5. Maintenance Engineer</option>
                <option value="NONE">None / Unassigned</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-400 mb-1 font-mono uppercase text-[11px]">
                Account Status *
              </label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as UserStatus)}
                className="w-full text-xs font-mono font-bold bg-[#121417] text-white border border-[#3d424d] rounded-lg p-2.5 focus:border-[#FACC15] focus:outline-none"
              >
                <option value="NONE">None / Unspecified</option>
                <option value="ACTIVE">Active (Full Access)</option>
                <option value="ON_LEAVE">On Leave</option>
                <option value="INACTIVE">Inactive / Archived</option>
                <option value="RESTRICTED">Restricted (Kiosk Only)</option>
              </select>
            </div>
          </div>

          {/* Role Capability Description Notice */}
          <div className="p-3 bg-[#121417] rounded-lg border border-[#2d323b] text-xs font-mono">
            <div className="flex items-center gap-1.5 text-[#FACC15] font-bold mb-1">
              <Shield className="w-3.5 h-3.5" />
              <span>ROLE PRIVILEGES: {ROLE_CONFIG[role]?.label || "Unassigned"}</span>
            </div>
            <p className="text-gray-400 text-[11px] leading-relaxed">
              {ROLE_CONFIG[role]?.description || "Standard viewing access."}
            </p>
          </div>

          {/* Facility and Line */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-gray-400 mb-1 font-mono uppercase text-[11px]">
                Plant Facility
              </label>
              <select
                value={facility}
                onChange={(e) => setFacility(e.target.value)}
                className="w-full text-xs font-mono font-bold bg-[#121417] text-white border border-[#3d424d] rounded-lg p-2.5 focus:border-[#FACC15] focus:outline-none"
              >
                <option value="None">None (Unassigned Facility)</option>
                {AVAILABLE_FACILITIES.map((fac) => (
                  <option key={fac} value={fac}>
                    {fac}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-400 mb-1 font-mono uppercase text-[11px]">
                Primary Production Line
              </label>
              <select
                value={line}
                onChange={(e) => setLine(e.target.value)}
                className="w-full text-xs font-mono font-bold bg-[#121417] text-white border border-[#3d424d] rounded-lg p-2.5 focus:border-[#FACC15] focus:outline-none"
              >
                <option value="None">None (Unassigned Line)</option>
                {AVAILABLE_LINES.map((l) => (
                  <option key={l} value={l}>
                    {l}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Equipment Domain Specialties */}
          <div>
            <label className="block text-xs font-bold text-gray-400 mb-2 font-mono uppercase text-[11px]">
              Domain Certifications & Specialties
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {ALL_DOMAINS.map((dom) => {
                const isChecked = specialties.includes(dom);
                return (
                  <button
                    type="button"
                    key={dom}
                    onClick={() => handleToggleSpecialty(dom)}
                    className={`p-2 rounded-lg border text-xs font-mono transition-all flex items-center justify-between gap-1.5 ${
                      isChecked
                        ? "bg-[#2d323b] text-[#FACC15] border-[#FACC15] font-bold"
                        : "bg-[#121417] text-gray-400 border-[#2d323b] hover:text-white"
                    }`}
                  >
                    <span>{dom}</span>
                    {isChecked && <Check className="w-3.5 h-3.5 text-[#FACC15]" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Modal Action Buttons */}
          <div className="pt-4 border-t border-[#2d323b] flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="text-xs font-mono font-bold uppercase tracking-wider text-gray-400 hover:text-white px-4 py-2 rounded-lg border border-[#2d323b] bg-[#121417] hover:bg-[#252a33] transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="bg-[#FACC15] hover:bg-yellow-300 active:bg-yellow-500 text-[#121417] font-bold text-xs uppercase tracking-wider px-5 py-2 rounded-lg shadow-sm flex items-center gap-1.5 transition-all"
            >
              <Check className="w-4 h-4 stroke-[3]" />
              <span>{userToEdit ? "Save Profile Changes" : "Create User Profile"}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
