import React from "react";
import { WifiOff, Wifi, RefreshCw, CheckCircle2, AlertTriangle, Smartphone, ShieldCheck } from "lucide-react";

interface OfflineSyncBannerProps {
  isOnline: boolean;
  pendingSyncCount: number;
  onManualSync: () => void;
  isSyncing: boolean;
  onToggleOfflineSimulation: (forcedOffline: boolean | null) => void;
  isSimulatedOffline: boolean;
}

export const OfflineSyncBanner: React.FC<OfflineSyncBannerProps> = ({
  isOnline,
  pendingSyncCount,
  onManualSync,
  isSyncing,
  onToggleOfflineSimulation,
  isSimulatedOffline,
}) => {
  return (
    <div className="bg-[#121417] border-b border-[#2d323b] text-xs px-4 sm:px-6 py-2">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          {!isOnline ? (
            <div className="flex items-center gap-2 text-amber-400">
              <span className="flex h-2 w-2 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-500"></span>
              </span>
              <WifiOff className="w-3.5 h-3.5 text-amber-400" />
              <span className="font-bold uppercase tracking-wider text-[11px]">Offline Issue Diagnostic Mode:</span>
              <span className="text-gray-300">
                All error logs, photos, and resolutions are caching locally to client storage.
              </span>
            </div>
          ) : (
            <div className="flex items-center gap-2 text-gray-300">
              <div className="w-2 h-2 rounded-full bg-green-500 shadow-[0_0_6px_rgba(34,197,94,0.6)]" />
              <ShieldCheck className="w-4 h-4 text-green-400" />
              <span className="text-gray-300">
                <strong className="text-white font-semibold">Zero-Friction Offline Cache Ready:</strong> Instant error triage even in wireless deadzones.
              </span>
            </div>
          )}
        </div>

        <div className="flex items-center gap-3">
          {pendingSyncCount > 0 && (
            <button
              onClick={onManualSync}
              disabled={isSyncing}
              className="bg-[#FACC15] hover:bg-yellow-300 active:bg-yellow-500 text-[#121417] font-bold text-[11px] uppercase tracking-wider px-2.5 py-1 rounded flex items-center gap-1.5 transition-all shadow-sm"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? "animate-spin" : ""}`} />
              <span>Sync {pendingSyncCount} Pending Fixes</span>
            </button>
          )}

          {/* Test Offline Simulation Toggle */}
          <button
            onClick={() => onToggleOfflineSimulation(isSimulatedOffline ? null : true)}
            className={`px-2.5 py-1 rounded border transition-colors flex items-center gap-1.5 font-mono text-[11px] ${
              isSimulatedOffline
                ? "bg-amber-950/80 border-amber-600 text-amber-300 hover:bg-amber-900"
                : "bg-[#1a1d23] border-[#2d323b] text-gray-400 hover:text-gray-200 hover:border-gray-500"
            }`}
            title="Simulate network deadzone without WiFi to test offline caching"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>{isSimulatedOffline ? "RESTORE LIVE WIFI" : "SIMULATE OFFLINE DEADZONE"}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
