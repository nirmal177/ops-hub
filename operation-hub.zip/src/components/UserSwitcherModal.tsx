import React, { useState } from "react";
import {
  X,
  UserCheck,
  Shield,
  Search,
  Plus,
  Check,
  Building,
  Cpu,
  LogOut,
  Sparkles,
} from "lucide-react";
import { User, UserRole } from "../types";
import { ROLE_CONFIG } from "../data/seedUsers";

interface UserSwitcherModalProps {
  isOpen: boolean;
  onClose: () => void;
  users: User[];
  currentUser: User;
  onSelectUser: (user: User) => void;
  onOpenAddUser: () => void;
  onOpenAdminConsole: () => void;
  onLogout?: () => void;
}

export const UserSwitcherModal: React.FC<UserSwitcherModalProps> = ({
  isOpen,
  onClose,
  users,
  currentUser,
  onSelectUser,
  onOpenAddUser,
  onOpenAdminConsole,
  onLogout,
}) => {
  const [search, setSearch] = useState("");
  const [selectedRoleFilter, setSelectedRoleFilter] = useState<UserRole | "ALL">("ALL");

  if (!isOpen) return null;

  const filteredUsers = users.filter((u) => {
    const matchesSearch =
      u.name.toLowerCase().includes(search.toLowerCase()) ||
      u.badgeId.toLowerCase().includes(search.toLowerCase()) ||
      u.email.toLowerCase().includes(search.toLowerCase()) ||
      u.facility.toLowerCase().includes(search.toLowerCase());
    const matchesRole = selectedRoleFilter === "ALL" || u.role === selectedRoleFilter;
    return matchesSearch && matchesRole;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-[#1a1d23] border border-[#2d323b] rounded-2xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl text-gray-200 overflow-hidden">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-[#2d323b] flex items-center justify-between bg-[#121417]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#2d323b] text-[#FACC15] flex items-center justify-center border border-[#3d424d]">
              <UserCheck className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white font-mono uppercase tracking-wider flex items-center gap-2">
                <span>Active Operator & Kiosk Switcher</span>
              </h3>
              <p className="text-xs text-gray-400 font-mono">
                Select technician profile or switch to Admin console
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white p-1.5 rounded-lg hover:bg-[#2d323b] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current User Active Banner */}
        <div className="p-4 bg-[#1e2229] border-b border-[#2d323b] flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-lg flex items-center justify-center font-bold text-sm text-[#121417] shadow-sm font-mono"
              style={{ backgroundColor: currentUser.avatarColor || "#FACC15" }}
            >
              {currentUser.name
                .split(" ")
                .map((n) => n[0])
                .slice(0, 2)
                .join("")}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs text-gray-400 font-mono">CURRENTLY LOGGED IN:</span>
                <span className="font-bold text-white text-sm">{currentUser.name}</span>
                <span
                  className={`text-[10px] font-mono font-bold px-1.5 py-0.2 rounded border ${
                    ROLE_CONFIG[currentUser.role]?.badgeBg || "bg-[#121417]"
                  } text-[#FACC15] ${ROLE_CONFIG[currentUser.role]?.badgeBorder || "border-[#3d424d]"}`}
                >
                  {currentUser.badgeId} • {ROLE_CONFIG[currentUser.role]?.badgeLabel || currentUser.role}
                </span>
              </div>
              <p className="text-[11px] text-gray-400 font-mono">
                {currentUser.facility} • {currentUser.line}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {(currentUser.role === "ADMIN" || currentUser.role === "MANAGER") && (
              <button
                onClick={() => {
                  onClose();
                  onOpenAdminConsole();
                }}
                className="bg-[#2d323b] hover:bg-[#3d424d] text-[#FACC15] text-xs font-mono font-bold uppercase tracking-wider px-3 py-1.5 rounded-lg border border-[#3d424d] flex items-center gap-1.5 transition-colors"
              >
                <Shield className="w-3.5 h-3.5" />
                <span>Admin Console</span>
              </button>
            )}
          </div>
        </div>

        {/* Search & Filter Controls */}
        <div className="p-4 border-b border-[#2d323b] space-y-3 bg-[#121417]">
          <div className="relative">
            <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search technician by name, badge (#GET-512), email, or facility..."
              className="w-full bg-[#1a1d23] text-white text-xs pl-9 pr-4 py-2 rounded-lg border border-[#2d323b] focus:border-[#FACC15] focus:outline-none placeholder:text-gray-500 font-mono"
            />
          </div>

          {/* Quick Role Filter Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
            <button
              onClick={() => setSelectedRoleFilter("ALL")}
              className={`text-[11px] font-mono px-2.5 py-1 rounded transition-colors whitespace-nowrap border ${
                selectedRoleFilter === "ALL"
                  ? "bg-[#FACC15] text-[#121417] font-bold border-[#FACC15]"
                  : "bg-[#1a1d23] text-gray-400 border-[#2d323b] hover:text-white"
              }`}
            >
              ALL ROLES ({users.length})
            </button>
            {(
              [
                "GET_TRAINEE",
                "ASSISTANT_MANAGER",
                "MANAGER",
                "ADMIN",
                "MAINTENANCE_ENGINEER",
              ] as UserRole[]
            ).map((role) => (
              <button
                key={role}
                onClick={() => setSelectedRoleFilter(role)}
                className={`text-[11px] font-mono px-2 py-1 rounded transition-colors whitespace-nowrap border ${
                  selectedRoleFilter === role
                    ? "bg-[#FACC15] text-[#121417] font-bold border-[#FACC15]"
                    : "bg-[#1a1d23] text-gray-400 border-[#2d323b] hover:text-white"
                }`}
              >
                {ROLE_CONFIG[role]?.badgeLabel || role}
              </button>
            ))}
          </div>
        </div>

        {/* User List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2 max-h-96">
          {filteredUsers.length === 0 ? (
            <div className="p-8 text-center text-gray-500 font-mono text-xs">
              No staff members found matching "{search}".
            </div>
          ) : (
            filteredUsers.map((user) => {
              const isCurrent = user.id === currentUser.id;
              const roleMeta = ROLE_CONFIG[user.role];

              return (
                <div
                  key={user.id}
                  onClick={() => {
                    onSelectUser(user);
                    onClose();
                  }}
                  className={`p-3 rounded-xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                    isCurrent
                      ? "bg-[#2d323b] border-[#FACC15] shadow-sm ring-1 ring-[#FACC15]/40"
                      : "bg-[#121417] border-[#2d323b] hover:bg-[#1e2229] hover:border-gray-500"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className="w-9 h-9 rounded-lg flex items-center justify-center font-bold text-xs text-[#121417] font-mono shrink-0"
                      style={{ backgroundColor: user.avatarColor || "#FACC15" }}
                    >
                      {user.name
                        .split(" ")
                        .map((n) => n[0])
                        .slice(0, 2)
                        .join("")}
                    </div>
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-xs sm:text-sm font-bold text-white">
                          {user.name}
                        </span>
                        <span
                          className={`text-[10px] font-mono font-bold px-1.5 py-0.2 rounded border ${
                            roleMeta?.badgeBg || "bg-[#1a1d23]"
                          } text-[#FACC15] ${roleMeta?.badgeBorder || "border-[#3d424d]"}`}
                        >
                          {user.badgeId} • {roleMeta?.badgeLabel || user.role}
                        </span>
                        {user.status !== "ACTIVE" && (
                          <span className="text-[10px] font-mono bg-red-950/60 text-red-400 border border-red-800 px-1 rounded">
                            {user.status}
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-gray-400 font-mono mt-0.5">
                        {user.facility} • {user.line} • {user.email}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    {isCurrent ? (
                      <span className="flex items-center gap-1 text-xs font-mono font-bold text-green-400 bg-green-950/60 border border-green-800 px-2 py-1 rounded">
                        <Check className="w-3.5 h-3.5" />
                        <span>Active</span>
                      </span>
                    ) : (
                      <button className="text-[11px] font-mono font-semibold text-[#FACC15] hover:text-white bg-[#1a1d23] hover:bg-[#252a33] px-2.5 py-1 rounded border border-[#2d323b] transition-colors">
                        Sign In
                      </button>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-[#2d323b] bg-[#121417] flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                onClose();
                onOpenAddUser();
              }}
              className="text-xs font-mono font-bold uppercase tracking-wider text-gray-300 hover:text-white flex items-center gap-1.5 bg-[#1a1d23] hover:bg-[#252a33] px-3 py-1.5 rounded-lg border border-[#2d323b] transition-colors"
            >
              <Plus className="w-3.5 h-3.5 text-[#FACC15]" />
              <span>+ Provision New User</span>
            </button>

            {onLogout && (
              <button
                onClick={() => {
                  onClose();
                  onLogout();
                }}
                className="text-xs font-mono font-bold uppercase tracking-wider text-red-400 hover:text-red-300 flex items-center gap-1.5 bg-red-950/40 hover:bg-red-950/70 px-3 py-1.5 rounded-lg border border-red-900/60 transition-colors"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Log Out</span>
              </button>
            )}
          </div>

          <button
            onClick={onClose}
            className="text-xs font-mono font-bold uppercase tracking-wider bg-[#2d323b] hover:bg-[#3d424d] text-white px-4 py-1.5 rounded-lg transition-colors border border-[#3d424d]"
          >
            Close Kiosk
          </button>
        </div>
      </div>
    </div>
  );
};
