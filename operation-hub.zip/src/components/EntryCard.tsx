import React from "react";
import {
  CheckCircle2,
  AlertTriangle,
  Clock,
  Wrench,
  ThumbsUp,
  Image as ImageIcon,
  ShieldAlert,
  ChevronRight,
  Sparkles,
  Bot,
  Network,
  Forklift,
  ExternalLink,
  MessageSquare,
} from "lucide-react";
import { TroubleshootingEntry, EquipmentDomain } from "../types";
import { DOMAIN_CONFIG } from "../data/seedEntries";

interface EntryCardProps {
  entry: TroubleshootingEntry;
  onSelect: (entry: TroubleshootingEntry) => void;
  onToggleHelpful: (entryId: string, e: React.MouseEvent) => void;
}

export const EntryCard: React.FC<EntryCardProps> = ({ entry, onSelect, onToggleHelpful }) => {
  const domainConfig = DOMAIN_CONFIG[entry.domain] || DOMAIN_CONFIG.AMR;

  const getSeverityBadge = () => {
    switch (entry.severity) {
      case "CRITICAL_STOP":
        return (
          <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded bg-rose-950/60 text-rose-400 border border-rose-800 uppercase font-mono">
            <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-pulse" />
            CRITICAL STOP
          </span>
        );
      case "HIGH_DEGRADED":
        return (
          <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded bg-amber-950/60 text-amber-400 border border-amber-800 uppercase font-mono">
            HIGH DEGRADED
          </span>
        );
      case "MEDIUM_WARNING":
        return (
          <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded bg-blue-950/60 text-blue-400 border border-blue-800 uppercase font-mono">
            WARNING
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded bg-[#121417] text-gray-400 border border-[#2d323b] uppercase font-mono">
            MAINTENANCE
          </span>
        );
    }
  };

  const getDomainIcon = (domain: EquipmentDomain) => {
    switch (domain) {
      case "AMR":
        return <Bot className="w-3.5 h-3.5" />;
      case "NETWORKING":
        return <Network className="w-3.5 h-3.5" />;
      case "FORKLIFT":
        return <Forklift className="w-3.5 h-3.5" />;
      case "COMMISSIONING":
      default:
        return <Wrench className="w-3.5 h-3.5" />;
    }
  };

  return (
    <div
      onClick={() => onSelect(entry)}
      className="bg-[#1a1d23] rounded-xl border border-[#2d323b] hover:border-[#FACC15] hover:bg-[#1e2229] transition-all p-4 sm:p-5 flex flex-col justify-between cursor-pointer group relative shadow-sm"
      id={`card-${entry.id}`}
    >
      <div>
        {/* Top Badges Bar */}
        <div className="flex flex-wrap items-center justify-between gap-2 mb-2.5">
          <div className="flex flex-wrap items-center gap-1.5">
            <span
              className={`inline-flex items-center gap-1 text-[11px] font-mono font-bold px-2.5 py-0.5 rounded-full border ${domainConfig.badgeClass}`}
            >
              {getDomainIcon(entry.domain)}
              {domainConfig.shortCode}
            </span>

            {entry.errorCode && entry.errorCode !== "N/A" && (
              <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-[#121417] text-[#FACC15] border border-[#3d424d]">
                {entry.errorCode}
              </span>
            )}

            {getSeverityBadge()}
          </div>

          <div className="flex items-center gap-1.5 text-xs text-gray-400 font-mono">
            <span className="bg-[#121417] px-2 py-0.5 rounded text-gray-300 font-medium border border-[#2d323b]">
              {entry.equipmentId}
            </span>
          </div>
        </div>

        {/* Title */}
        <h3 className="text-base font-bold text-gray-100 group-hover:text-[#FACC15] transition-colors leading-snug mb-1.5">
          {entry.title}
        </h3>

        {/* Subsystem & Equipment Model */}
        <div className="text-xs text-gray-400 mb-3 flex flex-wrap items-center gap-x-2 gap-y-1">
          <span className="font-semibold text-gray-300">{entry.equipmentModel}</span>
          <span className="text-gray-600">•</span>
          <span className="text-gray-400 font-mono bg-[#121417] px-1.5 py-0.5 rounded border border-[#2d323b] text-[11px]">
            {entry.subsystem}
          </span>
        </div>

        {/* Symptoms snippet */}
        {entry.symptoms && entry.symptoms.length > 0 && (
          <div className="mb-3">
            <p className="text-xs text-gray-400 line-clamp-2 leading-relaxed">
              <strong className="text-gray-300 font-semibold">Symptom:</strong> {entry.symptoms[0]}
            </p>
          </div>
        )}

        {/* Safety Warning Callout if present */}
        {entry.safetyPrecaution && (
          <div className="bg-amber-950/40 border border-amber-700/60 rounded-lg p-2 mb-3 flex items-start gap-2 text-xs text-amber-300">
            <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <p className="line-clamp-1 font-medium">{entry.safetyPrecaution}</p>
          </div>
        )}
      </div>

      {/* Card Footer: Author, Verification, Quick Stats, & CTA */}
      <div className="pt-3 border-t border-[#2d323b] flex flex-wrap items-center justify-between gap-2 mt-2">
        <div className="flex items-center gap-3 text-xs text-gray-400">
          <span className="flex items-center gap-1 font-medium text-gray-300">
            <Clock className="w-3.5 h-3.5 text-gray-500" />
            ~{entry.estimatedFixTimeMinutes}m fix
          </span>

          <span className="flex items-center gap-1 text-gray-400">
            <Wrench className="w-3.5 h-3.5 text-gray-500" />
            {entry.stepsToResolve.length} steps
          </span>

          {entry.images && entry.images.length > 0 && (
            <span className="flex items-center gap-1 text-blue-400 font-medium">
              <ImageIcon className="w-3.5 h-3.5" />
              {entry.images.length} photo{entry.images.length > 1 ? "s" : ""}
            </span>
          )}

          {entry.comments && entry.comments.length > 0 && (
            <span className="flex items-center gap-1 text-gray-400">
              <MessageSquare className="w-3.5 h-3.5" />
              {entry.comments.length}
            </span>
          )}
        </div>

        <div className="flex items-center gap-2">
          {/* Verified Badge */}
          {entry.verified ? (
            <span
              className="inline-flex items-center gap-1 text-[10px] font-bold text-green-400 bg-green-950/60 px-2 py-0.5 rounded border border-green-800 uppercase font-mono"
              title={`Verified solution by ${entry.verifiedBy || "Senior Tech"}`}
            >
              <CheckCircle2 className="w-3 h-3 text-green-400" />
              VERIFIED
            </span>
          ) : (
            <span className="text-[10px] text-gray-500 font-mono italic">DRAFT</span>
          )}

          {/* Helpful Vote Button */}
          <button
            onClick={(e) => onToggleHelpful(entry.id, e)}
            className={`inline-flex items-center gap-1 text-xs font-semibold px-2 py-1 rounded border transition-all ${
              entry.userVotedHelpful
                ? "bg-[#FACC15] text-[#121417] border-[#FACC15] font-bold shadow-sm"
                : "bg-[#121417] text-gray-300 border-[#2d323b] hover:border-gray-500"
            }`}
            title="Mark as worked on my machine"
          >
            <ThumbsUp className={`w-3.5 h-3.5 ${entry.userVotedHelpful ? "fill-[#121417]" : ""}`} />
            <span>{entry.helpfulCount}</span>
          </button>

          <span className="text-[#FACC15] group-hover:translate-x-0.5 transition-transform">
            <ChevronRight className="w-4 h-4" />
          </span>
        </div>
      </div>
    </div>
  );
};
