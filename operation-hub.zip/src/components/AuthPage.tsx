import React, { useState } from "react";
import {
  Shield,
  KeyRound,
  UserCheck,
  UserPlus,
  Lock,
  Mail,
  User as UserIcon,
  Eye,
  EyeOff,
  AlertTriangle,
  CheckCircle2,
  Cpu,
  ArrowRight,
  Sparkles,
  Wrench,
  Layers,
  Factory,
  Radio,
  Clock,
  IdCard,
} from "lucide-react";
import { User, UserRole, EquipmentDomain } from "../types";
import { ROLE_CONFIG, AVAILABLE_FACILITIES, AVAILABLE_LINES } from "../data/seedUsers";
import { StorageService } from "../utils/storage";

interface AuthPageProps {
  onLoginSuccess: (user: User) => void;
}

export const AuthPage: React.FC<AuthPageProps> = ({ onLoginSuccess }) => {
  const [authMode, setAuthMode] = useState<"login" | "register">("login");

  // Login form state
  const [loginIdentifier, setLoginIdentifier] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [showLoginPassword, setShowLoginPassword] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Registration form state
  const [regName, setRegName] = useState("");
  const [regUsername, setRegUsername] = useState("");
  const [regEmail, setRegEmail] = useState("");
  const [regPassword, setRegPassword] = useState("");
  const [regConfirmPassword, setRegConfirmPassword] = useState("");
  const [showRegPassword, setShowRegPassword] = useState(false);
  const [regBadgeId, setRegBadgeId] = useState("");
  const [regRole, setRegRole] = useState<UserRole>("GET_TRAINEE");
  const [regFacility, setRegFacility] = useState(AVAILABLE_FACILITIES[0] || "GIGA-FACTORY-01");
  const [regLine, setRegLine] = useState(AVAILABLE_LINES[3] || "Line 4 (AMR & Logistics)");
  const [regDepartment, setRegDepartment] = useState("Field Engineering & Maintenance");
  const [regShift, setRegShift] = useState("Morning Shift (06:00 - 14:30)");
  const [regSpecialties, setRegSpecialties] = useState<EquipmentDomain[]>(["AMR"]);
  const [regError, setRegError] = useState<string | null>(null);
  const [isRegistering, setIsRegistering] = useState(false);

  // Demo users for quick login
  const seedUsers = StorageService.getUsers();
  const demoUsers = [
    { role: "ADMIN", user: seedUsers.find((u) => u.role === "ADMIN") || seedUsers[0] },
    { role: "MANAGER", user: seedUsers.find((u) => u.role === "MANAGER") },
    { role: "ASSISTANT_MANAGER", user: seedUsers.find((u) => u.role === "ASSISTANT_MANAGER") },
    { role: "MAINTENANCE_ENGINEER", user: seedUsers.find((u) => u.role === "MAINTENANCE_ENGINEER") },
    { role: "GET_TRAINEE", user: seedUsers.find((u) => u.role === "GET_TRAINEE") },
  ].filter((item) => Boolean(item.user));

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);

    if (!loginIdentifier.trim()) {
      setLoginError("Please enter your username, work email, or badge ID.");
      return;
    }
    if (!loginPassword.trim()) {
      setLoginError("Please enter your password.");
      return;
    }

    setIsLoggingIn(true);
    setTimeout(() => {
      const res = StorageService.login(loginIdentifier, loginPassword);
      setIsLoggingIn(false);

      if (res.success && res.user) {
        onLoginSuccess(res.user);
      } else {
        setLoginError(res.error || "Authentication failed. Please verify credentials.");
      }
    }, 250);
  };

  const handleQuickLogin = (u: User) => {
    const username = u.username || u.email.split("@")[0];
    const password = u.password || "password123";
    setLoginIdentifier(username);
    setLoginPassword(password);
    setLoginError(null);
    setIsLoggingIn(true);

    setTimeout(() => {
      const res = StorageService.login(username, password);
      setIsLoggingIn(false);
      if (res.success && res.user) {
        onLoginSuccess(res.user);
      } else {
        setLoginError(res.error || "Failed to log in with quick account.");
      }
    }, 200);
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setRegError(null);

    if (!regName.trim()) {
      setRegError("Please provide your Full Legal or Technician Name.");
      return;
    }
    if (!regUsername.trim() || regUsername.trim().length < 3) {
      setRegError("Username must be at least 3 alphanumeric characters.");
      return;
    }
    if (!regEmail.trim() || !regEmail.includes("@")) {
      setRegError("Please enter a valid plant / organizational email address.");
      return;
    }
    if (!regPassword || regPassword.length < 6) {
      setRegError("Password must be at least 6 characters long.");
      return;
    }
    if (regPassword !== regConfirmPassword) {
      setRegError("Passwords do not match. Please re-enter.");
      return;
    }

    setIsRegistering(true);
    setTimeout(() => {
      const res = StorageService.register({
        name: regName,
        username: regUsername,
        email: regEmail,
        password: regPassword,
        badgeId: regBadgeId.trim() || undefined,
        role: regRole,
        facility: regFacility,
        line: regLine,
        department: regDepartment,
        shift: regShift,
        specialties: regSpecialties,
      });

      setIsRegistering(false);

      if (res.success && res.user) {
        onLoginSuccess(res.user);
      } else {
        setRegError(res.error || "Registration failed. Please check form inputs.");
      }
    }, 300);
  };

  const toggleSpecialty = (domain: EquipmentDomain) => {
    if (domain === "NONE") return;
    setRegSpecialties((prev) =>
      prev.includes(domain) ? prev.filter((d) => d !== domain) : [...prev, domain]
    );
  };

  return (
    <div className="min-h-screen bg-[#0d0f12] text-gray-200 flex flex-col justify-between selection:bg-[#FACC15] selection:text-black">
      {/* Top Station Status Banner */}
      <div className="bg-[#121417] border-b border-[#242831] px-4 py-2 text-xs font-mono text-gray-400 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2.5">
          <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse shadow-[0_0_8px_rgba(74,222,128,0.7)]" />
          <span className="text-gray-300 font-semibold tracking-wide">PLANT TERMINAL ACCESS GATEWAY</span>
          <span className="text-gray-600">|</span>
          <span className="text-[#FACC15]">SECURE NODE: FX-01-SEC-AUTH</span>
        </div>
        <div className="flex items-center gap-3 text-[11px] text-gray-500">
          <span className="flex items-center gap-1">
            <Radio className="w-3 h-3 text-green-400" />
            TLS 1.3 / ENCRYPTED STORAGE
          </span>
          <span>v4.12.0</span>
        </div>
      </div>

      {/* Main Authentication Container */}
      <div className="flex-1 flex items-center justify-center p-4 sm:p-6 lg:p-8">
        <div className="w-full max-w-4xl grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          {/* Left Hero & System Overview Card */}
          <div className="lg:col-span-5 bg-gradient-to-br from-[#16191f] to-[#121417] border border-[#2d323b] rounded-2xl p-6 sm:p-8 flex flex-col justify-between relative overflow-hidden shadow-2xl">
            {/* Background ambient pattern */}
            <div className="absolute -right-12 -top-12 w-48 h-48 bg-[#FACC15]/5 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute -left-12 -bottom-12 w-48 h-48 bg-blue-500/5 rounded-full blur-3xl pointer-events-none" />

            <div>
              {/* Logo & Brand */}
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-[#FACC15] rounded-xl flex items-center justify-center text-[#121417] font-bold text-xl font-mono shadow-md">
                  OH
                </div>
                <div>
                  <h1 className="text-xl font-bold font-mono tracking-tight text-white flex items-center gap-1.5 uppercase">
                    Operation <span className="text-[#FACC15]">Hub</span>
                  </h1>
                  <p className="text-[11px] text-gray-400 font-mono tracking-wider">
                    FIELD DIAGNOSTICS & RESOLUTION ENGINE
                  </p>
                </div>
              </div>

              <div className="space-y-4 my-6 text-sm text-gray-300">
                <div className="p-3.5 bg-[#121417]/80 rounded-xl border border-[#2d323b] flex items-start gap-3">
                  <Wrench className="w-4 h-4 text-[#FACC15] shrink-0 mt-0.5" />
                  <div>
                    <h2 className="text-xs font-bold text-white font-mono uppercase tracking-wide">30-Second Fast Capture</h2>
                    <p className="text-[11px] text-gray-400 mt-0.5 leading-relaxed">
                      Rapidly document root-cause fixes, error codes, and field workarounds before shift handoffs.
                    </p>
                  </div>
                </div>

                <div className="p-3.5 bg-[#121417]/80 rounded-xl border border-[#2d323b] flex items-start gap-3">
                  <Sparkles className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <h2 className="text-xs font-bold text-white font-mono uppercase tracking-wide">AI Diagnostic Copilot</h2>
                    <p className="text-[11px] text-gray-400 mt-0.5 leading-relaxed">
                      Instant multi-step triage trees across AMR, Line PLC, Fieldbus, and Logistics equipment.
                    </p>
                  </div>
                </div>

                <div className="p-3.5 bg-[#121417]/80 rounded-xl border border-[#2d323b] flex items-start gap-3">
                  <Shield className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                  <div>
                    <h2 className="text-xs font-bold text-white font-mono uppercase tracking-wide">Role-Based Plant Governance</h2>
                    <p className="text-[11px] text-gray-400 mt-0.5 leading-relaxed">
                      Audited shift verification workflows, LOTO compliance checks, and GET training credentials.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Bottom terminal stats indicator */}
            <div className="pt-4 border-t border-[#242831] flex items-center justify-between text-xs font-mono text-gray-400">
              <div className="flex items-center gap-1.5">
                <Factory className="w-3.5 h-3.5 text-[#FACC15]" />
                <span>GIGA-FACTORY HUB</span>
              </div>
              <span className="text-green-400 font-semibold flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-green-400" />
                ONLINE
              </span>
            </div>
          </div>

          {/* Right Auth Form (Login or Register) */}
          <div className="lg:col-span-7 bg-[#16191f] border border-[#2d323b] rounded-2xl p-6 sm:p-8 flex flex-col shadow-2xl">
            {/* Top Mode Toggle Tabs */}
            <div className="flex items-center bg-[#101215] p-1 rounded-xl border border-[#272b33] mb-6">
              <button
                type="button"
                onClick={() => {
                  setAuthMode("login");
                  setLoginError(null);
                }}
                className={`flex-1 py-2.5 px-4 rounded-lg text-xs font-bold font-mono tracking-wider flex items-center justify-center gap-2 transition-all ${
                  authMode === "login"
                    ? "bg-[#252a33] text-[#FACC15] shadow-sm border border-[#3d424d]"
                    : "text-gray-400 hover:text-white"
                }`}
                id="tab-auth-login"
              >
                <KeyRound className="w-3.5 h-3.5" />
                <span>OPERATOR LOGIN</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setAuthMode("register");
                  setRegError(null);
                }}
                className={`flex-1 py-2.5 px-4 rounded-lg text-xs font-bold font-mono tracking-wider flex items-center justify-center gap-2 transition-all ${
                  authMode === "register"
                    ? "bg-[#252a33] text-[#FACC15] shadow-sm border border-[#3d424d]"
                    : "text-gray-400 hover:text-white"
                }`}
                id="tab-auth-register"
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>REGISTER NEW USER</span>
              </button>
            </div>

            {/* LOGIN FORM */}
            {authMode === "login" && (
              <div className="flex-1 flex flex-col justify-between">
                <div>
                  <div className="mb-5">
                    <h2 className="text-lg font-bold font-mono text-white flex items-center gap-2">
                      <span>Sign In to Terminal</span>
                    </h2>
                    <p className="text-xs text-gray-400 mt-1">
                      Enter your plant credentials, username, or badge ID to begin your shift session.
                    </p>
                  </div>

                  {loginError && (
                    <div className="mb-4 p-3 bg-red-950/70 border border-red-800 rounded-lg text-xs text-red-300 flex items-start gap-2.5 animate-shake">
                      <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-bold">Authentication Error: </span>
                        <span>{loginError}</span>
                      </div>
                    </div>
                  )}

                  <form onSubmit={handleLoginSubmit} className="space-y-4">
                    <div>
                      <label className="block text-xs font-mono font-bold text-gray-300 mb-1.5 uppercase">
                        Username, Email, or Badge ID
                      </label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-500">
                          <UserIcon className="w-4 h-4" />
                        </div>
                        <input
                          type="text"
                          value={loginIdentifier}
                          onChange={(e) => setLoginIdentifier(e.target.value)}
                          placeholder="e.g. admin, d.sterling, or ADM-001"
                          autoComplete="username"
                          className="w-full bg-[#101215] text-white pl-9 pr-3 py-2.5 rounded-lg border border-[#2d323b] focus:border-[#FACC15] focus:ring-1 focus:ring-[#FACC15] focus:outline-none text-xs font-mono placeholder-gray-600 transition-colors"
                          id="input-login-identifier"
                        />
                      </div>
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-1.5">
                        <label className="block text-xs font-mono font-bold text-gray-300 uppercase">
                          Password
                        </label>
                        <span className="text-[10px] text-gray-500 font-mono">
                          Default: <code className="text-gray-400">password123</code>
                        </span>
                      </div>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-500">
                          <Lock className="w-4 h-4" />
                        </div>
                        <input
                          type={showLoginPassword ? "text" : "password"}
                          value={loginPassword}
                          onChange={(e) => setLoginPassword(e.target.value)}
                          placeholder="Enter your security password"
                          autoComplete="current-password"
                          className="w-full bg-[#101215] text-white pl-9 pr-10 py-2.5 rounded-lg border border-[#2d323b] focus:border-[#FACC15] focus:ring-1 focus:ring-[#FACC15] focus:outline-none text-xs font-mono placeholder-gray-600 transition-colors"
                          id="input-login-password"
                        />
                        <button
                          type="button"
                          onClick={() => setShowLoginPassword(!showLoginPassword)}
                          className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-500 hover:text-gray-300"
                        >
                          {showLoginPassword ? (
                            <EyeOff className="w-4 h-4" />
                          ) : (
                            <Eye className="w-4 h-4" />
                          )}
                        </button>
                      </div>
                    </div>

                    <button
                      type="submit"
                      disabled={isLoggingIn}
                      className="w-full bg-[#FACC15] hover:bg-yellow-300 active:bg-yellow-500 text-[#121417] font-bold py-2.5 px-4 rounded-lg font-mono text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all transform active:scale-98 shadow-md border border-yellow-400 mt-2"
                      id="btn-submit-login"
                    >
                      {isLoggingIn ? (
                        <>
                          <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                          <span>AUTHENTICATING SESSION...</span>
                        </>
                      ) : (
                        <>
                          <span>SIGN IN TO WORKSTATION</span>
                          <ArrowRight className="w-4 h-4" />
                        </>
                      )}
                    </button>
                  </form>
                </div>

                {/* Quick 1-Click Demo Profiles */}
                <div className="mt-6 pt-5 border-t border-[#242831]">
                  <div className="flex items-center justify-between mb-2.5">
                    <span className="text-[11px] font-mono font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1.5">
                      <Sparkles className="w-3 h-3 text-[#FACC15]" />
                      Quick 1-Click Demo Accounts:
                    </span>
                    <span className="text-[10px] text-gray-500 font-mono">Password auto-filled</span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {demoUsers.map((item) => {
                      if (!item.user) return null;
                      const u = item.user;
                      const roleMeta = ROLE_CONFIG[u.role];
                      return (
                        <button
                          key={u.id}
                          type="button"
                          onClick={() => handleQuickLogin(u)}
                          className="bg-[#101215] hover:bg-[#20252e] text-left p-2 rounded-lg border border-[#272b33] hover:border-[#FACC15]/50 transition-all flex items-center gap-2 group"
                          title={`Log in as ${u.name} (${roleMeta?.label})`}
                        >
                          <div
                            className="w-6 h-6 rounded flex items-center justify-center text-xs font-bold text-[#121417] font-mono shrink-0"
                            style={{ backgroundColor: u.avatarColor || "#FACC15" }}
                          >
                            {u.name[0]}
                          </div>
                          <div className="min-w-0 flex-1">
                            <p className="text-xs font-bold text-white group-hover:text-[#FACC15] truncate font-mono">
                              {u.name.split(" ")[0]}
                            </p>
                            <p className="text-[9px] text-gray-400 truncate">
                              {roleMeta?.badgeLabel || u.role}
                            </p>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {/* REGISTRATION FORM */}
            {authMode === "register" && (
              <div>
                <div className="mb-4">
                  <h2 className="text-lg font-bold font-mono text-white flex items-center gap-2">
                    <span>New Technician Registration</span>
                  </h2>
                  <p className="text-xs text-gray-400 mt-0.5">
                    Enroll a new operator account with plant credentials, assigned production line, and role privileges.
                  </p>
                </div>

                {regError && (
                  <div className="mb-4 p-3 bg-red-950/70 border border-red-800 rounded-lg text-xs text-red-300 flex items-start gap-2.5 animate-shake">
                    <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold">Registration Error: </span>
                      <span>{regError}</span>
                    </div>
                  </div>
                )}

                <form onSubmit={handleRegisterSubmit} className="space-y-3.5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-mono font-bold text-gray-300 mb-1 uppercase">
                        Full Name *
                      </label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-2.5 flex items-center pointer-events-none text-gray-500">
                          <UserIcon className="w-3.5 h-3.5" />
                        </div>
                        <input
                          type="text"
                          required
                          value={regName}
                          onChange={(e) => {
                            setRegName(e.target.value);
                            if (!regUsername && e.target.value) {
                              const autoUser = e.target.value.toLowerCase().replace(/\s+/g, ".");
                              setRegUsername(autoUser);
                            }
                          }}
                          placeholder="e.g. Jordan Mitchell"
                          className="w-full bg-[#101215] text-white pl-8 pr-3 py-2 rounded-lg border border-[#2d323b] focus:border-[#FACC15] focus:outline-none text-xs font-mono"
                          id="input-reg-name"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] font-mono font-bold text-gray-300 mb-1 uppercase">
                        Username *
                      </label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-2.5 flex items-center pointer-events-none text-gray-500">
                          <span className="text-xs font-mono font-bold text-gray-500">@</span>
                        </div>
                        <input
                          type="text"
                          required
                          value={regUsername}
                          onChange={(e) => setRegUsername(e.target.value.toLowerCase().replace(/[^a-z0-9._-]/g, ""))}
                          placeholder="e.g. j.mitchell"
                          className="w-full bg-[#101215] text-white pl-8 pr-3 py-2 rounded-lg border border-[#2d323b] focus:border-[#FACC15] focus:outline-none text-xs font-mono"
                          id="input-reg-username"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-mono font-bold text-gray-300 mb-1 uppercase">
                        Plant Email Address *
                      </label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-2.5 flex items-center pointer-events-none text-gray-500">
                          <Mail className="w-3.5 h-3.5" />
                        </div>
                        <input
                          type="email"
                          required
                          value={regEmail}
                          onChange={(e) => setRegEmail(e.target.value)}
                          placeholder="j.mitchell@plantops.internal"
                          className="w-full bg-[#101215] text-white pl-8 pr-3 py-2 rounded-lg border border-[#2d323b] focus:border-[#FACC15] focus:outline-none text-xs font-mono"
                          id="input-reg-email"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] font-mono font-bold text-gray-300 mb-1 uppercase">
                        Badge ID (Optional)
                      </label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-2.5 flex items-center pointer-events-none text-gray-500">
                          <IdCard className="w-3.5 h-3.5" />
                        </div>
                        <input
                          type="text"
                          value={regBadgeId}
                          onChange={(e) => setRegBadgeId(e.target.value.toUpperCase())}
                          placeholder="Auto-generated if empty (e.g. TEC-440)"
                          className="w-full bg-[#101215] text-white pl-8 pr-3 py-2 rounded-lg border border-[#2d323b] focus:border-[#FACC15] focus:outline-none text-xs font-mono uppercase"
                          id="input-reg-badge"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-mono font-bold text-gray-300 mb-1 uppercase">
                        Password (min 6 chars) *
                      </label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-2.5 flex items-center pointer-events-none text-gray-500">
                          <Lock className="w-3.5 h-3.5" />
                        </div>
                        <input
                          type={showRegPassword ? "text" : "password"}
                          required
                          value={regPassword}
                          onChange={(e) => setRegPassword(e.target.value)}
                          placeholder="Create strong password"
                          className="w-full bg-[#101215] text-white pl-8 pr-8 py-2 rounded-lg border border-[#2d323b] focus:border-[#FACC15] focus:outline-none text-xs font-mono"
                          id="input-reg-password"
                        />
                        <button
                          type="button"
                          onClick={() => setShowRegPassword(!showRegPassword)}
                          className="absolute inset-y-0 right-0 pr-2.5 flex items-center text-gray-500 hover:text-gray-300"
                        >
                          {showRegPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] font-mono font-bold text-gray-300 mb-1 uppercase">
                        Confirm Password *
                      </label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-2.5 flex items-center pointer-events-none text-gray-500">
                          <Lock className="w-3.5 h-3.5" />
                        </div>
                        <input
                          type={showRegPassword ? "text" : "password"}
                          required
                          value={regConfirmPassword}
                          onChange={(e) => setRegConfirmPassword(e.target.value)}
                          placeholder="Re-enter password"
                          className="w-full bg-[#101215] text-white pl-8 pr-3 py-2 rounded-lg border border-[#2d323b] focus:border-[#FACC15] focus:outline-none text-xs font-mono"
                          id="input-reg-confirm-password"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-mono font-bold text-gray-300 mb-1 uppercase">
                        Plant Role & Privileges *
                      </label>
                      <select
                        value={regRole}
                        onChange={(e) => setRegRole(e.target.value as UserRole)}
                        className="w-full bg-[#101215] text-white px-3 py-2 rounded-lg border border-[#2d323b] focus:border-[#FACC15] focus:outline-none text-xs font-mono"
                        id="select-reg-role"
                      >
                        <option value="GET_TRAINEE">1. Graduate Engineering Trainee (GET)</option>
                        <option value="ASSISTANT_MANAGER">2. Assistant Manager</option>
                        <option value="MANAGER">3. Manager</option>
                        <option value="ADMIN">4. Admin</option>
                        <option value="MAINTENANCE_ENGINEER">5. Maintenance Engineer</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[11px] font-mono font-bold text-gray-300 mb-1 uppercase">
                        Facility Assignment
                      </label>
                      <select
                        value={regFacility}
                        onChange={(e) => setRegFacility(e.target.value)}
                        className="w-full bg-[#101215] text-white px-3 py-2 rounded-lg border border-[#2d323b] focus:border-[#FACC15] focus:outline-none text-xs font-mono"
                        id="select-reg-facility"
                      >
                        {AVAILABLE_FACILITIES.map((fac) => (
                          <option key={fac} value={fac}>
                            {fac}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* Specialties Selector */}
                  <div>
                    <label className="block text-[11px] font-mono font-bold text-gray-300 mb-1.5 uppercase">
                      Domain Specialties / Equipment Certifications
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {(["AMR", "NETWORKING", "COMMISSIONING", "FORKLIFT"] as EquipmentDomain[]).map((dom) => {
                        const isSelected = regSpecialties.includes(dom);
                        return (
                          <button
                            key={dom}
                            type="button"
                            onClick={() => toggleSpecialty(dom)}
                            className={`px-2.5 py-1 rounded-md text-[11px] font-mono font-bold transition-all border ${
                              isSelected
                                ? "bg-[#FACC15] text-[#121417] border-yellow-400 shadow-sm"
                                : "bg-[#101215] text-gray-400 border-[#2d323b] hover:text-white"
                            }`}
                          >
                            {isSelected && <CheckCircle2 className="w-3 h-3 inline mr-1" />}
                            {dom}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={isRegistering}
                    className="w-full bg-[#FACC15] hover:bg-yellow-300 active:bg-yellow-500 text-[#121417] font-bold py-2.5 px-4 rounded-lg font-mono text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all transform active:scale-98 shadow-md border border-yellow-400 mt-4"
                    id="btn-submit-register"
                  >
                    {isRegistering ? (
                      <>
                        <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                        <span>PROVISIONING OPERATOR ACCOUNT...</span>
                      </>
                    ) : (
                      <>
                        <UserPlus className="w-4 h-4" />
                        <span>COMPLETE REGISTRATION & LOG IN</span>
                      </>
                    )}
                  </button>
                </form>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Micro Footer */}
      <div className="bg-[#121417] border-t border-[#242831] px-4 py-2 text-center text-xs font-mono text-gray-500">
        <span>Operation Hub &copy; 2026 Plant Maintenance &amp; Commissioning Intelligence System</span>
      </div>
    </div>
  );
};
