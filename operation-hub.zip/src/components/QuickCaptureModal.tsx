import React, { useState, useRef, useEffect } from "react";
import {
  X,
  Camera,
  Mic,
  MicOff,
  Sparkles,
  Wrench,
  AlertTriangle,
  Clock,
  CheckCircle2,
  Upload,
  Bot,
  Network,
  Forklift,
  Plus,
  Trash2,
  ShieldAlert,
  HelpCircle,
  Smartphone,
} from "lucide-react";
import { EquipmentDomain, Severity, TroubleshootingEntry, ShiftInfo } from "../types";
import { DOMAIN_CONFIG } from "../data/seedEntries";

interface QuickCaptureModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (entry: Omit<TroubleshootingEntry, "id" | "createdAt" | "updatedAt" | "helpfulCount" | "comments" | "syncStatus">) => void;
  shiftInfo: ShiftInfo;
  isOnline: boolean;
}

const SAMPLE_PHOTO_PRESETS = [
  {
    name: "LiDAR Scanner Optic",
    url: "https://images.unsplash.com/photo-1581092335397-9583fe92d232?auto=format&fit=crop&w=600&q=80",
    domain: "AMR",
  },
  {
    name: "Switch RJ45 Ports",
    url: "https://images.unsplash.com/photo-1544197150-b99a580bb7a8?auto=format&fit=crop&w=600&q=80",
    domain: "NETWORKING",
  },
  {
    name: "PLC Terminal Block",
    url: "https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=600&q=80",
    domain: "COMMISSIONING",
  },
  {
    name: "Forklift Inverter/Battery",
    url: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&w=600&q=80",
    domain: "FORKLIFT",
  },
];

export const QuickCaptureModal: React.FC<QuickCaptureModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  shiftInfo,
  isOnline,
}) => {
  if (!isOpen) return null;

  const [domain, setDomain] = useState<EquipmentDomain>("AMR");
  const [equipmentId, setEquipmentId] = useState("AMR-MiR-08");
  const [equipmentModel, setEquipmentModel] = useState("MiR 250 Top Roller");
  const [errorCode, setErrorCode] = useState("");
  const [title, setTitle] = useState("");
  const [subsystem, setSubsystem] = useState("LiDAR & 2D Safety Scanner");
  const [severity, setSeverity] = useState<Severity>("HIGH_DEGRADED");
  const [symptomInput, setSymptomInput] = useState("");
  const [symptoms, setSymptoms] = useState<string[]>([]);
  const [rootCause, setRootCause] = useState("");
  const [steps, setSteps] = useState<string[]>([""]);
  const [tools, setTools] = useState<string[]>([]);
  const [toolInput, setToolInput] = useState("");
  const [safetyPrecaution, setSafetyPrecaution] = useState("Verify machine manual mode & apply standard equipment safety PPE.");
  const [estimatedMinutes, setEstimatedMinutes] = useState(15);
  const [images, setImages] = useState<string[]>([]);
  const [isRecording, setIsRecording] = useState(false);
  const [audioTranscript, setAudioTranscript] = useState("");
  const [isFormattingWithAI, setIsFormattingWithAI] = useState(false);
  const [activeStepTab, setActiveStepTab] = useState<"quick" | "full">("quick");

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Auto update default equipment model & subsystem when domain changes
  const handleDomainChange = (newDomain: EquipmentDomain) => {
    setDomain(newDomain);
    const meta = DOMAIN_CONFIG[newDomain];
    if (meta && meta.subsystems.length > 0) {
      setSubsystem(meta.subsystems[0]);
    }
    if (newDomain === "AMR") {
      setEquipmentId("AMR-MiR-08");
      setEquipmentModel("MiR 250 Top Roller");
    } else if (newDomain === "NETWORKING") {
      setEquipmentId("SW-MOXA-EDS510-03");
      setEquipmentModel("Moxa EDS-510E Managed Switch");
    } else if (newDomain === "COMMISSIONING") {
      setEquipmentId("PLC-SIEMENS-LINE2");
      setEquipmentModel("Siemens S7-1500 Cell 2");
    } else if (newDomain === "FORKLIFT") {
      setEquipmentId("FL-TOYOTA-04");
      setEquipmentModel("Toyota 8FBE20 3-Wheel");
    }
  };

  // Add symptom pill
  const handleAddSymptom = () => {
    if (symptomInput.trim() && !symptoms.includes(symptomInput.trim())) {
      setSymptoms([...symptoms, symptomInput.trim()]);
      setSymptomInput("");
    }
  };

  // Add tool pill
  const handleAddTool = () => {
    if (toolInput.trim() && !tools.includes(toolInput.trim())) {
      setTools([...tools, toolInput.trim()]);
      setToolInput("");
    }
  };

  // Add step line
  const handleAddStep = () => {
    setSteps([...steps, ""]);
  };

  const handleStepChange = (index: number, val: string) => {
    const updated = [...steps];
    updated[index] = val;
    setSteps(updated);
  };

  const handleRemoveStep = (index: number) => {
    if (steps.length > 1) {
      setSteps(steps.filter((_, i) => i !== index));
    }
  };

  // Photo handling
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const file = files[0];
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === "string") {
        setImages([...images, reader.result]);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSelectPresetPhoto = (url: string) => {
    if (!images.includes(url)) {
      setImages([...images, url]);
    }
  };

  // Voice Note Simulation & Web Speech API if supported
  const toggleVoiceRecording = () => {
    if (isRecording) {
      setIsRecording(false);
    } else {
      setIsRecording(true);
      // Simulate live voice transcription after 2.5 seconds if speech recognition is unavailable
      const simText = `Machine halted on line with flashing red LED. We wiped the optical lens with IPA, checked harness seating on pin 4, and reset the fault in controller UI. Unit resumed full speed.`;
      setTimeout(() => {
        setAudioTranscript(simText);
        if (!rootCause) setRootCause(simText);
        setIsRecording(false);
      }, 2500);
    }
  };

  // AI Auto-Format SOP
  const handleAIAutoFormat = async () => {
    const noteText = audioTranscript || rootCause || symptoms.join(". ") || title;
    if (!noteText) {
      alert("Please enter a quick note, symptom, or audio transcription first.");
      return;
    }

    setIsFormattingWithAI(true);
    try {
      const res = await fetch("/api/ai/format-sop", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          rawText: noteText,
          domain,
          equipmentId,
        }),
      });

      const data = await res.json();
      if (data.formatted) {
        if (data.formatted.title && !title) setTitle(data.formatted.title);
        if (data.formatted.rootCause) setRootCause(data.formatted.rootCause);
        if (Array.isArray(data.formatted.steps) && data.formatted.steps.length > 0) {
          setSteps(data.formatted.steps);
        }
        if (data.formatted.safetyNotice) setSafetyPrecaution(data.formatted.safetyNotice);
        if (Array.isArray(data.formatted.toolsRequired)) {
          setTools(Array.from(new Set([...tools, ...data.formatted.toolsRequired])));
        }
      }
    } catch (e) {
      console.error("AI Formatting Error:", e);
    } finally {
      setIsFormattingWithAI(false);
    }
  };

  // Form submit
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const cleanSteps = steps.filter((s) => s.trim().length > 0);
    const finalSteps = cleanSteps.length > 0 ? cleanSteps : ["Inspect hardware and restart unit."];
    const finalTitle = title.trim() || `${domain} Fix: ${errorCode || subsystem}`;

    onSubmit({
      title: finalTitle,
      errorCode: errorCode.trim() || "N/A",
      equipmentId: equipmentId.trim() || "EQUIP-01",
      equipmentModel: equipmentModel.trim() || "Industrial Unit",
      domain,
      subsystem: subsystem.trim() || "General",
      severity,
      symptoms: symptoms.length > 0 ? symptoms : [symptomInput.trim() || "Equipment issue reported"],
      rootCause: rootCause.trim() || "Root cause documented during diagnosis",
      stepsToResolve: finalSteps,
      toolsRequired: tools.length > 0 ? tools : ["Digital Multimeter", "Standard Hand Tools"],
      safetyPrecaution: safetyPrecaution.trim(),
      images,
      author: {
        name: shiftInfo.userName,
        role: shiftInfo.userRole,
        badge: shiftInfo.userRole.includes("GET") ? "GET Author" : "Diagnostic Tech",
      },
      verified: !shiftInfo.userRole.includes("GET"), // Senior tech posts verified by default
      verifiedBy: !shiftInfo.userRole.includes("GET") ? shiftInfo.userName : undefined,
      estimatedFixTimeMinutes: Number(estimatedMinutes) || 15,
      tags: [domain.toLowerCase(), subsystem.toLowerCase().replace(/\s+/g, "-")],
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6">
      <div className="bg-[#1a1d23] text-gray-200 w-full max-w-3xl rounded-2xl shadow-2xl border border-[#2d323b] overflow-hidden flex flex-col max-h-[94vh] animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="bg-[#121417] text-white p-4 sm:p-5 border-b border-[#2d323b] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#FACC15] flex items-center justify-center text-[#121417] font-bold">
              <Camera className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-white uppercase tracking-wider font-mono">Capture Error Fix</h2>
                <span className="text-[10px] bg-[#1a1d23] text-[#FACC15] font-bold px-2 py-0.5 rounded border border-[#3d424d] font-mono">
                  &lt;30 SEC FLOW
                </span>
              </div>
              <p className="text-xs text-gray-400 font-mono">
                Log resolution directly at machine • Auto-caches offline
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-gray-400 hover:text-white hover:bg-[#2d323b] rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-6 overflow-y-auto space-y-5">
          {/* Domain Selector Chips */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-gray-400 mb-2 font-mono">
              1. Select Equipment Domain
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {(["AMR", "NETWORKING", "COMMISSIONING", "FORKLIFT"] as EquipmentDomain[]).map((d) => {
                const isSel = domain === d;
                const meta = DOMAIN_CONFIG[d];
                return (
                  <button
                    key={d}
                    type="button"
                    onClick={() => handleDomainChange(d)}
                    className={`p-2.5 rounded-xl border text-left transition-all flex items-center gap-2 ${
                      isSel
                        ? "bg-[#2d323b] text-white border-[#FACC15] shadow-md ring-1 ring-[#FACC15]/40"
                        : "bg-[#121417] text-gray-300 border-[#2d323b] hover:bg-[#1e2229] hover:border-gray-500"
                    }`}
                  >
                    <span className={`w-2 h-2 rounded-full ${isSel ? "bg-[#FACC15]" : "bg-gray-500"}`} />
                    <span className="text-xs font-bold">{meta.shortCode}</span>
                    <span className="text-[11px] opacity-70 truncate hidden sm:inline">{d}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Equipment ID & Error Code Bar */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-bold text-gray-400 mb-1 font-mono uppercase text-[11px]">
                Equipment ID / Tag
              </label>
              <input
                type="text"
                value={equipmentId}
                onChange={(e) => setEquipmentId(e.target.value)}
                placeholder="e.g. AMR-MiR-08"
                className="w-full text-xs font-mono font-bold bg-[#121417] text-white border border-[#3d424d] rounded-lg p-2.5 focus:border-[#FACC15] focus:ring-1 focus:ring-[#FACC15] focus:outline-none"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-400 mb-1 font-mono uppercase text-[11px]">
                Error Code (if any)
              </label>
              <input
                type="text"
                value={errorCode}
                onChange={(e) => setErrorCode(e.target.value)}
                placeholder="e.g. ERR-E301 or CURTIS_55"
                className="w-full text-xs font-mono font-bold bg-[#121417] text-white border border-[#3d424d] rounded-lg p-2.5 focus:border-[#FACC15] focus:ring-1 focus:ring-[#FACC15] focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-400 mb-1 font-mono uppercase text-[11px]">
                Subsystem
              </label>
              <select
                value={subsystem}
                onChange={(e) => setSubsystem(e.target.value)}
                className="w-full text-xs bg-[#121417] text-gray-200 border border-[#3d424d] rounded-lg p-2.5 focus:border-[#FACC15] focus:outline-none font-mono"
              >
                <option value="None">None / General</option>
                {DOMAIN_CONFIG[domain]?.subsystems.map((sub) => (
                  <option key={sub} value={sub}>
                    {sub}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Quick Title */}
          <div>
            <label className="block text-xs font-bold text-gray-400 mb-1 font-mono uppercase text-[11px]">
              Issue / Fix Title
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. LiDAR Scanner Blinded by Retro-Reflective Vest in Aisle 4"
              className="w-full text-xs sm:text-sm font-semibold bg-[#121417] text-white border border-[#3d424d] rounded-lg p-2.5 focus:border-[#FACC15] focus:ring-1 focus:ring-[#FACC15] focus:outline-none"
              required
            />
          </div>

          {/* Fast Voice / Audio Note or Quick Raw Note with AI SOP Formatter */}
          <div className="bg-[#121417] border border-[#2d323b] rounded-xl p-3.5 space-y-2">
            <div className="flex items-center justify-between gap-2">
              <label className="text-xs font-bold text-gray-200 flex items-center gap-1.5 font-mono uppercase text-[11px]">
                <span>Quick Voice / Audio Issue Memo</span>
                <span className="text-[10px] text-gray-500 font-normal font-sans lowercase">
                  (Speak or type raw notes, then 1-click AI SOP)
                </span>
              </label>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={toggleVoiceRecording}
                  className={`text-xs px-2.5 py-1 rounded font-bold uppercase tracking-wider flex items-center gap-1 transition-all ${
                    isRecording
                      ? "bg-rose-600 text-white animate-pulse"
                      : "bg-[#2d323b] text-gray-200 hover:bg-[#3d424d] border border-[#3d424d]"
                  }`}
                >
                  {isRecording ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5 text-rose-500" />}
                  <span>{isRecording ? "Recording Audio..." : "Voice Memo"}</span>
                </button>

                <button
                  type="button"
                  onClick={handleAIAutoFormat}
                  disabled={isFormattingWithAI}
                  className="text-xs bg-blue-600 hover:bg-blue-500 active:bg-blue-700 text-white px-2.5 py-1 rounded font-bold uppercase tracking-wider flex items-center gap-1 transition-colors shadow-sm disabled:opacity-50"
                  title="Transform raw notes into clean technical steps & LOTO rules"
                >
                  <Sparkles className="w-3.5 h-3.5 text-[#FACC15]" />
                  <span>{isFormattingWithAI ? "Formatting..." : "AI Auto-SOP"}</span>
                </button>
              </div>
            </div>

            <textarea
              value={audioTranscript || rootCause}
              onChange={(e) => {
                setAudioTranscript(e.target.value);
                setRootCause(e.target.value);
              }}
              placeholder="e.g. Contactor coil flyback diode burned. Discharged 48V DC bus with 100-ohm resistor, replaced Albright 24V contactor, cleared code 55..."
              rows={2}
              className="w-full text-xs border border-[#3d424d] rounded-lg p-2.5 focus:border-[#FACC15] focus:outline-none bg-[#1a1d23] text-white placeholder:text-gray-500"
            />
          </div>

          {/* Photo Upload & Presets */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold text-gray-400 flex items-center gap-1.5 font-mono uppercase text-[11px]">
                <Camera className="w-3.5 h-3.5 text-gray-500" />
                <span>Attach Machine Photo / Wiring Diagram</span>
              </label>

              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                capture="environment"
                onChange={handleFileUpload}
                className="hidden"
              />

              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="text-xs font-bold text-[#FACC15] hover:text-yellow-300 flex items-center gap-1 uppercase font-mono"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Take Photo / Upload</span>
              </button>
            </div>

            {/* Photo thumbnails preview */}
            {images.length > 0 && (
              <div className="flex flex-wrap gap-2 mb-2">
                {images.map((img, idx) => (
                  <div key={idx} className="relative w-20 h-20 rounded-lg overflow-hidden border border-[#3d424d] group">
                    <img src={img} alt="Capture" className="w-full h-full object-cover" />
                    <button
                      type="button"
                      onClick={() => setImages(images.filter((_, i) => i !== idx))}
                      className="absolute top-1 right-1 bg-black/80 text-white rounded p-0.5 hover:bg-rose-600"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* Sample photo presets for rapid testing */}
            <div className="flex flex-wrap items-center gap-1.5 text-[11px] text-gray-400 font-mono">
              <span className="font-medium text-gray-500">Quick Presets:</span>
              {SAMPLE_PHOTO_PRESETS.map((preset, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => handleSelectPresetPhoto(preset.url)}
                  className="px-2 py-0.5 bg-[#121417] hover:bg-[#252a33] text-gray-300 rounded border border-[#2d323b] hover:border-gray-500 text-[11px]"
                >
                  +{preset.name}
                </button>
              ))}
            </div>
          </div>

          {/* Resolution Steps Builder */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-bold text-gray-200 flex items-center gap-1.5 font-mono uppercase text-[11px]">
                <Wrench className="w-3.5 h-3.5 text-gray-500" />
                <span>Resolution Steps</span>
              </label>

              <button
                type="button"
                onClick={handleAddStep}
                className="text-xs font-bold text-[#FACC15] hover:text-yellow-300 flex items-center gap-1 font-mono uppercase"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Step</span>
              </button>
            </div>

            <div className="space-y-2">
              {steps.map((step, idx) => (
                <div key={idx} className="flex items-center gap-2">
                  <span className="text-xs font-mono font-bold bg-[#121417] text-gray-300 px-2 py-2 rounded-lg border border-[#2d323b] shrink-0">
                    #{idx + 1}
                  </span>
                  <input
                    type="text"
                    value={step}
                    onChange={(e) => handleStepChange(idx, e.target.value)}
                    placeholder={`e.g. Step ${idx + 1}: Check 24V supply and clean lens...`}
                    className="flex-1 text-xs bg-[#121417] text-white border border-[#3d424d] rounded-lg p-2 focus:border-[#FACC15] focus:outline-none placeholder:text-gray-500"
                  />
                  {steps.length > 1 && (
                    <button
                      type="button"
                      onClick={() => handleRemoveStep(idx)}
                      className="text-gray-500 hover:text-rose-500 p-1"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Tools & Safety LOTO */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-gray-400 mb-1 font-mono uppercase text-[11px]">
                Tools & Parts Used
              </label>
              <div className="flex items-center gap-1.5 mb-1.5">
                <input
                  type="text"
                  value={toolInput}
                  onChange={(e) => setToolInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      handleAddTool();
                    }
                  }}
                  placeholder="e.g. Fluke Multimeter, 10mm socket..."
                  className="flex-1 text-xs bg-[#121417] text-white border border-[#3d424d] rounded-lg p-2 focus:border-[#FACC15] focus:outline-none placeholder:text-gray-500"
                />
                <button
                  type="button"
                  onClick={handleAddTool}
                  className="bg-[#2d323b] hover:bg-[#3d424d] text-white text-xs font-bold px-2.5 py-2 rounded-lg border border-[#3d424d] uppercase font-mono"
                >
                  Add
                </button>
              </div>

              {tools.length > 0 && (
                <div className="flex flex-wrap gap-1">
                  {tools.map((t, idx) => (
                    <span
                      key={idx}
                      className="text-[11px] bg-[#121417] text-gray-200 px-2 py-0.5 rounded-full border border-[#2d323b] flex items-center gap-1 font-mono"
                    >
                      {t}
                      <button
                        type="button"
                        onClick={() => setTools(tools.filter((_, i) => i !== idx))}
                        className="text-gray-500 hover:text-rose-400"
                      >
                        ×
                      </button>
                    </span>
                  ))}
                </div>
              )}
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-400 mb-1 font-mono uppercase text-[11px]">
                LOTO / Safety Precaution
              </label>
              <input
                type="text"
                value={safetyPrecaution}
                onChange={(e) => setSafetyPrecaution(e.target.value)}
                placeholder="e.g. LOTO 48V DC battery before probing busbars."
                className="w-full text-xs bg-[#121417] text-white border border-[#3d424d] rounded-lg p-2 focus:border-rose-500 focus:outline-none placeholder:text-gray-500"
              />
            </div>
          </div>
        </form>

        {/* Bottom Publish Actions */}
        <div className="bg-[#121417] p-4 border-t border-[#2d323b] flex flex-wrap items-center justify-between gap-3">
          <div className="text-xs text-gray-400 font-mono">
            {isOnline ? (
              <span className="text-green-400 font-medium flex items-center gap-1">
                <CheckCircle2 className="w-4 h-4 text-green-400" />
                Will sync live across all connected devices
              </span>
            ) : (
              <span className="text-[#FACC15] font-bold flex items-center gap-1">
                <Smartphone className="w-4 h-4 text-[#FACC15]" />
                Saving to offline cache (will auto-sync when online)
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs sm:text-sm font-bold uppercase tracking-wider text-gray-400 hover:text-white transition-colors"
            >
              Cancel
            </button>

            <button
              type="button"
              onClick={handleSubmit}
              className="bg-[#FACC15] hover:bg-yellow-300 active:bg-yellow-500 text-[#121417] text-xs sm:text-sm font-bold uppercase tracking-wider px-5 py-2 rounded-lg transition-all shadow-md flex items-center gap-1.5"
              id="btn-publish-fix"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Publish to Error & Issue KB</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
