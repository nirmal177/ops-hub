import React from "react";
import {
  Wrench,
  Wifi,
  WifiOff,
  RefreshCw,
  Plus,
  Sparkles,
  GraduationCap,
  Layers,
  Search,
  CheckCircle2,
  FileSpreadsheet,
  Download,
  Shield,
  Users,
  ChevronDown,
  LogOut,
} from "lucide-react";
import { EquipmentDomain, ShiftInfo, User } from "../types";
import { ROLE_CONFIG } from "../data/seedUsers";

interface HeaderProps {
  activeTab: "search" | "capture" | "copilot" | "training" | "analytics" | "admin";
  setActiveTab: (tab: "search" | "capture" | "copilot" | "training" | "analytics" | "admin") => void;
  isOnline: boolean;
  pendingSyncCount: number;
  onManualSync: () => void;
  isSyncing: boolean;
  onOpenQuickCapture: () => void;
  shiftInfo: ShiftInfo;
  currentUser: User;
  onOpenUserSwitcher: () => void;
  totalEntriesCount: number;
  verifiedRate: number;
  unverifiedCount: number;
  onExport: () => void;
  onLogout?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  isOnline,
  pendingSyncCount,
  onManualSync,
  isSyncing,
  onOpenQuickCapture,
  shiftInfo,
  currentUser,
  onOpenUserSwitcher,
  totalEntriesCount,
  verifiedRate,
  unverifiedCount,
  onExport,
  onLogout,
}) => {
  const roleMeta = ROLE_CONFIG[currentUser.role];
  const isAdminOrLead = currentUser.role === "ADMIN" || currentUser.role === "MANAGER";

  return (
    <header className="bg-[#1a1d23] border-b border-[#2d323b] sticky top-0 z-30 text-gray-200">
      {/* Top micro-bar: Terminal ID, Facility & Active Operator info */}
      <div className="bg-[#121417] px-4 sm:px-6 py-1.5 border-b border-[#2d323b] text-xs flex flex-wrap items-center justify-between gap-2 text-gray-400 font-mono">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <span className="text-[10px] text-gray-500 uppercase font-bold tracking-wider">Terminal ID:</span>
            <span className="text-xs text-[#FACC15] font-bold">PLANT-{currentUser.facility.replace("GIGA-FACTORY-", "FX-")}-{currentUser.line.replace(/[^0-9]/g, "") || "4"}</span>
          </div>
          <span className="text-[#2d323b]">|</span>
          <button
            onClick={onOpenUserSwitcher}
            className="hover:text-[#FACC15] transition-all flex items-center gap-2 text-gray-300 text-xs font-sans group bg-[#1a1d23] hover:bg-[#252a33] px-2 py-0.5 rounded border border-[#2d323b] hover:border-gray-500"
            title="Click to Switch Active User Profile / Badge ID"
            id="btn-header-user-switcher"
          >
            <div
              className="w-4 h-4 rounded text-[9px] font-bold text-[#121417] flex items-center justify-center font-mono shrink-0"
              style={{ backgroundColor: currentUser.avatarColor || "#FACC15" }}
            >
              {currentUser.name[0]}
            </div>
            <span className="font-semibold text-white group-hover:text-[#FACC15]">{currentUser.name}</span>
            <span
              className={`text-[9px] font-mono font-bold px-1 rounded border ${
                roleMeta?.badgeBg || "bg-[#121417]"
              } text-[#FACC15] ${roleMeta?.badgeBorder || "border-[#3d424d]"}`}
            >
              {roleMeta?.badgeLabel || currentUser.role}
            </span>
            <ChevronDown className="w-3 h-3 text-gray-500 group-hover:text-white" />
          </button>
        </div>

        <div className="flex items-center gap-3 sm:gap-4">
          <div className="flex items-center gap-2">
            {isOnline ? (
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.6)] animate-pulse" />
                <span className="text-[11px] font-medium text-gray-300 hidden sm:inline">System Online</span>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-amber-500 shadow-[0_0_8px_rgba(245,158,11,0.6)]" />
                <span className="text-[11px] font-bold text-amber-400 bg-amber-950/60 px-1.5 py-0.5 rounded border border-amber-800">
                  OFFLINE CACHE ({pendingSyncCount})
                </span>
              </div>
            )}

            {pendingSyncCount > 0 && (
              <button
                onClick={onManualSync}
                disabled={isSyncing}
                className="inline-flex items-center gap-1 text-[11px] bg-[#FACC15] hover:bg-yellow-300 active:bg-yellow-500 text-[#121417] px-2 py-0.5 rounded font-bold transition-colors uppercase"
              >
                <RefreshCw className={`w-3 h-3 ${isSyncing ? "animate-spin" : ""}`} />
                <span>Sync {pendingSyncCount}</span>
              </button>
            )}
          </div>

          <div className="hidden lg:flex items-center gap-3 text-[11px] text-gray-400">
            <span>Verified: <strong className="text-green-400">{verifiedRate}%</strong></span>
            <span>Total: <strong className="text-white">{totalEntriesCount}</strong></span>
          </div>

          <button
            onClick={onExport}
            className="hover:text-[#FACC15] text-gray-400 px-2 py-0.5 rounded border border-[#2d323b] bg-[#1a1d23] hover:border-gray-500 flex items-center gap-1.5 transition-colors text-[11px] font-mono"
            title="Export Complete Operation Hub KB as JSON"
          >
            <Download className="w-3 h-3" />
            <span className="hidden sm:inline">EXPORT</span>
          </button>

          {onLogout && (
            <button
              onClick={onLogout}
              className="hover:text-red-400 text-gray-400 px-2 py-0.5 rounded border border-[#2d323b] bg-[#1a1d23] hover:border-red-900/80 hover:bg-red-950/40 flex items-center gap-1.5 transition-colors text-[11px] font-mono"
              title="Log out and lock workstation session"
              id="btn-header-logout"
            >
              <LogOut className="w-3 h-3 text-red-400" />
              <span className="hidden sm:inline">LOCK / LOGOUT</span>
            </button>
          )}
        </div>
      </div>

      {/* Main navigation header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3">
        <div className="flex items-center justify-between gap-3">
          {/* Logo and Brand */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-[#FACC15] rounded-lg flex items-center justify-center text-[#121417] font-bold text-lg shadow-sm font-mono">
              OH
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base sm:text-lg font-bold tracking-tight text-white flex items-center gap-1.5 font-mono uppercase">
                  Operation <span className="text-[#FACC15]">Hub</span>
                </h1>
                <span className="px-2 py-0.5 rounded text-[10px] bg-blue-900/30 text-blue-400 border border-blue-800 font-mono">
                  v4.12.0
                </span>
              </div>
              <p className="text-[11px] text-gray-400 hidden sm:block font-mono">
                EQUIPMENT DIAGNOSTICS & ISSUE RESOLUTION ENGINE
              </p>
            </div>
          </div>

          {/* Action Hub */}
          <div className="flex items-center gap-2 sm:gap-3">
            <button
              onClick={onOpenQuickCapture}
              className="bg-[#FACC15] hover:bg-yellow-300 active:bg-yellow-500 text-[#121417] font-bold text-xs uppercase tracking-wider px-3.5 sm:px-4 py-2 rounded-lg shadow-sm flex items-center gap-1.5 transition-all transform active:scale-95 border border-yellow-400"
              id="btn-quick-capture-header"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              <span>Capture Issue Fix <span className="hidden md:inline text-[10px] font-mono">(&lt;30S)</span></span>
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 sm:gap-2 mt-3 pt-2 border-t border-[#2d323b] overflow-x-auto no-scrollbar">
          <button
            onClick={() => setActiveTab("search")}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-2 whitespace-nowrap border ${
              activeTab === "search"
                ? "bg-[#2d323b] text-white border-[#FACC15] shadow-sm"
                : "bg-[#121417] text-gray-400 border-[#2d323b] hover:text-white hover:border-gray-500"
            }`}
          >
            <Search className={`w-3.5 h-3.5 ${activeTab === "search" ? "text-[#FACC15]" : ""}`} />
            <span>Search & Resolve</span>
          </button>

          <button
            onClick={() => setActiveTab("copilot")}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-2 whitespace-nowrap border ${
              activeTab === "copilot"
                ? "bg-[#2d323b] text-white border-[#FACC15] shadow-sm"
                : "bg-[#121417] text-gray-400 border-[#2d323b] hover:text-white hover:border-gray-500"
            }`}
          >
            <Sparkles className={`w-3.5 h-3.5 ${activeTab === "copilot" ? "text-[#FACC15]" : "text-amber-400"}`} />
            <span>AI Error Copilot</span>
            <span className="text-[9px] bg-blue-950 text-blue-300 font-mono px-1 py-0.2 rounded border border-blue-800">
              FAST TREE
            </span>
          </button>

          <button
            onClick={() => setActiveTab("training")}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-2 whitespace-nowrap border ${
              activeTab === "training"
                ? "bg-[#2d323b] text-white border-[#FACC15] shadow-sm"
                : "bg-[#121417] text-gray-400 border-[#2d323b] hover:text-white hover:border-gray-500"
            }`}
          >
            <GraduationCap className={`w-3.5 h-3.5 ${activeTab === "training" ? "text-[#FACC15]" : "text-amber-400"}`} />
            <span>GET Hub & SOPs</span>
          </button>

          <button
            onClick={() => setActiveTab("analytics")}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-2 whitespace-nowrap border ${
              activeTab === "analytics"
                ? "bg-[#2d323b] text-white border-[#FACC15] shadow-sm"
                : "bg-[#121417] text-gray-400 border-[#2d323b] hover:text-white hover:border-gray-500"
            }`}
          >
            <Layers className={`w-3.5 h-3.5 ${activeTab === "analytics" ? "text-[#FACC15]" : ""}`} />
            <span>Error & Issue Analytics</span>
          </button>

          {/* Admin & User Management Tab */}
          <button
            onClick={() => setActiveTab("admin")}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-2 whitespace-nowrap border ${
              activeTab === "admin"
                ? "bg-[#2d323b] text-white border-[#FACC15] shadow-sm ring-1 ring-[#FACC15]/30"
                : "bg-[#121417] text-gray-400 border-[#2d323b] hover:text-white hover:border-gray-500"
            }`}
          >
            <Shield className={`w-3.5 h-3.5 ${activeTab === "admin" ? "text-[#FACC15]" : "text-yellow-400"}`} />
            <span>Admin & Staff</span>
            {unverifiedCount > 0 && (
              <span className="text-[9px] bg-yellow-950 text-yellow-400 font-mono px-1 py-0.2 rounded border border-yellow-800 font-bold">
                {unverifiedCount}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};

