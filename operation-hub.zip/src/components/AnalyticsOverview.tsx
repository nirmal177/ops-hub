import React from "react";
import {
  TrendingUp,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Bot,
  Network,
  Wrench,
  Forklift,
  Layers,
  ArrowUpRight,
  ShieldCheck,
} from "lucide-react";
import { TroubleshootingEntry, EquipmentDomain } from "../types";
import { DOMAIN_CONFIG } from "../data/seedEntries";

interface AnalyticsOverviewProps {
  entries: TroubleshootingEntry[];
  onSelectErrorCode: (code: string) => void;
  onSelectDomain: (domain: EquipmentDomain) => void;
}

export const AnalyticsOverview: React.FC<AnalyticsOverviewProps> = ({
  entries,
  onSelectErrorCode,
  onSelectDomain,
}) => {
  // Domain breakdown
  const domainStats = (["AMR", "NETWORKING", "COMMISSIONING", "FORKLIFT"] as EquipmentDomain[]).map((d) => {
    const list = entries.filter((e) => e.domain === d);
    const verified = list.filter((e) => e.verified).length;
    const avgMinutes = list.length > 0
      ? Math.round(list.reduce((acc, curr) => acc + curr.estimatedFixTimeMinutes, 0) / list.length)
      : 0;

    return {
      domain: d,
      meta: DOMAIN_CONFIG[d],
      count: list.length,
      verified,
      verifiedPct: list.length > 0 ? Math.round((verified / list.length) * 100) : 0,
      avgMinutes,
    };
  });

  // Top Error Codes
  const errorCodeCounts: Record<string, { code: string; domain: EquipmentDomain; count: number; title: string }> = {};
  entries.forEach((e) => {
    if (e.errorCode && e.errorCode !== "N/A") {
      if (!errorCodeCounts[e.errorCode]) {
        errorCodeCounts[e.errorCode] = { code: e.errorCode, domain: e.domain, count: 0, title: e.title };
      }
      errorCodeCounts[e.errorCode].count += 1 + e.helpfulCount;
    }
  });

  const topErrorCodes = Object.values(errorCodeCounts)
    .sort((a, b) => b.count - a.count)
    .slice(0, 5);

  const totalHelpfulVotes = entries.reduce((acc, curr) => acc + curr.helpfulCount, 0);
  const totalVerified = entries.filter((e) => e.verified).length;
  const overallVerifiedRate = entries.length > 0 ? Math.round((totalVerified / entries.length) * 100) : 0;
  const overallAvgMTTR = entries.length > 0
    ? Math.round(entries.reduce((acc, curr) => acc + curr.estimatedFixTimeMinutes, 0) / entries.length)
    : 0;

  return (
    <div className="space-y-6">
      {/* Top High-Impact KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#1a1d23] p-5 rounded-xl border border-[#2d323b] shadow-sm">
          <span className="text-xs font-bold uppercase tracking-wider text-gray-400 block font-mono text-[11px]">
            Solutions Logged
          </span>
          <div className="flex items-baseline justify-between mt-2">
            <span className="text-3xl font-extrabold text-white font-mono">
              {entries.length}
            </span>
            <span className="text-xs font-bold text-green-400 bg-green-950/60 px-2 py-0.5 rounded border border-green-800 font-mono">
              100% Offline Ready
            </span>
          </div>
          <p className="text-xs text-gray-400 mt-2 font-mono">
            Across 4 core factory domains
          </p>
        </div>

        <div className="bg-[#1a1d23] p-5 rounded-xl border border-[#2d323b] shadow-sm">
          <span className="text-xs font-bold uppercase tracking-wider text-gray-400 block font-mono text-[11px]">
            Mean Time To Resolve (MTTR)
          </span>
          <div className="flex items-baseline justify-between mt-2">
            <span className="text-3xl font-extrabold text-[#FACC15] font-mono">
              ~{overallAvgMTTR}m
            </span>
            <span className="text-xs font-bold text-yellow-300 bg-yellow-950/60 px-2 py-0.5 rounded border border-yellow-800 flex items-center gap-0.5 font-mono">
              <Clock className="w-3 h-3" /> Field Avg
            </span>
          </div>
          <p className="text-xs text-gray-400 mt-2 font-mono">
            From error trip to line restart
          </p>
        </div>

        <div className="bg-[#1a1d23] p-5 rounded-xl border border-[#2d323b] shadow-sm">
          <span className="text-xs font-bold uppercase tracking-wider text-gray-400 block font-mono text-[11px]">
            Lead Verification Rate
          </span>
          <div className="flex items-baseline justify-between mt-2">
            <span className="text-3xl font-extrabold text-green-400 font-mono">
              {overallVerifiedRate}%
            </span>
            <span className="text-xs font-bold text-green-400 bg-green-950/60 px-2 py-0.5 rounded border border-green-800 font-mono">
              {totalVerified} Verified
            </span>
          </div>
          <p className="text-xs text-gray-400 mt-2 font-mono">
            Peer-reviewed by Shift Leads
          </p>
        </div>

        <div className="bg-[#1a1d23] p-5 rounded-xl border border-[#2d323b] shadow-sm">
          <span className="text-xs font-bold uppercase tracking-wider text-gray-400 block font-mono text-[11px]">
            Issue Validation Upvotes
          </span>
          <div className="flex items-baseline justify-between mt-2">
            <span className="text-3xl font-extrabold text-[#FACC15] font-mono">
              {totalHelpfulVotes}
            </span>
            <span className="text-xs font-bold text-yellow-300 bg-yellow-950/60 px-2 py-0.5 rounded border border-yellow-800 font-mono">
              Active Shift
            </span>
          </div>
          <p className="text-xs text-gray-400 mt-2 font-mono">
            "Works on My Machine" votes
          </p>
        </div>
      </div>

      {/* Domain Breakdown Grid */}
      <div className="bg-[#1a1d23] rounded-xl p-5 sm:p-6 border border-[#2d323b] shadow-sm space-y-4">
        <h3 className="text-base font-bold text-white flex items-center gap-2 font-mono uppercase tracking-wider">
          <Layers className="w-5 h-5 text-gray-400" />
          <span>Domain Resolution Efficiency & MTTR Matrix</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {domainStats.map((item) => (
            <div
              key={item.domain}
              onClick={() => onSelectDomain(item.domain)}
              className="p-4 rounded-xl border border-[#2d323b] bg-[#121417] hover:bg-[#1e2229] hover:border-[#FACC15] hover:shadow-md transition-all cursor-pointer group"
            >
              <div className="flex items-center justify-between gap-2 mb-2">
                <span className={`text-xs font-bold px-2 py-0.5 rounded border font-mono ${item.meta.badgeClass}`}>
                  {item.meta.shortCode}
                </span>
                <span className="text-xs font-mono font-bold text-gray-300">
                  {item.count} Fixes
                </span>
              </div>

              <h4 className="text-xs sm:text-sm font-bold text-white group-hover:text-[#FACC15] transition-colors">
                {item.meta.label}
              </h4>

              <div className="mt-3 pt-3 border-t border-[#2d323b] space-y-1.5 text-xs text-gray-400 font-mono">
                <div className="flex justify-between">
                  <span>Avg Repair Time:</span>
                  <strong className="text-white font-mono">~{item.avgMinutes} min</strong>
                </div>
                <div className="flex justify-between">
                  <span>Verified Rate:</span>
                  <strong className="text-green-400 font-mono">{item.verifiedPct}%</strong>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Most Frequent Error Codes Leaderboard */}
      <div className="bg-[#1a1d23] rounded-xl p-5 sm:p-6 border border-[#2d323b] shadow-sm space-y-4">
        <h3 className="text-base font-bold text-white flex items-center gap-2 font-mono uppercase tracking-wider">
          <TrendingUp className="w-5 h-5 text-[#FACC15]" />
          <span>Top Recurring Error & Issue Codes</span>
        </h3>

        <div className="space-y-2.5">
          {topErrorCodes.map((item, idx) => (
            <div
              key={item.code}
              onClick={() => onSelectErrorCode(item.code)}
              className="p-3.5 rounded-xl border border-[#2d323b] bg-[#121417] hover:bg-[#1e2229] hover:border-[#FACC15] transition-all flex items-center justify-between gap-3 cursor-pointer group"
            >
              <div className="flex items-center gap-3">
                <span className="w-6 h-6 rounded bg-[#2d323b] text-[#FACC15] font-mono font-bold text-xs flex items-center justify-center shrink-0 border border-[#3d424d]">
                  #{idx + 1}
                </span>
                <div>
                  <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-[#2d323b] text-[#FACC15] border border-[#3d424d] mr-2">
                    {item.code}
                  </span>
                  <span className="text-xs sm:text-sm font-bold text-gray-200 group-hover:text-[#FACC15] transition-colors">
                    {item.title}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-semibold text-gray-400 bg-[#1a1d23] px-2.5 py-1 rounded border border-[#2d323b]">
                  {item.count} activity pts
                </span>
                <ArrowUpRight className="w-4 h-4 text-gray-400 group-hover:text-[#FACC15] transition-colors" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
