import React, { useState } from "react";
import {
  X,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Wrench,
  ThumbsUp,
  Printer,
  ShieldAlert,
  Share2,
  Bot,
  Network,
  Forklift,
  User as UserIcon,
  MessageSquare,
  Send,
  Sparkles,
  ChevronRight,
  ExternalLink,
  CheckSquare,
  Square,
  Shield,
  Trash2,
  Check,
} from "lucide-react";
import { TroubleshootingEntry, EquipmentDomain, ShiftInfo, User } from "../types";
import { DOMAIN_CONFIG } from "../data/seedEntries";

interface EntryDetailModalProps {
  entry: TroubleshootingEntry | null;
  onClose: () => void;
  onToggleHelpful: (entryId: string, e: React.MouseEvent) => void;
  onAddComment: (entryId: string, comment: { author: string; role: string; text: string; workedForUser: boolean }) => void;
  shiftInfo: ShiftInfo;
  currentUser?: User;
  onVerifyEntry?: (entryId: string) => void;
  onUnverifyEntry?: (entryId: string) => void;
  onDeleteEntry?: (entryId: string) => void;
  onOpenAIWithContext?: (entry: TroubleshootingEntry) => void;
}

export const EntryDetailModal: React.FC<EntryDetailModalProps> = ({
  entry,
  onClose,
  onToggleHelpful,
  onAddComment,
  shiftInfo,
  currentUser,
  onVerifyEntry,
  onUnverifyEntry,
  onDeleteEntry,
  onOpenAIWithContext,
}) => {
  if (!entry) return null;

  const [completedSteps, setCompletedSteps] = useState<number[]>([]);
  const [commentText, setCommentText] = useState("");
  const [commentWorked, setCommentWorked] = useState(true);
  const [copiedLink, setCopiedLink] = useState(false);

  const domainConfig = DOMAIN_CONFIG[entry.domain] || DOMAIN_CONFIG.AMR;
  const canVerify =
    currentUser?.role === "ADMIN" ||
    currentUser?.role === "MANAGER" ||
    currentUser?.role === "ASSISTANT_MANAGER" ||
    currentUser?.role === "MAINTENANCE_ENGINEER";
  const canDelete = currentUser?.role === "ADMIN" || currentUser?.role === "MANAGER";

  const toggleStep = (index: number) => {
    setCompletedSteps((prev) =>
      prev.includes(index) ? prev.filter((i) => i !== index) : [...prev, index]
    );
  };

  const handleCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) return;

    onAddComment(entry.id, {
      author: currentUser ? currentUser.name : shiftInfo.userName,
      role: currentUser ? currentUser.role : shiftInfo.userRole,
      text: commentText.trim(),
      workedForUser: commentWorked,
    });

    setCommentText("");
  };

  const handlePrint = () => {
    window.print();
  };

  const handleCopyShare = () => {
    const text = `[Error & Issue KB] ${entry.errorCode ? entry.errorCode + " - " : ""}${entry.title} (${entry.equipmentId})`;
    navigator.clipboard.writeText(text);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const allStepsComplete = completedSteps.length === entry.stepsToResolve.length;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6">
      <div className="bg-[#1a1d23] text-gray-200 w-full max-w-4xl rounded-2xl shadow-2xl border border-[#2d323b] overflow-hidden flex flex-col max-h-[92vh] animate-in fade-in zoom-in-95 duration-150">
        {/* Header Bar */}
        <div className="bg-[#121417] text-white p-4 sm:p-6 border-b border-[#2d323b] flex items-start justify-between gap-4">
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-2">
              <span className={`inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-0.5 rounded-full border ${domainConfig.badgeClass}`}>
                {domainConfig.shortCode}
              </span>

              {entry.errorCode && entry.errorCode !== "N/A" && (
                <span className="font-mono text-xs font-bold px-2.5 py-0.5 rounded bg-[#FACC15] text-[#121417]">
                  {entry.errorCode}
                </span>
              )}

              <span className="font-mono text-xs text-gray-300 bg-[#1e2229] px-2 py-0.5 rounded border border-[#2d323b]">
                {entry.equipmentId}
              </span>

              {entry.verified ? (
                <span className="inline-flex items-center gap-1 text-xs font-bold text-green-400 bg-green-950/60 px-2 py-0.5 rounded border border-green-800 uppercase font-mono">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  VERIFIED SOLUTION
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 text-xs font-bold text-yellow-400 bg-yellow-950/60 px-2 py-0.5 rounded border border-yellow-800 uppercase font-mono">
                  FIELD DRAFT (UNVERIFIED)
                </span>
              )}
            </div>

            <h2 className="text-xl sm:text-2xl font-bold text-white leading-tight">
              {entry.title}
            </h2>

            <p className="text-xs sm:text-sm text-gray-400 mt-1 font-mono">
              {entry.equipmentModel} • Subsystem: <span className="text-gray-200">{entry.subsystem}</span>
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="p-2 text-gray-400 hover:text-white hover:bg-[#2d323b] rounded-lg transition-colors border border-transparent hover:border-[#3d424d]"
              title="Print 1-Page Equipment Work Order / Checklist"
            >
              <Printer className="w-5 h-5" />
            </button>

            <button
              onClick={handleCopyShare}
              className="p-2 text-gray-400 hover:text-white hover:bg-[#2d323b] rounded-lg transition-colors border border-transparent hover:border-[#3d424d]"
              title="Copy Summary Link"
            >
              <Share2 className="w-5 h-5" />
            </button>

            <button
              onClick={onClose}
              className="p-2 text-gray-400 hover:text-white hover:bg-[#2d323b] rounded-lg transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Scrollable Content Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-6">
          {copiedLink && (
            <div className="bg-blue-950 border border-blue-600 text-blue-300 text-xs px-3 py-1.5 rounded text-center font-medium font-mono">
              Resolution summary copied to clipboard!
            </div>
          )}

          {/* Supervisor / Admin Governance Banner */}
          {canVerify && (
            <div className="bg-[#121417] p-3.5 rounded-xl border border-[#3d424d] flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-[#FACC15]" />
                <span className="text-gray-300 font-bold uppercase">Supervisor Governance Controls:</span>
                <span className="text-gray-400">
                  {entry.verified ? `Stamped by: ${entry.verifiedBy || "Lead"} on ${entry.verifiedDate || "Active Shift"}` : "Pending Shift Stamp"}
                </span>
              </div>

              <div className="flex items-center gap-2">
                {!entry.verified ? (
                  <button
                    onClick={() => onVerifyEntry && onVerifyEntry(entry.id)}
                    className="bg-green-600 hover:bg-green-500 text-white font-bold px-3 py-1.5 rounded flex items-center gap-1.5 transition-colors"
                  >
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                    <span>Approve & Verify</span>
                  </button>
                ) : (
                  <button
                    onClick={() => onUnverifyEntry && onUnverifyEntry(entry.id)}
                    className="bg-[#2d323b] hover:bg-[#3d424d] text-yellow-400 font-bold px-3 py-1.5 rounded border border-[#3d424d] flex items-center gap-1.5 transition-colors"
                  >
                    <span>Revoke Verification</span>
                  </button>
                )}

                {canDelete && (
                  <button
                    onClick={() => {
                      if (window.confirm("Are you sure you want to delete this SOP resolution? This action will be audited.")) {
                        onDeleteEntry && onDeleteEntry(entry.id);
                        onClose();
                      }
                    }}
                    className="bg-red-950/60 hover:bg-red-900 text-red-300 border border-red-800 font-bold px-3 py-1.5 rounded flex items-center gap-1.5 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Delete SOP</span>
                  </button>
                )}
              </div>
            </div>
          )}

          {/* Safety Warning (LOTO) Banner */}
          {entry.safetyPrecaution && (
            <div className="bg-rose-950/40 border border-rose-700/80 rounded-xl p-4 flex items-start gap-3 text-rose-200 shadow-sm">
              <ShieldAlert className="w-6 h-6 text-rose-500 shrink-0 mt-0.5" />
              <div>
                <h4 className="font-bold text-xs uppercase tracking-wider text-rose-400 flex items-center gap-1.5 font-mono">
                  Critical Safety & Lockout Precaution (LOTO)
                </h4>
                <p className="text-xs sm:text-sm text-rose-200 mt-1 leading-relaxed">
                  {entry.safetyPrecaution}
                </p>
              </div>
            </div>
          )}

          {/* Quick Metrics Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-[#121417] p-3.5 rounded-xl border border-[#2d323b] text-xs">
            <div>
              <span className="text-gray-500 block uppercase font-mono text-[10px]">Estimated Fix Time</span>
              <span className="font-bold text-gray-200 flex items-center gap-1.5 text-sm mt-0.5">
                <Clock className="w-4 h-4 text-[#FACC15]" />
                ~{entry.estimatedFixTimeMinutes} Minutes
              </span>
            </div>

            <div>
              <span className="text-gray-500 block uppercase font-mono text-[10px]">Verified Resolution Votes</span>
              <span className="font-bold text-gray-200 flex items-center gap-1.5 text-sm mt-0.5">
                <ThumbsUp className="w-4 h-4 text-green-400" />
                {entry.helpfulCount} Confirmed
              </span>
            </div>

            <div>
              <span className="text-gray-500 block uppercase font-mono text-[10px]">Logged By</span>
              <span className="font-bold text-gray-200 text-sm mt-0.5 block truncate">
                {entry.author.name}
              </span>
            </div>

            <div>
              <span className="text-gray-500 block uppercase font-mono text-[10px]">Verification Status</span>
              <span className="font-bold text-green-400 text-sm mt-0.5 block truncate font-mono">
                {entry.verified ? `VERIFIED: ${entry.verifiedBy || "Lead"}` : "FIELD DRAFT"}
              </span>
            </div>
          </div>

          {/* Symptoms & Root Cause Box */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-[#121417] p-4 rounded-xl border border-[#2d323b]">
              <h4 className="text-xs font-bold uppercase tracking-wider text-gray-400 mb-2 font-mono">
                Observed Error Symptoms
              </h4>
              <ul className="space-y-1.5 text-xs sm:text-sm text-gray-300">
                {entry.symptoms.map((sym, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#FACC15] mt-1.5 shrink-0" />
                    <span>{sym}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-[#1e2229] p-4 rounded-xl border border-[#2d323b]">
              <h4 className="text-xs font-bold uppercase tracking-wider text-[#FACC15] mb-2 font-mono">
                Confirmed Root Cause
              </h4>
              <p className="text-xs sm:text-sm text-gray-200 leading-relaxed font-medium">
                {entry.rootCause}
              </p>
            </div>
          </div>

          {/* Tools & Parts Required */}
          {entry.toolsRequired && entry.toolsRequired.length > 0 && (
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-gray-400 mb-2.5 flex items-center gap-1.5 font-mono">
                <Wrench className="w-4 h-4 text-gray-500" />
                Required Tools & Replacement Parts
              </h4>
              <div className="flex flex-wrap gap-2">
                {entry.toolsRequired.map((tool, idx) => (
                  <span
                    key={idx}
                    className="inline-flex items-center gap-1.5 text-xs font-medium bg-[#121417] text-gray-200 px-3 py-1.5 rounded-lg border border-[#2d323b]"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#FACC15]" />
                    {tool}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Step-by-Step Interactive Checklist */}
          <div>
            <div className="flex items-center justify-between gap-2 mb-3">
              <h4 className="text-sm font-bold uppercase tracking-wider text-white flex items-center gap-2 font-mono">
                <span>Field Resolution Steps</span>
                <span className="text-xs font-normal text-gray-400 font-sans">
                  (Check off as you complete on the machine)
                </span>
              </h4>

              <span className="text-xs font-mono font-bold text-[#FACC15] bg-[#121417] px-2 py-0.5 rounded border border-[#2d323b]">
                {completedSteps.length} of {entry.stepsToResolve.length} Done
              </span>
            </div>

            {allStepsComplete && (
              <div className="bg-green-950/60 border border-green-700 text-green-300 p-3 rounded-xl mb-3 flex items-center gap-2 text-xs sm:text-sm font-medium">
                <CheckCircle2 className="w-5 h-5 text-green-400 shrink-0" />
                <span>All diagnostic and repair steps completed! Ready for safe machine recommissioning.</span>
              </div>
            )}

            <div className="space-y-2.5">
              {entry.stepsToResolve.map((step, idx) => {
                const isDone = completedSteps.includes(idx);
                return (
                  <div
                    key={idx}
                    onClick={() => toggleStep(idx)}
                    className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-start gap-3 select-none ${
                      isDone
                        ? "bg-green-950/40 border-green-700 text-green-200"
                        : "bg-[#121417] border-[#2d323b] hover:border-[#FACC15] hover:bg-[#1e2229]"
                    }`}
                  >
                    <button
                      type="button"
                      className="mt-0.5 text-gray-500 hover:text-[#FACC15] shrink-0"
                    >
                      {isDone ? (
                        <CheckSquare className="w-5 h-5 text-green-400" />
                      ) : (
                        <Square className="w-5 h-5 text-gray-500" />
                      )}
                    </button>

                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-0.5">
                        <span className={`text-xs font-bold font-mono px-1.5 py-0.2 rounded ${
                          isDone ? "bg-green-900 text-green-300" : "bg-[#2d323b] text-gray-300"
                        }`}>
                          STEP {idx + 1}
                        </span>
                      </div>
                      <p className={`text-xs sm:text-sm leading-relaxed ${isDone ? "line-through text-gray-400" : "text-gray-100 font-medium"}`}>
                        {step}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Photo Gallery */}
          {entry.images && entry.images.length > 0 && (
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-gray-400 mb-2.5 font-mono">
                Attached Equipment Photos / Wiring Diagrams ({entry.images.length})
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {entry.images.map((img, idx) => (
                  <div key={idx} className="rounded-xl overflow-hidden border border-[#2d323b] bg-[#121417] relative group">
                    <img
                      src={img}
                      alt={`Equipment capture ${idx + 1}`}
                      className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-200"
                    />
                    <span className="absolute bottom-2 right-2 bg-black/80 text-white text-[11px] px-2 py-0.5 rounded font-mono border border-gray-700">
                      Photo #{idx + 1}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* AI Field Copilot Action Trigger */}
          {onOpenAIWithContext && (
            <div className="bg-[#121417] border border-blue-900/60 p-4 rounded-xl flex flex-wrap items-center justify-between gap-3">
              <div>
                <h5 className="font-bold text-xs sm:text-sm text-white flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-[#FACC15]" />
                  Need live step-by-step diagnostic reasoning for this unit?
                </h5>
                <p className="text-xs text-gray-400 mt-0.5">
                  Open in AI Field Copilot to query live multimeter pinouts, PLC tag logs, or error codes.
                </p>
              </div>

              <button
                onClick={() => {
                  onClose();
                  onOpenAIWithContext(entry);
                }}
                className="bg-blue-600 hover:bg-blue-500 active:bg-blue-700 text-white text-xs font-bold uppercase tracking-wider px-3.5 py-2 rounded-lg transition-colors flex items-center gap-1.5 shadow-sm"
              >
                <span>Launch AI Copilot</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Floor Feedback & Comments Stream */}
          <div className="pt-4 border-t border-[#2d323b]">
            <h4 className="text-sm font-bold text-white mb-3 flex items-center gap-2 font-mono">
              <MessageSquare className="w-4 h-4 text-gray-400" />
              <span>Issue Notes & Verification Feedback ({entry.comments ? entry.comments.length : 0})</span>
            </h4>

            {entry.comments && entry.comments.length > 0 ? (
              <div className="space-y-3 mb-4">
                {entry.comments.map((comment) => (
                  <div
                    key={comment.id}
                    className="bg-[#121417] p-3 rounded-xl border border-[#2d323b] text-xs"
                  >
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white">{comment.author}</span>
                        <span className="text-gray-500 font-mono text-[10px]">({comment.role})</span>
                      </div>
                      {comment.workedForUser && (
                        <span className="inline-flex items-center gap-1 text-[10px] font-bold text-green-400 bg-green-950/60 px-2 py-0.2 rounded border border-green-800">
                          <CheckCircle2 className="w-3 h-3" /> Worked for me
                        </span>
                      )}
                    </div>
                    <p className="text-gray-300 leading-relaxed">{comment.text}</p>
                    <span className="text-[10px] text-gray-500 mt-1 block font-mono">
                      {new Date(comment.createdAt).toLocaleString()}
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-gray-500 italic mb-4">
                No shift comments yet. Be the first to confirm this solution worked on your machine.
              </p>
            )}

            {/* Quick comment form */}
            <form onSubmit={handleCommentSubmit} className="space-y-2">
              <div className="flex items-center gap-3">
                <label className="text-xs font-semibold text-gray-300 flex items-center gap-1.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={commentWorked}
                    onChange={(e) => setCommentWorked(e.target.checked)}
                    className="rounded text-[#FACC15] focus:ring-[#FACC15] bg-[#121417] border-[#3d424d]"
                  />
                  <span>This resolution worked on my equipment!</span>
                </label>
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  placeholder={`Add shift note as ${shiftInfo.userName} (${shiftInfo.userRole})...`}
                  className="flex-1 text-xs bg-[#121417] text-white border border-[#3d424d] rounded px-3 py-2 focus:border-[#FACC15] focus:outline-none placeholder:text-gray-500"
                />
                <button
                  type="submit"
                  disabled={!commentText.trim()}
                  className="bg-[#2d323b] hover:bg-[#3d424d] disabled:opacity-50 text-white text-xs font-bold uppercase tracking-wider px-3.5 py-2 rounded flex items-center gap-1.5 transition-colors border border-[#3d424d]"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Post</span>
                </button>
              </div>
            </form>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="bg-[#121417] p-4 border-t border-[#2d323b] flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              onClick={(e) => onToggleHelpful(entry.id, e)}
              className={`inline-flex items-center gap-1.5 text-xs font-bold px-4 py-2 rounded border transition-all ${
                entry.userVotedHelpful
                  ? "bg-[#FACC15] text-[#121417] border-[#FACC15] shadow-sm"
                  : "bg-[#1a1d23] text-gray-300 border-[#2d323b] hover:border-gray-500"
              }`}
            >
              <ThumbsUp className={`w-4 h-4 ${entry.userVotedHelpful ? "fill-[#121417]" : ""}`} />
              <span>{entry.userVotedHelpful ? "Voted Helpful" : "Works on My Machine"} ({entry.helpfulCount})</span>
            </button>
          </div>

          <button
            onClick={onClose}
            className="bg-[#2d323b] hover:bg-[#3d424d] text-white text-xs sm:text-sm font-bold uppercase tracking-wider px-5 py-2 rounded transition-colors border border-[#3d424d]"
          >
            Close Viewer
          </button>
        </div>
      </div>
    </div>
  );
};
