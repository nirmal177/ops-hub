import React, { useState } from "react";
import {
  GraduationCap,
  BookOpen,
  Bot,
  Network,
  Wrench,
  Forklift,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  HelpCircle,
  Sparkles,
  ChevronRight,
  ArrowRight,
} from "lucide-react";
import { GET_TRAINING_MODULES } from "../data/seedEntries";
import { EquipmentDomain } from "../types";

interface GETTrainingHubProps {
  onOpenQuickCapture: () => void;
  onFilterByDomain: (domain: EquipmentDomain) => void;
}

const QUIZ_QUESTIONS = [
  {
    id: "q1",
    domain: "AMR",
    question: "An AMR comes to a sudden halt in Aisle 4 with optical scanner zone 1 violation, but no obstacle is in front. What is the very first step?",
    options: [
      "Replace the main navigation computer motherboard.",
      "Clean both LiDAR optical covers with 99% IPA and inspect for reflective vests/glare.",
      "Push the robot manually as fast as possible back to the staging dock.",
      "Format the robot SSD drive.",
    ],
    correctIndex: 1,
    explanation: "Over 45% of false scanner trips are caused by dust film, oil mist, or direct retro-reflective glare saturating the receiver optic. Always clean optics first.",
  },
  {
    id: "q2",
    domain: "FORKLIFT",
    question: "Before probing the busbars on a 48V electric forklift with Curtis inverter fault code 55, what is mandatory?",
    options: [
      "Keep the key in ON position to watch LED codes.",
      "Disconnect battery plug and discharge capacitor bank to 0V using a power resistor.",
      "Spray water to clean the contactor terminals.",
      "Use an uninsulated screwdriver to bridge the terminals.",
    ],
    correctIndex: 1,
    explanation: "Curtis inverters contain large capacitor banks that store lethal DC charge even after battery disconnect. Always verify 0V before touching busbars.",
  },
  {
    id: "q3",
    domain: "NETWORKING",
    question: "What does a solid red Bus Failure (BF) LED on a Siemens ET200SP interface module most frequently indicate?",
    options: [
      "The room temperature is above 25°C.",
      "PROFINET Device Name mismatch or damaged RJ45 cable pin crimp.",
      "The switch power cord is white instead of black.",
      "The PLC firmware is too recent.",
    ],
    correctIndex: 1,
    explanation: "PROFINET relies strictly on topological device names (e.g. `et200sp-rack02`). If the name is missing or mismatched in TIA Portal, BF LED glows solid red.",
  },
];

export const GETTrainingHub: React.FC<GETTrainingHubProps> = ({
  onOpenQuickCapture,
  onFilterByDomain,
}) => {
  const [activeModuleId, setActiveModuleId] = useState(GET_TRAINING_MODULES[0].id);
  const [quizAnswers, setQuizAnswers] = useState<Record<string, number>>({});
  const [showQuizResults, setShowQuizResults] = useState(false);

  const activeModule = GET_TRAINING_MODULES.find((m) => m.id === activeModuleId) || GET_TRAINING_MODULES[0];

  const handleSelectQuizOption = (qId: string, optIndex: number) => {
    setQuizAnswers((prev) => ({ ...prev, [qId]: optIndex }));
  };

  const getDomainIcon = (domain: string) => {
    switch (domain) {
      case "AMR":
        return <Bot className="w-4 h-4 text-sky-600" />;
      case "NETWORKING":
        return <Network className="w-4 h-4 text-violet-600" />;
      case "FORKLIFT":
        return <Forklift className="w-4 h-4 text-emerald-600" />;
      case "COMMISSIONING":
      default:
        return <Wrench className="w-4 h-4 text-amber-600" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Hero Banner */}
      <div className="bg-[#1a1d23] text-white p-5 sm:p-6 rounded-xl border border-[#2d323b] shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-1.5 text-xs font-mono font-bold px-2.5 py-0.5 rounded bg-[#121417] text-[#FACC15] border border-[#3d424d] mb-2 uppercase">
              <GraduationCap className="w-3.5 h-3.5 text-[#FACC15]" />
              GRADUATE ENGINEER TRAINEE (GET) ACCELERATOR
            </div>
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white font-mono uppercase">
              Error & Issue SOPs & Diagnostic Cheat Sheets
            </h2>
            <p className="text-xs sm:text-sm text-gray-400 mt-1 leading-relaxed">
              Curated troubleshooting guides for diagnosing errors and issues. Learn to triage AMR LiDAR trips, Moxa VLAN drops, Pilz dual-channel safety relays, and electric forklift fault codes with senior-level confidence.
            </p>
          </div>

          <button
            onClick={onOpenQuickCapture}
            className="bg-[#FACC15] hover:bg-yellow-300 active:bg-yellow-500 text-[#121417] text-xs sm:text-sm font-bold uppercase tracking-wider px-4 py-2.5 rounded-lg shadow-sm transition-all flex items-center gap-2"
          >
            <span>+ Log First GET Resolution</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Module Selector & Reader */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Left List of Modules */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold uppercase tracking-wider text-gray-400 px-1 font-mono text-[11px]">
            Training Modules
          </h3>
          {GET_TRAINING_MODULES.map((mod) => {
            const isSel = mod.id === activeModuleId;
            return (
              <div
                key={mod.id}
                onClick={() => setActiveModuleId(mod.id)}
                className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
                  isSel
                    ? "bg-[#2d323b] border-[#FACC15] shadow-md ring-1 ring-[#FACC15]/40"
                    : "bg-[#1a1d23] border-[#2d323b] hover:border-gray-500 hover:bg-[#1e2229]"
                }`}
              >
                <div className="flex items-center justify-between gap-2 mb-1">
                  <div className="flex items-center gap-1.5">
                    {getDomainIcon(mod.domain)}
                    <span className="text-xs font-bold text-gray-200">{mod.domain}</span>
                  </div>
                  <span className="text-[10px] font-mono bg-[#121417] text-gray-400 px-1.5 py-0.2 rounded border border-[#2d323b]">
                    {mod.readTime}
                  </span>
                </div>
                <h4 className="text-xs sm:text-sm font-bold text-white leading-snug">
                  {mod.title}
                </h4>
                <p className="text-xs text-gray-400 mt-1 line-clamp-1">{mod.summary}</p>
              </div>
            );
          })}
        </div>

        {/* Right Active Module Reader */}
        <div className="lg:col-span-2 bg-[#1a1d23] rounded-xl p-5 sm:p-6 border border-[#2d323b] shadow-sm space-y-5 text-gray-200">
          <div className="flex flex-wrap items-center justify-between gap-2 pb-4 border-b border-[#2d323b]">
            <div>
              <span className="text-xs font-bold uppercase font-mono text-[#FACC15] bg-[#121417] px-2 py-0.5 rounded border border-[#3d424d]">
                {activeModule.badge}
              </span>
              <h3 className="text-lg sm:text-xl font-bold text-white mt-1">
                {activeModule.title}
              </h3>
            </div>

            <button
              onClick={() => onFilterByDomain(activeModule.domain as EquipmentDomain)}
              className="text-xs font-mono font-bold uppercase tracking-wider text-[#FACC15] hover:text-yellow-300 flex items-center gap-1 bg-[#121417] px-3 py-1.5 rounded-lg border border-[#2d323b] hover:border-gray-500"
            >
              <span>View all {activeModule.domain} KB entries</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <p className="text-xs sm:text-sm text-gray-300 leading-relaxed font-medium">
            {activeModule.summary}
          </p>

          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-gray-400 mb-3 flex items-center gap-1.5 font-mono">
              <ShieldCheck className="w-4 h-4 text-green-400" />
              Critical Resolution Golden Rules
            </h4>
            <div className="space-y-2.5">
              {activeModule.keyPoints.map((point, idx) => (
                <div
                  key={idx}
                  className="bg-[#121417] border border-[#2d323b] rounded-xl p-3.5 flex items-start gap-3 text-xs sm:text-sm"
                >
                  <span className="w-5 h-5 rounded-full bg-[#2d323b] text-[#FACC15] border border-[#3d424d] flex items-center justify-center font-mono font-bold text-xs shrink-0 mt-0.5">
                    {idx + 1}
                  </span>
                  <span className="text-gray-200 font-medium leading-relaxed">{point}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Interactive GET Diagnostic Scenario Quiz */}
      <div className="bg-[#1a1d23] rounded-xl p-5 sm:p-6 border border-[#2d323b] shadow-sm space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h3 className="text-base sm:text-lg font-bold text-white flex items-center gap-2 font-mono uppercase tracking-wider">
              <HelpCircle className="w-5 h-5 text-[#FACC15]" />
              <span>GET Error & Issue Diagnostic Knowledge Check</span>
            </h3>
            <p className="text-xs text-gray-400 mt-0.5">
              Test your instinctive troubleshooting reactions before tackling complex errors and issues.
            </p>
          </div>

          <button
            onClick={() => setShowQuizResults(!showQuizResults)}
            className="text-xs font-mono font-bold uppercase tracking-wider bg-[#2d323b] hover:bg-[#3d424d] text-white px-3.5 py-1.5 rounded-lg transition-colors border border-[#3d424d]"
          >
            {showQuizResults ? "Hide Answers" : "Verify Answers"}
          </button>
        </div>

        <div className="space-y-5">
          {QUIZ_QUESTIONS.map((q, qIdx) => {
            const selectedOpt = quizAnswers[q.id];
            const isAnswered = selectedOpt !== undefined;
            const isCorrect = selectedOpt === q.correctIndex;

            return (
              <div
                key={q.id}
                className="bg-[#121417] p-4 rounded-xl border border-[#2d323b] space-y-3"
              >
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs font-bold bg-[#2d323b] text-[#FACC15] px-2 py-0.5 rounded border border-[#3d424d]">
                    Q{qIdx + 1} • {q.domain}
                  </span>
                </div>

                <p className="text-xs sm:text-sm font-bold text-white">{q.question}</p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {q.options.map((opt, optIdx) => {
                    const isSelected = selectedOpt === optIdx;
                    return (
                      <button
                        key={optIdx}
                        onClick={() => handleSelectQuizOption(q.id, optIdx)}
                        className={`text-left p-3 rounded-lg border text-xs transition-all leading-snug flex items-start gap-2 ${
                          isSelected
                            ? "bg-[#FACC15] text-[#121417] border-[#FACC15] font-bold shadow-sm"
                            : "bg-[#1a1d23] text-gray-300 border-[#2d323b] hover:bg-[#252a33] hover:border-gray-500"
                        }`}
                      >
                        <span className="font-mono opacity-80 shrink-0 font-bold">
                          {String.fromCharCode(65 + optIdx)}.
                        </span>
                        <span>{opt}</span>
                      </button>
                    );
                  })}
                </div>

                {showQuizResults && isAnswered && (
                  <div
                    className={`p-3 rounded-lg text-xs leading-relaxed ${
                      isCorrect
                        ? "bg-green-950/60 text-green-200 border border-green-700 font-medium"
                        : "bg-rose-950/60 text-rose-200 border border-rose-700 font-medium"
                    }`}
                  >
                    <strong className="font-mono">{isCorrect ? "Correct!" : "Senior Tech Feedback:"}</strong> {q.explanation}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
