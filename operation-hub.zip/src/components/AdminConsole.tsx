import React, { useState } from "react";
import {
  Users,
  Shield,
  CheckCircle2,
  AlertTriangle,
  FileText,
  Search,
  Plus,
  Edit2,
  Trash2,
  Power,
  RotateCcw,
  Download,
  Upload,
  UserCheck,
  Check,
  X,
  Clock,
  Building,
  Key,
  ShieldAlert,
  Sliders,
  Filter,
  ArrowRight,
  ExternalLink,
  Zap,
  Lock,
} from "lucide-react";
import {
  User,
  UserRole,
  UserStatus,
  AuditLog,
  TroubleshootingEntry,
  EquipmentDomain,
} from "../types";
import { ROLE_CONFIG } from "../data/seedUsers";

interface AdminConsoleProps {
  users: User[];
  currentUser: User;
  onSelectUser: (user: User) => void;
  onOpenAddUser: () => void;
  onOpenEditUser: (user: User) => void;
  onToggleUserStatus: (userId: string) => void;
  onDeleteUser: (userId: string) => void;
  auditLogs: AuditLog[];
  entries: TroubleshootingEntry[];
  onVerifyEntry: (entryId: string) => void;
  onUnverifyEntry: (entryId: string) => void;
  onDeleteEntry: (entryId: string) => void;
  onSelectEntry: (entry: TroubleshootingEntry) => void;
  onExportSystem: () => void;
  onResetFactorySeed: () => void;
}

export const AdminConsole: React.FC<AdminConsoleProps> = ({
  users,
  currentUser,
  onSelectUser,
  onOpenAddUser,
  onOpenEditUser,
  onToggleUserStatus,
  onDeleteUser,
  auditLogs,
  entries,
  onVerifyEntry,
  onUnverifyEntry,
  onDeleteEntry,
  onSelectEntry,
  onExportSystem,
  onResetFactorySeed,
}) => {
  const [adminTab, setAdminTab] = useState<"users" | "roles" | "approvals" | "audit" | "system">("users");
  const [userSearch, setUserSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState<UserRole | "ALL">("ALL");
  const [statusFilter, setStatusFilter] = useState<UserStatus | "ALL">("ALL");
  const [auditSearch, setAuditSearch] = useState("");
  const [auditSeverityFilter, setAuditSeverityFilter] = useState<"ALL" | "INFO" | "WARNING" | "CRITICAL">("ALL");
  const [userToDelete, setUserToDelete] = useState<User | null>(null);

  const isAdmin = currentUser.role === "ADMIN";
  const unverifiedEntries = entries.filter((e) => !e.verified);
  const activeUsersCount = users.filter((u) => u.status === "ACTIVE").length;
  const getTraineesCount = users.filter((u) => u.role === "GET_TRAINEE").length;
  const supervisorsCount = users.filter((u) => u.role === "MANAGER" || u.role === "ASSISTANT_MANAGER" || u.role === "ADMIN").length;

  const filteredUsers = users.filter((u) => {
    const matchesSearch =
      u.name.toLowerCase().includes(userSearch.toLowerCase()) ||
      u.badgeId.toLowerCase().includes(userSearch.toLowerCase()) ||
      u.email.toLowerCase().includes(userSearch.toLowerCase()) ||
      u.facility.toLowerCase().includes(userSearch.toLowerCase()) ||
      u.line.toLowerCase().includes(userSearch.toLowerCase());
    const matchesRole = roleFilter === "ALL" || roleFilter === "NONE" || u.role === roleFilter;
    const matchesStatus = statusFilter === "ALL" || statusFilter === "NONE" || u.status === statusFilter;
    return matchesSearch && matchesRole && matchesStatus;
  });

  const filteredAuditLogs = auditLogs.filter((log) => {
    const matchesSearch =
      log.details.toLowerCase().includes(auditSearch.toLowerCase()) ||
      log.userName.toLowerCase().includes(auditSearch.toLowerCase()) ||
      log.action.toLowerCase().includes(auditSearch.toLowerCase());
    const matchesSeverity = auditSeverityFilter === "ALL" || auditSeverityFilter === "NONE" || log.severity === auditSeverityFilter;
    return matchesSearch && matchesSeverity;
  });

  const isUserAdminOrLead = currentUser.role === "ADMIN" || currentUser.role === "MANAGER" || currentUser.role === "ASSISTANT_MANAGER";

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Top Banner */}
      <div className="bg-[#1a1d23] text-white p-5 sm:p-6 rounded-xl border border-[#2d323b] shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-1.5 text-xs font-mono font-bold px-2.5 py-0.5 rounded bg-[#121417] text-[#FACC15] border border-[#3d424d] mb-2 uppercase">
              <Shield className="w-3.5 h-3.5 text-[#FACC15]" />
              PLANT OPERATIONS & GOVERNANCE CONSOLE
            </div>
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white font-mono uppercase">
              User Management & Access Control
            </h2>
            <p className="text-xs sm:text-sm text-gray-400 mt-1 leading-relaxed">
              Manage technician identities, certify GET trainees, audit safety compliance actions, and review pending line error and issue resolutions.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onOpenAddUser}
              className="bg-[#FACC15] hover:bg-yellow-300 active:bg-yellow-500 text-[#121417] text-xs sm:text-sm font-bold uppercase tracking-wider px-4 py-2.5 rounded-lg shadow-sm transition-all flex items-center gap-2"
              id="btn-admin-add-user"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              <span>+ Provision Staff</span>
            </button>
          </div>
        </div>

        {/* Quick KPI Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-5 pt-4 border-t border-[#2d323b] font-mono">
          <div className="bg-[#121417] p-3 rounded-lg border border-[#2d323b]">
            <span className="text-[11px] text-gray-400 uppercase block">Total Technicians</span>
            <div className="text-lg font-bold text-white mt-0.5 flex items-baseline justify-between">
              <span>{users.length}</span>
              <span className="text-[10px] text-green-400 font-bold">{activeUsersCount} Active</span>
            </div>
          </div>

          <div className="bg-[#121417] p-3 rounded-lg border border-[#2d323b]">
            <span className="text-[11px] text-gray-400 uppercase block">GET Trainees</span>
            <div className="text-lg font-bold text-[#fb923c] mt-0.5 flex items-baseline justify-between">
              <span>{getTraineesCount}</span>
              <span className="text-[10px] text-gray-400">In Training</span>
            </div>
          </div>

          <div className="bg-[#121417] p-3 rounded-lg border border-[#2d323b]">
            <span className="text-[11px] text-gray-400 uppercase block">Pending SOP Reviews</span>
            <div className="text-lg font-bold text-[#FACC15] mt-0.5 flex items-baseline justify-between">
              <span>{unverifiedEntries.length}</span>
              <span className="text-[10px] text-yellow-300">Needs Stamp</span>
            </div>
          </div>

          <div className="bg-[#121417] p-3 rounded-lg border border-[#2d323b]">
            <span className="text-[11px] text-gray-400 uppercase block">Audit Trail Events</span>
            <div className="text-lg font-bold text-blue-400 mt-0.5 flex items-baseline justify-between">
              <span>{auditLogs.length}</span>
              <span className="text-[10px] text-gray-400">Security Logs</span>
            </div>
          </div>
        </div>
      </div>

      {/* Admin Tab Switcher */}
      <div className="flex items-center gap-1.5 sm:gap-2 border-b border-[#2d323b] pb-2 overflow-x-auto no-scrollbar font-mono text-xs">
        <button
          onClick={() => setAdminTab("users")}
          className={`px-3.5 py-2 rounded-lg font-bold uppercase tracking-wider transition-all flex items-center gap-2 whitespace-nowrap border ${
            adminTab === "users"
              ? "bg-[#2d323b] text-white border-[#FACC15] shadow-sm"
              : "bg-[#1a1d23] text-gray-400 border-[#2d323b] hover:text-white"
          }`}
        >
          <Users className={`w-4 h-4 ${adminTab === "users" ? "text-[#FACC15]" : ""}`} />
          <span>Staff Directory ({users.length})</span>
        </button>

        <button
          onClick={() => setAdminTab("roles")}
          className={`px-3.5 py-2 rounded-lg font-bold uppercase tracking-wider transition-all flex items-center gap-2 whitespace-nowrap border ${
            adminTab === "roles"
              ? "bg-[#2d323b] text-white border-[#FACC15] shadow-sm"
              : "bg-[#1a1d23] text-gray-400 border-[#2d323b] hover:text-white"
          }`}
        >
          <Key className={`w-4 h-4 ${adminTab === "roles" ? "text-[#FACC15]" : ""}`} />
          <span>Role & Permission Matrix</span>
        </button>

        <button
          onClick={() => setAdminTab("approvals")}
          className={`px-3.5 py-2 rounded-lg font-bold uppercase tracking-wider transition-all flex items-center gap-2 whitespace-nowrap border ${
            adminTab === "approvals"
              ? "bg-[#2d323b] text-white border-[#FACC15] shadow-sm"
              : "bg-[#1a1d23] text-gray-400 border-[#2d323b] hover:text-white"
          }`}
        >
          <CheckCircle2 className={`w-4 h-4 ${adminTab === "approvals" ? "text-[#FACC15]" : ""}`} />
          <span>SOP Quality Queue ({unverifiedEntries.length})</span>
        </button>

        <button
          onClick={() => setAdminTab("audit")}
          className={`px-3.5 py-2 rounded-lg font-bold uppercase tracking-wider transition-all flex items-center gap-2 whitespace-nowrap border ${
            adminTab === "audit"
              ? "bg-[#2d323b] text-white border-[#FACC15] shadow-sm"
              : "bg-[#1a1d23] text-gray-400 border-[#2d323b] hover:text-white"
          }`}
        >
          <FileText className={`w-4 h-4 ${adminTab === "audit" ? "text-[#FACC15]" : ""}`} />
          <span>Security Audit Trail ({auditLogs.length})</span>
        </button>

        <button
          onClick={() => setAdminTab("system")}
          className={`px-3.5 py-2 rounded-lg font-bold uppercase tracking-wider transition-all flex items-center gap-2 whitespace-nowrap border ${
            adminTab === "system"
              ? "bg-[#2d323b] text-white border-[#FACC15] shadow-sm"
              : "bg-[#1a1d23] text-gray-400 border-[#2d323b] hover:text-white"
          }`}
        >
          <Sliders className={`w-4 h-4 ${adminTab === "system" ? "text-[#FACC15]" : ""}`} />
          <span>Plant Diagnostics & Backup</span>
        </button>
      </div>

      {/* TAB 1: USERS DIRECTORY */}
      {adminTab === "users" && (
        <div className="space-y-4">
          {/* Search and Filters */}
          <div className="bg-[#1a1d23] p-4 rounded-xl border border-[#2d323b] space-y-3">
            <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={userSearch}
                  onChange={(e) => setUserSearch(e.target.value)}
                  placeholder="Search staff by name, badge ID (#TEC-209), line, or email..."
                  className="w-full bg-[#121417] text-white text-xs pl-9 pr-4 py-2.5 rounded-lg border border-[#2d323b] focus:border-[#FACC15] focus:outline-none placeholder:text-gray-500 font-mono"
                />
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <select
                  value={roleFilter}
                  onChange={(e) => setRoleFilter(e.target.value as UserRole | "ALL")}
                  className="bg-[#121417] text-gray-300 text-xs font-mono py-2 px-3 rounded-lg border border-[#2d323b] focus:border-[#FACC15] focus:outline-none"
                >
                  <option value="ALL">All Roles ({users.length})</option>
                  <option value="GET_TRAINEE">1. Graduate Engineering Trainee</option>
                  <option value="ASSISTANT_MANAGER">2. Assistant Manager</option>
                  <option value="MANAGER">3. Manager</option>
                  <option value="ADMIN">4. Admin</option>
                  <option value="MAINTENANCE_ENGINEER">5. Maintenance Engineer</option>
                  <option value="NONE">None (No Role Filter)</option>
                </select>

                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value as UserStatus | "ALL")}
                  className="bg-[#121417] text-gray-300 text-xs font-mono py-2 px-3 rounded-lg border border-[#2d323b] focus:border-[#FACC15] focus:outline-none"
                >
                  <option value="ALL">All Statuses</option>
                  <option value="NONE">None (No Status Filter)</option>
                  <option value="ACTIVE">Active</option>
                  <option value="ON_LEAVE">On Leave</option>
                  <option value="INACTIVE">Inactive</option>
                  <option value="RESTRICTED">Restricted</option>
                </select>
              </div>
            </div>
          </div>

          {/* User Table / Cards */}
          <div className="bg-[#1a1d23] rounded-xl border border-[#2d323b] overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-[#121417] text-gray-400 uppercase text-[11px] border-b border-[#2d323b]">
                  <tr>
                    <th className="py-3 px-4">Technician / Badge</th>
                    <th className="py-3 px-4">Role & Privileges</th>
                    <th className="py-3 px-4">Plant & Line</th>
                    <th className="py-3 px-4">Specialties</th>
                    <th className="py-3 px-4 text-center">Floor Stats</th>
                    <th className="py-3 px-4 text-center">Status</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#2d323b]">
                  {filteredUsers.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-8 text-center text-gray-500 font-mono">
                        No technician profiles match the current filter criteria.
                      </td>
                    </tr>
                  ) : (
                    filteredUsers.map((user) => {
                      const isCurrent = user.id === currentUser.id;
                      const roleMeta = ROLE_CONFIG[user.role];

                      return (
                        <tr
                          key={user.id}
                          className={`hover:bg-[#1e2229] transition-colors ${
                            isCurrent ? "bg-[#252a33]/50" : ""
                          }`}
                        >
                          {/* Name & Badge */}
                          <td className="py-3 px-4">
                            <div className="flex items-center gap-3">
                              <div
                                className="w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs text-[#121417] font-mono shrink-0"
                                style={{ backgroundColor: user.avatarColor || "#FACC15" }}
                              >
                                {user.name
                                  .split(" ")
                                  .map((n) => n[0])
                                  .slice(0, 2)
                                  .join("")}
                              </div>
                              <div>
                                <div className="flex items-center gap-2">
                                  <span className="font-bold text-white font-sans text-xs sm:text-sm">
                                    {user.name}
                                  </span>
                                  {isCurrent && (
                                    <span className="text-[9px] bg-green-950 text-green-400 border border-green-800 px-1 rounded">
                                      YOU
                                    </span>
                                  )}
                                </div>
                                <span className="text-gray-400 text-[11px]">
                                  {user.badgeId} • {user.email}
                                </span>
                              </div>
                            </div>
                          </td>

                          {/* Role */}
                          <td className="py-3 px-4">
                            <span
                              className={`text-[10px] font-bold px-2 py-0.5 rounded border ${
                                roleMeta?.badgeBg || "bg-[#121417]"
                              } text-[#FACC15] ${roleMeta?.badgeBorder || "border-[#3d424d]"}`}
                            >
                              {roleMeta?.badgeLabel || user.role}
                            </span>
                          </td>

                          {/* Facility & Line */}
                          <td className="py-3 px-4 text-gray-300">
                            <div>{user.facility}</div>
                            <div className="text-gray-500 text-[10px]">{user.line}</div>
                          </td>

                          {/* Specialties */}
                          <td className="py-3 px-4">
                            <div className="flex flex-wrap gap-1 max-w-xs">
                              {user.specialties?.map((sp) => (
                                <span
                                  key={sp}
                                  className="text-[9px] px-1.5 py-0.2 rounded bg-[#121417] text-gray-300 border border-[#2d323b]"
                                >
                                  {sp}
                                </span>
                              ))}
                            </div>
                          </td>

                          {/* Stats */}
                          <td className="py-3 px-4 text-center">
                            <div className="flex items-center justify-center gap-2 text-[11px]">
                              <span title="Solutions Logged" className="text-[#FACC15]">
                                ⚡ {user.stats?.solutionsLogged || 0}
                              </span>
                              <span className="text-gray-600">|</span>
                              <span title="Verifications" className="text-green-400">
                                ✓ {user.stats?.verificationsPerformed || 0}
                              </span>
                            </div>
                          </td>

                          {/* Status */}
                          <td className="py-3 px-4 text-center">
                            <button
                              onClick={() => onToggleUserStatus(user.id)}
                              title="Click to toggle status"
                              className={`text-[10px] font-bold px-2 py-0.5 rounded border transition-colors ${
                                user.status === "ACTIVE"
                                  ? "bg-green-950/60 text-green-400 border-green-800 hover:bg-green-900"
                                  : user.status === "ON_LEAVE"
                                  ? "bg-yellow-950/60 text-yellow-400 border-yellow-800"
                                  : "bg-red-950/60 text-red-400 border-red-800"
                              }`}
                            >
                              {user.status}
                            </button>
                          </td>

                          {/* Actions */}
                          <td className="py-3 px-4 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              {!isCurrent && (
                                <button
                                  onClick={() => onSelectUser(user)}
                                  className="text-[11px] bg-[#121417] hover:bg-[#252a33] text-[#FACC15] border border-[#2d323b] hover:border-[#FACC15] px-2 py-1 rounded transition-colors"
                                  title="Quick Kiosk Switch to this User"
                                >
                                  Switch
                                </button>
                              )}
                              <button
                                onClick={() => onOpenEditUser(user)}
                                className="p-1.5 text-gray-400 hover:text-white bg-[#121417] hover:bg-[#252a33] border border-[#2d323b] rounded transition-colors"
                                title="Edit User Profile"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                              {!isCurrent && (
                                isAdmin ? (
                                  <button
                                    onClick={() => setUserToDelete(user)}
                                    className="p-1.5 text-gray-400 hover:text-red-400 bg-[#121417] hover:bg-red-950/60 border border-[#2d323b] hover:border-red-800 rounded transition-colors"
                                    title="Decommission & Delete Employee (Administrator Access Only)"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                ) : (
                                  <span
                                    className="p-1.5 text-gray-600 bg-[#121417] border border-[#23272e] rounded opacity-40 cursor-not-allowed"
                                    title="Admin Clearance Required: Only plant administrators can delete employee accounts"
                                  >
                                    <Lock className="w-3.5 h-3.5" />
                                  </span>
                                )
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: ROLE & PERMISSION MATRIX */}
      {adminTab === "roles" && (
        <div className="space-y-5">
          <div className="bg-[#1a1d23] p-5 rounded-xl border border-[#2d323b] space-y-4">
            <div>
              <h3 className="text-base font-bold text-white font-mono uppercase tracking-wider flex items-center gap-2">
                <Key className="w-4 h-4 text-[#FACC15]" />
                <span>Shop-Floor Role Permission Hierarchy</span>
              </h3>
              <p className="text-xs text-gray-400 font-mono mt-0.5">
                Defines technical permissions for LOTO lockout safety overrides, employee deletion & provisioning, and SOP verification
              </p>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-[#121417] text-gray-400 uppercase text-[11px] border-b border-[#2d323b]">
                  <tr>
                    <th className="py-3 px-4">Role Title</th>
                    <th className="py-3 px-4 text-center">Verify & Stamp SOPs</th>
                    <th className="py-3 px-4 text-center">Delete Entries</th>
                    <th className="py-3 px-4 text-center">User Management</th>
                    <th className="py-3 px-4 text-center text-red-400">Delete Employee</th>
                    <th className="py-3 px-4 text-center">Direct Publish (No Draft)</th>
                    <th className="py-3 px-4 text-center">Safety / LOTO Override</th>
                    <th className="py-3 px-4 text-center">Export Full KB</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#2d323b]">
                  {(
                    [
                      "GET_TRAINEE",
                      "ASSISTANT_MANAGER",
                      "MANAGER",
                      "ADMIN",
                      "MAINTENANCE_ENGINEER",
                    ] as UserRole[]
                  ).map((role) => {
                    const cfg = ROLE_CONFIG[role];
                    const perm = cfg.permissions;

                    return (
                      <tr key={role} className="hover:bg-[#1e2229] transition-colors">
                        <td className="py-3 px-4">
                          <div>
                            <span
                              className={`text-[10px] font-bold px-2 py-0.5 rounded border ${
                                cfg.badgeBg
                              } text-[#FACC15] ${cfg.badgeBorder}`}
                            >
                              {cfg.badgeLabel}
                            </span>
                            <div className="text-white font-sans font-semibold text-xs mt-1">
                              {cfg.label}
                            </div>
                            <p className="text-[10px] text-gray-400 font-mono line-clamp-1">
                              {cfg.description}
                            </p>
                          </div>
                        </td>

                        <td className="py-3 px-4 text-center">
                          {perm.canVerifySolutions ? (
                            <span className="inline-flex items-center text-green-400 font-bold">
                              <Check className="w-4 h-4" />
                            </span>
                          ) : (
                            <span className="text-gray-600">—</span>
                          )}
                        </td>

                        <td className="py-3 px-4 text-center">
                          {perm.canDeleteEntries ? (
                            <span className="inline-flex items-center text-green-400 font-bold">
                              <Check className="w-4 h-4" />
                            </span>
                          ) : (
                            <span className="text-gray-600">—</span>
                          )}
                        </td>

                        <td className="py-3 px-4 text-center">
                          {perm.canManageUsers ? (
                            <span className="inline-flex items-center text-green-400 font-bold">
                              <Check className="w-4 h-4" />
                            </span>
                          ) : (
                            <span className="text-gray-600">—</span>
                          )}
                        </td>

                        <td className="py-3 px-4 text-center">
                          {perm.canDeleteUsers ? (
                            <span className="inline-flex items-center justify-center gap-1 text-red-400 font-bold bg-red-950/40 border border-red-900/60 px-2 py-0.5 rounded text-[10px]">
                              <Check className="w-3.5 h-3.5" />
                              <span>Admin Only</span>
                            </span>
                          ) : (
                            <span className="text-gray-600" title="Restricted to Admin">—</span>
                          )}
                        </td>

                        <td className="py-3 px-4 text-center">
                          {perm.canPublishDirectly ? (
                            <span className="inline-flex items-center text-green-400 font-bold">
                              <Check className="w-4 h-4" />
                            </span>
                          ) : (
                            <span className="text-yellow-400 text-[10px]">Review Queue</span>
                          )}
                        </td>

                        <td className="py-3 px-4 text-center">
                          {perm.canEditSafetyLOTO ? (
                            <span className="inline-flex items-center text-green-400 font-bold">
                              <Check className="w-4 h-4" />
                            </span>
                          ) : (
                            <span className="text-gray-600">—</span>
                          )}
                        </td>

                        <td className="py-3 px-4 text-center">
                          {perm.canExportData ? (
                            <span className="inline-flex items-center text-green-400 font-bold">
                              <Check className="w-4 h-4" />
                            </span>
                          ) : (
                            <span className="text-gray-600">—</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: SOP QUALITY & VERIFICATION QUEUE */}
      {adminTab === "approvals" && (
        <div className="space-y-4">
          <div className="bg-[#1a1d23] p-5 rounded-xl border border-[#2d323b]">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h3 className="text-base font-bold text-white font-mono uppercase tracking-wider flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-green-400" />
                  <span>SOP Quality & Supervisor Peer-Review Queue</span>
                </h3>
                <p className="text-xs text-gray-400 font-mono mt-0.5">
                  Verify shop-floor fixes drafted by technicians and GET trainees before wide fleet rollout
                </p>
              </div>
              <span className="text-xs font-mono font-bold bg-[#121417] text-[#FACC15] px-2.5 py-1 rounded border border-[#3d424d]">
                {unverifiedEntries.length} Fixes Pending Verification
              </span>
            </div>
          </div>

          {unverifiedEntries.length === 0 ? (
            <div className="bg-[#1a1d23] p-12 rounded-xl border border-[#2d323b] text-center space-y-3">
              <CheckCircle2 className="w-10 h-10 text-green-400 mx-auto animate-pulse" />
              <h4 className="text-base font-bold text-white font-mono uppercase">
                All Field Resolutions Verified!
              </h4>
              <p className="text-xs text-gray-400 max-w-md mx-auto font-mono">
                100% of currently recorded error & issue fixes carry a Supervisor or Lead Engineer verification stamp.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-3">
              {unverifiedEntries.map((entry) => (
                <div
                  key={entry.id}
                  className="bg-[#1a1d23] p-4 rounded-xl border border-[#2d323b] hover:border-gray-500 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                >
                  <div className="space-y-1.5 flex-1">
                    <div className="flex items-center gap-2 flex-wrap font-mono text-xs">
                      <span className="font-bold bg-[#121417] text-[#FACC15] px-2 py-0.5 rounded border border-[#3d424d]">
                        {entry.errorCode}
                      </span>
                      <span className="text-gray-400 font-bold">{entry.domain}</span>
                      <span className="text-gray-600">•</span>
                      <span className="text-gray-400">{entry.equipmentId}</span>
                      <span className="text-gray-600">•</span>
                      <span className="text-orange-400">Author: {entry.author?.name} ({entry.author?.role})</span>
                    </div>

                    <h4
                      onClick={() => onSelectEntry(entry)}
                      className="text-xs sm:text-sm font-bold text-white hover:text-[#FACC15] cursor-pointer transition-colors"
                    >
                      {entry.title}
                    </h4>

                    <p className="text-xs text-gray-400 line-clamp-2 font-mono">
                      <strong>Root Cause:</strong> {entry.rootCause}
                    </p>
                  </div>

                  <div className="flex items-center gap-2 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-[#2d323b]">
                    <button
                      onClick={() => onSelectEntry(entry)}
                      className="text-xs font-mono font-bold text-gray-300 hover:text-white bg-[#121417] hover:bg-[#252a33] px-3 py-2 rounded-lg border border-[#2d323b] transition-colors"
                    >
                      Inspect Fix
                    </button>

                    <button
                      onClick={() => onVerifyEntry(entry.id)}
                      className="bg-green-600 hover:bg-green-500 active:bg-green-700 text-white text-xs font-mono font-bold uppercase tracking-wider px-3.5 py-2 rounded-lg shadow-sm flex items-center gap-1.5 transition-colors"
                      id={`btn-verify-${entry.id}`}
                    >
                      <Check className="w-3.5 h-3.5 stroke-[3]" />
                      <span>Approve & Verify</span>
                    </button>

                    <button
                      onClick={() => onDeleteEntry(entry.id)}
                      className="text-gray-400 hover:text-red-400 bg-[#121417] hover:bg-red-950/60 p-2 rounded-lg border border-[#2d323b] hover:border-red-800 transition-colors"
                      title="Reject & Delete SOP"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 4: SYSTEM AUDIT TRAIL */}
      {adminTab === "audit" && (
        <div className="space-y-4">
          <div className="bg-[#1a1d23] p-4 rounded-xl border border-[#2d323b] space-y-3">
            <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={auditSearch}
                  onChange={(e) => setAuditSearch(e.target.value)}
                  placeholder="Search security audit logs by technician name, action, or details..."
                  className="w-full bg-[#121417] text-white text-xs pl-9 pr-4 py-2.5 rounded-lg border border-[#2d323b] focus:border-[#FACC15] focus:outline-none placeholder:text-gray-500 font-mono"
                />
              </div>

              <div className="flex items-center gap-2">
                <select
                  value={auditSeverityFilter}
                  onChange={(e) =>
                    setAuditSeverityFilter(e.target.value as "ALL" | "INFO" | "WARNING" | "CRITICAL" | "NONE")
                  }
                  className="bg-[#121417] text-gray-300 text-xs font-mono py-2 px-3 rounded-lg border border-[#2d323b] focus:border-[#FACC15] focus:outline-none"
                >
                  <option value="ALL">All Severity ({auditLogs.length})</option>
                  <option value="NONE">None (No Severity Filter)</option>
                  <option value="INFO">Info Logs</option>
                  <option value="WARNING">Warnings</option>
                  <option value="CRITICAL">Critical Security</option>
                </select>

                <button
                  onClick={onExportSystem}
                  className="bg-[#2d323b] hover:bg-[#3d424d] text-white text-xs font-mono font-bold uppercase tracking-wider px-3 py-2 rounded-lg border border-[#3d424d] flex items-center gap-1.5 transition-colors"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Export Logs</span>
                </button>
              </div>
            </div>
          </div>

          <div className="bg-[#1a1d23] rounded-xl border border-[#2d323b] overflow-hidden shadow-sm">
            <div className="p-4 bg-[#121417] border-b border-[#2d323b] flex items-center justify-between text-xs font-mono text-gray-400">
              <span>Timestamp & User</span>
              <span>Action & Operational Details</span>
            </div>
            <div className="divide-y divide-[#2d323b] max-h-96 overflow-y-auto">
              {filteredAuditLogs.length === 0 ? (
                <div className="p-8 text-center text-gray-500 font-mono text-xs">
                  No audit trail records found.
                </div>
              ) : (
                filteredAuditLogs.map((log) => (
                  <div
                    key={log.id}
                    className="p-3.5 hover:bg-[#1e2229] transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs font-mono"
                  >
                    <div className="flex items-center gap-3">
                      <span
                        className={`w-2 h-2 rounded-full shrink-0 ${
                          log.severity === "CRITICAL"
                            ? "bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.8)]"
                            : log.severity === "WARNING"
                            ? "bg-amber-500"
                            : "bg-blue-500"
                        }`}
                      />
                      <div>
                        <div className="flex items-center gap-2">
                          <strong className="text-white">{log.userName}</strong>
                          <span className="text-[10px] text-gray-400">({log.userRole})</span>
                          <span
                            className={`text-[9px] px-1 py-0.2 rounded border ${
                              log.severity === "CRITICAL"
                                ? "bg-red-950/60 text-red-400 border-red-800"
                                : log.severity === "WARNING"
                                ? "bg-amber-950/60 text-amber-400 border-amber-800"
                                : "bg-blue-950/60 text-blue-400 border-blue-800"
                            }`}
                          >
                            {log.action}
                          </span>
                        </div>
                        <p className="text-gray-300 text-[11px] mt-0.5">{log.details}</p>
                      </div>
                    </div>

                    <div className="text-[10px] text-gray-500 shrink-0">
                      {new Date(log.timestamp).toLocaleTimeString([], {
                        hour: "2-digit",
                        minute: "2-digit",
                        second: "2-digit",
                      })}{" "}
                      • {new Date(log.timestamp).toLocaleDateString()}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: PLANT DIAGNOSTICS & BACKUP */}
      {adminTab === "system" && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          {/* Data Export & Backup */}
          <div className="bg-[#1a1d23] p-5 rounded-xl border border-[#2d323b] space-y-4">
            <div className="flex items-center gap-2.5 text-white">
              <Download className="w-5 h-5 text-[#FACC15]" />
              <h4 className="text-base font-bold font-mono uppercase">Full Plant Backup & JSON Export</h4>
            </div>
            <p className="text-xs text-gray-400 font-mono leading-relaxed">
              Export all {entries.length} SOP resolutions, {users.length} technician accounts, and {auditLogs.length} audit logs into an offline JSON archive.
            </p>
            <button
              onClick={onExportSystem}
              className="w-full bg-[#FACC15] hover:bg-yellow-300 text-[#121417] font-bold text-xs uppercase tracking-wider py-2.5 rounded-lg flex items-center justify-center gap-2 transition-colors font-mono"
            >
              <Download className="w-4 h-4" />
              <span>Export Complete Operation Hub (.json)</span>
            </button>
          </div>

          {/* Factory Reset / Seed Re-initialization */}
          <div className="bg-[#1a1d23] p-5 rounded-xl border border-red-950/60 space-y-4">
            <div className="flex items-center gap-2.5 text-red-400">
              <RotateCcw className="w-5 h-5 text-red-400" />
              <h4 className="text-base font-bold font-mono uppercase">Re-seed Factory Demo Data</h4>
            </div>
            <p className="text-xs text-gray-400 font-mono leading-relaxed">
              Restores factory default troubleshooting solutions, standard GET trainees, and shifts. Useful for training demonstrations or test staging.
            </p>
            <button
              onClick={() => {
                if (window.confirm("Are you sure you want to reset demo data to factory defaults?")) {
                  onResetFactorySeed();
                }
              }}
              className="w-full bg-red-950/60 hover:bg-red-900 text-red-300 border border-red-800 font-bold text-xs uppercase tracking-wider py-2.5 rounded-lg flex items-center justify-center gap-2 transition-colors font-mono"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Reset to Standard Factory Seed</span>
            </button>
          </div>
        </div>
      )}

      {/* ADMIN-ONLY EMPLOYEE DECOMMISSION & DELETION CONFIRMATION MODAL */}
      {userToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-[#1a1d23] border border-red-900/60 rounded-2xl w-full max-w-lg shadow-2xl text-gray-200 overflow-hidden">
            {/* Header */}
            <div className="p-4 sm:p-5 border-b border-[#2d323b] bg-red-950/30 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-lg bg-red-950 text-red-400 flex items-center justify-center border border-red-800">
                  <ShieldAlert className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white font-mono uppercase tracking-wider flex items-center gap-2">
                    <span>Decommission Employee</span>
                  </h3>
                  <span className="text-[10px] font-mono font-bold text-red-400 tracking-wider">
                    ADMIN PRIVILEGE REQUIRED
                  </span>
                </div>
              </div>
              <button
                onClick={() => setUserToDelete(null)}
                className="text-gray-400 hover:text-white p-1.5 rounded-lg hover:bg-[#2d323b] transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Body */}
            <div className="p-5 space-y-4">
              <div className="bg-[#121417] p-4 rounded-xl border border-[#2d323b] space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-400 font-mono">Employee Record:</span>
                  <span className="text-xs font-mono font-bold text-[#FACC15] bg-[#2d323b] px-2 py-0.5 rounded border border-[#3d424d]">
                    {userToDelete.badgeId}
                  </span>
                </div>
                <div className="text-sm font-bold text-white font-sans">
                  {userToDelete.name}
                </div>
                <div className="text-xs text-gray-400 font-mono flex items-center gap-2">
                  <span>{userToDelete.email}</span>
                  <span>•</span>
                  <span className="text-gray-300">{ROLE_CONFIG[userToDelete.role]?.label || userToDelete.role}</span>
                </div>
                <div className="text-[11px] text-gray-500 font-mono">
                  {userToDelete.facility} — {userToDelete.line}
                </div>
              </div>

              <div className="p-3 bg-red-950/40 border border-red-800/80 rounded-lg text-xs font-mono text-red-200 flex items-start gap-2.5">
                <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                <p className="leading-relaxed text-[11px]">
                  <strong>Warning:</strong> Deleting an employee permanently revokes station login access, wipes credentials, and records an unalterable critical audit log event in the plant telemetry stream.
                </p>
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 border-t border-[#2d323b] bg-[#121417] flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setUserToDelete(null)}
                className="text-xs font-mono font-bold uppercase tracking-wider text-gray-400 hover:text-white px-4 py-2 rounded-lg border border-[#2d323b] bg-[#1a1d23] hover:bg-[#252a33] transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  onDeleteUser(userToDelete.id);
                  setUserToDelete(null);
                }}
                className="bg-red-600 hover:bg-red-500 text-white font-bold text-xs uppercase tracking-wider px-4 py-2 rounded-lg shadow-sm flex items-center gap-2 transition-all"
              >
                <Trash2 className="w-4 h-4" />
                <span>Confirm Permanent Deletion</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
