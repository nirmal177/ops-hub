import React, { useMemo } from "react";
import {
  Search,
  Filter,
  Bot,
  Network,
  Wrench,
  Forklift,
  CheckCircle2,
  Clock,
  Image as ImageIcon,
  AlertOctagon,
  Sparkles,
  SlidersHorizontal,
  X,
  Zap,
} from "lucide-react";
import { TroubleshootingEntry, EquipmentDomain, QuickFilterState } from "../types";
import { DOMAIN_CONFIG } from "../data/seedEntries";
import { EntryCard } from "./EntryCard";

interface SearchAndResolveViewProps {
  entries: TroubleshootingEntry[];
  filters: QuickFilterState;
  setFilters: React.Dispatch<React.SetStateAction<QuickFilterState>>;
  onSelectEntry: (entry: TroubleshootingEntry) => void;
  onToggleHelpful: (entryId: string, e: React.MouseEvent) => void;
  onOpenQuickCapture: () => void;
  onOpenCopilotWithQuery?: (query: string) => void;
}

const COMMON_QUICK_ERRORS = [
  "ERR-E301",
  "SLAM_LOST_04",
  "IP_CONFLICT_02",
  "CURTIS_FLT_55",
  "PROFINET_BF_RED",
  "SAFETY_LOOP_CH_B_DISCREPANCY",
  "HYD_PRES_LOW_09",
  "IO_LINK_PORT_ERR_08",
];

export const SearchAndResolveView: React.FC<SearchAndResolveViewProps> = ({
  entries,
  filters,
  setFilters,
  onSelectEntry,
  onToggleHelpful,
  onOpenQuickCapture,
  onOpenCopilotWithQuery,
}) => {
  // Domain Counts
  const domainCounts = useMemo(() => {
    const counts: Record<string, number> = { ALL: entries.length, AMR: 0, NETWORKING: 0, COMMISSIONING: 0, FORKLIFT: 0 };
    entries.forEach((e) => {
      if (counts[e.domain] !== undefined) {
        counts[e.domain] += 1;
      }
    });
    return counts;
  }, [entries]);

  // Filtered Entries
  const filteredEntries = useMemo(() => {
    return entries
      .filter((item) => {
        // Domain filter
        if (filters.selectedDomain !== "ALL" && item.domain !== filters.selectedDomain) {
          return false;
        }

        // Severity filter
        if (filters.selectedSeverity !== "ALL" && item.severity !== filters.selectedSeverity) {
          return false;
        }

        // Verified filter
        if (filters.verifiedOnly && !item.verified) {
          return false;
        }

        // Has images filter
        if (filters.hasImagesOnly && (!item.images || item.images.length === 0)) {
          return false;
        }

        // Quick fix filter (< 15 mins)
        if (filters.quickFixOnly && item.estimatedFixTimeMinutes > 15) {
          return false;
        }

        // Search query matching (title, errorCode, equipmentId, symptoms, rootCause, tags, subsystem)
        if (filters.searchQuery.trim()) {
          const q = filters.searchQuery.toLowerCase().trim();
          const matchCode = item.errorCode.toLowerCase().includes(q);
          const matchTitle = item.title.toLowerCase().includes(q);
          const matchEquip = item.equipmentId.toLowerCase().includes(q) || item.equipmentModel.toLowerCase().includes(q);
          const matchSubsystem = item.subsystem.toLowerCase().includes(q);
          const matchRoot = item.rootCause.toLowerCase().includes(q);
          const matchSymptoms = item.symptoms.some((s) => s.toLowerCase().includes(q));
          const matchTags = item.tags.some((t) => t.toLowerCase().includes(q));

          return matchCode || matchTitle || matchEquip || matchSubsystem || matchRoot || matchSymptoms || matchTags;
        }

        return true;
      })
      .sort((a, b) => {
        if (filters.sortBy === "none") {
          return 0;
        }
        if (filters.sortBy === "helpful") {
          return b.helpfulCount - a.helpfulCount;
        }
        if (filters.sortBy === "fastest") {
          return a.estimatedFixTimeMinutes - b.estimatedFixTimeMinutes;
        }
        // default newest
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      });
  }, [entries, filters]);

  const handleDomainTabClick = (d: EquipmentDomain | "ALL") => {
    setFilters((prev) => ({ ...prev, selectedDomain: d }));
  };

  const handleErrorCodeChipClick = (code: string) => {
    setFilters((prev) => ({
      ...prev,
      searchQuery: prev.searchQuery === code ? "" : code,
    }));
  };

  return (
    <div className="space-y-4">
      {/* Search Input Bar */}
      <div className="bg-[#1a1d23] rounded-xl p-4 sm:p-5 border border-[#2d323b] shadow-sm space-y-4">
        <div className="relative">
          <Search className="w-5 h-5 text-gray-500 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={filters.searchQuery}
            onChange={(e) => setFilters((prev) => ({ ...prev, searchQuery: e.target.value }))}
            placeholder="Search error codes (e.g. ERR-E301), Equipment (e.g. AMR-08), symptoms, or keywords..."
            className="w-full pl-11 pr-10 py-3 bg-[#121417] border border-[#3d424d] rounded-lg text-sm font-medium text-white placeholder:text-gray-500 focus:bg-[#121417] focus:border-[#FACC15] focus:ring-1 focus:ring-[#FACC15] focus:outline-none transition-all shadow-inner"
            id="input-kb-search"
          />
          {filters.searchQuery && (
            <button
              onClick={() => setFilters((prev) => ({ ...prev, searchQuery: "" }))}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white p-1"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Quick Error Code Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1">
          <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider shrink-0 mr-1 flex items-center gap-1 font-mono">
            <Zap className="w-3.5 h-3.5 text-[#FACC15]" />
            Quick Codes:
          </span>
          {COMMON_QUICK_ERRORS.map((code) => {
            const isSelected = filters.searchQuery === code;
            return (
              <button
                key={code}
                onClick={() => handleErrorCodeChipClick(code)}
                className={`font-mono text-xs font-bold px-2.5 py-1 rounded border transition-all shrink-0 ${
                  isSelected
                    ? "bg-[#FACC15] text-[#121417] border-[#FACC15] shadow-sm"
                    : "bg-[#121417] hover:bg-[#252a33] text-gray-300 border-[#2d323b] hover:border-gray-500"
                }`}
              >
                {code}
              </button>
            );
          })}
        </div>

        {/* Domain Navigation Tabs */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 pt-2 border-t border-[#2d323b]">
          <button
            onClick={() => handleDomainTabClick("ALL")}
            className={`p-2.5 rounded-lg border text-left transition-all flex items-center justify-between ${
              filters.selectedDomain === "ALL"
                ? "bg-[#2d323b] text-white border-[#FACC15] shadow-sm"
                : "bg-[#121417] hover:bg-[#1e2229] text-gray-300 border-[#2d323b] hover:border-gray-500"
            }`}
          >
            <span className="text-xs font-bold">All Domains</span>
            <span className={`text-[11px] font-mono px-1.5 py-0.2 rounded ${
              filters.selectedDomain === "ALL" ? "bg-[#121417] text-[#FACC15] border border-[#3d424d]" : "bg-[#1a1d23] text-gray-400 border border-[#2d323b]"
            }`}>
              {domainCounts.ALL}
            </span>
          </button>

          {(["AMR", "NETWORKING", "COMMISSIONING", "FORKLIFT"] as EquipmentDomain[]).map((d) => {
            const isSelected = filters.selectedDomain === d;
            const meta = DOMAIN_CONFIG[d];
            return (
              <button
                key={d}
                onClick={() => handleDomainTabClick(d)}
                className={`p-2.5 rounded-lg border text-left transition-all flex items-center justify-between ${
                  isSelected
                    ? "bg-[#2d323b] text-white border-[#FACC15] shadow-sm"
                    : "bg-[#121417] hover:bg-[#1e2229] text-gray-300 border-[#2d323b] hover:border-gray-500"
                }`}
              >
                <div className="flex items-center gap-1.5 truncate">
                  <span className={`w-2 h-2 rounded-full ${isSelected ? "bg-[#FACC15]" : "bg-gray-500"}`} />
                  <span className="text-xs font-bold truncate">{meta.shortCode}</span>
                </div>
                <span className={`text-[11px] font-mono px-1.5 py-0.2 rounded shrink-0 ${
                  isSelected ? "bg-[#121417] text-[#FACC15] border border-[#3d424d]" : "bg-[#1a1d23] text-gray-400 border border-[#2d323b]"
                }`}>
                  {domainCounts[d] || 0}
                </span>
              </button>
            );
          })}
        </div>

        {/* Secondary Filter Pills */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-[#2d323b] text-xs">
          <div className="flex flex-wrap items-center gap-1.5">
            {/* Verified Only Toggle */}
            <button
              onClick={() => setFilters((prev) => ({ ...prev, verifiedOnly: !prev.verifiedOnly }))}
              className={`px-3 py-1 rounded border font-medium transition-colors flex items-center gap-1.5 text-xs ${
                filters.verifiedOnly
                  ? "bg-green-950/60 text-green-400 border-green-700 font-bold"
                  : "bg-[#121417] text-gray-400 border-[#2d323b] hover:border-gray-500 hover:text-gray-200"
              }`}
            >
              <CheckCircle2 className={`w-3.5 h-3.5 ${filters.verifiedOnly ? "text-green-400" : "text-gray-500"}`} />
              <span>Verified Only</span>
            </button>

            {/* Quick Fix <15m */}
            <button
              onClick={() => setFilters((prev) => ({ ...prev, quickFixOnly: !prev.quickFixOnly }))}
              className={`px-3 py-1 rounded border font-medium transition-colors flex items-center gap-1.5 text-xs ${
                filters.quickFixOnly
                  ? "bg-yellow-950/50 text-[#FACC15] border-yellow-700 font-bold"
                  : "bg-[#121417] text-gray-400 border-[#2d323b] hover:border-gray-500 hover:text-gray-200"
              }`}
            >
              <Clock className={`w-3.5 h-3.5 ${filters.quickFixOnly ? "text-[#FACC15]" : "text-gray-500"}`} />
              <span>&lt;15m Quick Fix</span>
            </button>

            {/* Has Photos */}
            <button
              onClick={() => setFilters((prev) => ({ ...prev, hasImagesOnly: !prev.hasImagesOnly }))}
              className={`px-3 py-1 rounded border font-medium transition-colors flex items-center gap-1.5 text-xs ${
                filters.hasImagesOnly
                  ? "bg-blue-950/60 text-blue-400 border-blue-700 font-bold"
                  : "bg-[#121417] text-gray-400 border-[#2d323b] hover:border-gray-500 hover:text-gray-200"
              }`}
            >
              <ImageIcon className={`w-3.5 h-3.5 ${filters.hasImagesOnly ? "text-blue-400" : "text-gray-500"}`} />
              <span>With Photos</span>
            </button>
          </div>

          {/* Sort By Dropdown */}
          <div className="flex items-center gap-1.5 text-gray-400 font-mono text-xs">
            <SlidersHorizontal className="w-3.5 h-3.5 text-gray-500" />
            <span className="uppercase text-[11px]">Sort:</span>
            <select
              value={filters.sortBy}
              onChange={(e) => setFilters((prev) => ({ ...prev, sortBy: e.target.value as any }))}
              className="bg-[#121417] border border-[#3d424d] rounded px-2.5 py-1 font-medium text-gray-200 text-xs focus:border-[#FACC15] focus:outline-none"
            >
              <option value="none">None (Default)</option>
              <option value="newest">Newest First</option>
              <option value="helpful">Most Helpful Votes</option>
              <option value="fastest">Fastest Resolution</option>
            </select>
          </div>
        </div>
      </div>

      {/* Results Header */}
      <div className="flex items-center justify-between px-1">
        <span className="text-xs font-bold text-gray-400 uppercase tracking-wider font-mono">
          Found {filteredEntries.length} Proven Solution{filteredEntries.length === 1 ? "" : "s"}
        </span>

        {filters.searchQuery && (
          <span className="text-xs text-gray-400 font-mono">
            Filtered by <strong className="text-[#FACC15]">"{filters.searchQuery}"</strong>
          </span>
        )}
      </div>

      {/* Entries List / Grid */}
      {filteredEntries.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredEntries.map((entry) => (
            <EntryCard
              key={entry.id}
              entry={entry}
              onSelect={onSelectEntry}
              onToggleHelpful={onToggleHelpful}
            />
          ))}
        </div>
      ) : (
        /* Empty State */
        <div className="bg-[#1a1d23] rounded-xl p-8 border border-[#2d323b] text-center space-y-4 shadow-sm">
          <div className="w-12 h-12 rounded-lg bg-[#121417] text-[#FACC15] border border-[#3d424d] flex items-center justify-center mx-auto">
            <Search className="w-6 h-6" />
          </div>

          <div>
            <h3 className="text-base font-bold text-white">
              No matching error resolution found
            </h3>
            <p className="text-xs sm:text-sm text-gray-400 max-w-md mx-auto mt-1">
              We couldn't find an existing SOP matching "{filters.searchQuery || filters.selectedDomain}". You can ask the AI Field Copilot for an instant diagnostic tree or capture a new resolution in &lt;30s.
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            {onOpenCopilotWithQuery && filters.searchQuery && (
              <button
                onClick={() => onOpenCopilotWithQuery(filters.searchQuery)}
                className="bg-blue-600 hover:bg-blue-500 active:bg-blue-700 text-white text-xs font-bold uppercase tracking-wider px-4 py-2 rounded-lg flex items-center gap-1.5 transition-colors shadow-sm"
              >
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>Ask AI Copilot for "{filters.searchQuery}"</span>
              </button>
            )}

            <button
              onClick={onOpenQuickCapture}
              className="bg-[#FACC15] hover:bg-yellow-300 active:bg-yellow-500 text-[#121417] text-xs font-bold uppercase tracking-wider px-4 py-2 rounded-lg flex items-center gap-1.5 transition-colors shadow-sm"
            >
              <span>+ Capture First Fix for this Code</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
