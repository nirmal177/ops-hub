import React, { useState, useEffect } from "react";
import { Header } from "./components/Header";
import { OfflineSyncBanner } from "./components/OfflineSyncBanner";
import { SearchAndResolveView } from "./components/SearchAndResolveView";
import { EntryDetailModal } from "./components/EntryDetailModal";
import { QuickCaptureModal } from "./components/QuickCaptureModal";
import { AIDiagnosticAssistant } from "./components/AIDiagnosticAssistant";
import { GETTrainingHub } from "./components/GETTrainingHub";
import { AnalyticsOverview } from "./components/AnalyticsOverview";
import { AdminConsole } from "./components/AdminConsole";
import { UserSwitcherModal } from "./components/UserSwitcherModal";
import { UserEditModal } from "./components/UserEditModal";
import { AuthPage } from "./components/AuthPage";
import { StorageService } from "./utils/storage";
import {
  TroubleshootingEntry,
  QuickFilterState,
  EquipmentDomain,
  ShiftInfo,
  User,
  AuditLog,
} from "./types";
import { Sparkles, CheckCircle2, ShieldCheck } from "lucide-react";

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() =>
    StorageService.isAuthenticated()
  );
  const [entries, setEntries] = useState<TroubleshootingEntry[]>(() =>
    StorageService.getEntries()
  );
  const [users, setUsers] = useState<User[]>(() =>
    StorageService.getUsers()
  );
  const [currentUser, setCurrentUser] = useState<User>(() =>
    StorageService.getCurrentUser()
  );
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(() =>
    StorageService.getAuditLogs()
  );

  const [isOnline, setIsOnline] = useState<boolean>(() =>
    StorageService.isOnline()
  );
  const [pendingSyncCount, setPendingSyncCount] = useState<number>(
    () => StorageService.getSyncQueue().length
  );
  const [isSyncing, setIsSyncing] = useState(false);
  const [isSimulatedOffline, setIsSimulatedOffline] = useState(false);

  const [activeTab, setActiveTab] = useState<
    "search" | "capture" | "copilot" | "training" | "analytics" | "admin"
  >("search");
  const [selectedEntry, setSelectedEntry] =
    useState<TroubleshootingEntry | null>(null);
  const [isQuickCaptureOpen, setIsQuickCaptureOpen] = useState(false);

  // User management modals
  const [isUserSwitcherOpen, setIsUserSwitcherOpen] = useState(false);
  const [isUserEditOpen, setIsUserEditOpen] = useState(false);
  const [userToEdit, setUserToEdit] = useState<User | null>(null);

  const [copilotQuery, setCopilotQuery] = useState<string>("");
  const [copilotEntryContext, setCopilotEntryContext] =
    useState<TroubleshootingEntry | null>(null);

  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const [filters, setFilters] = useState<QuickFilterState>({
    searchQuery: "",
    selectedDomain: "ALL",
    selectedSeverity: "ALL",
    verifiedOnly: false,
    hasImagesOnly: false,
    quickFixOnly: false,
    sortBy: "newest",
  });

  const shiftInfo: ShiftInfo = {
    shiftName: currentUser.shift,
    facility: currentUser.facility,
    line: currentUser.line,
    userName: currentUser.name,
    userRole: currentUser.role,
  };

  // Storage and Network event sync
  useEffect(() => {
    const handleUpdate = () => {
      setEntries(StorageService.getEntries());
      setUsers(StorageService.getUsers());
      setCurrentUser(StorageService.getCurrentUser());
      setAuditLogs(StorageService.getAuditLogs());
      setIsOnline(StorageService.isOnline());
      setIsAuthenticated(StorageService.isAuthenticated());
      setPendingSyncCount(StorageService.getSyncQueue().length);
    };

    const unsubscribe = StorageService.subscribe(handleUpdate);

    const handleOnline = () => {
      StorageService.setOfflineOverride(null);
      setIsSimulatedOffline(false);
      handleUpdate();
    };

    const handleOffline = () => {
      handleUpdate();
    };

    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);

    return () => {
      unsubscribe();
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, []);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleLoginSuccess = (user: User) => {
    setCurrentUser(user);
    setIsAuthenticated(true);
    showToast(`Logged in as ${user.name} (${user.badgeId})`);
  };

  const handleLogout = () => {
    StorageService.logout();
    setIsAuthenticated(false);
    showToast("Session closed. Workstation locked.");
  };

  const handleManualSync = async () => {
    setIsSyncing(true);
    const res = await StorageService.syncPendingEntries();
    setIsSyncing(false);
    showToast(`Successfully synced ${res.syncedCount} resolution(s)!`);
  };

  const handleToggleOfflineSimulation = (forcedOffline: boolean | null) => {
    StorageService.setOfflineOverride(forcedOffline);
    setIsSimulatedOffline(Boolean(forcedOffline));
    setIsOnline(StorageService.isOnline());
    showToast(
      forcedOffline
        ? "Simulating offline deadzone (offline cache engaged)"
        : "Live Wi-Fi connection restored"
    );
  };

  const handleSelectUser = (user: User) => {
    StorageService.setCurrentUser(user.id);
    setCurrentUser(user);
    showToast(`Active operator switched to ${user.name} (${user.role})`);
  };

  const handleCreateNewUser = () => {
    setUserToEdit(null);
    setIsUserEditOpen(true);
  };

  const handleEditUser = (user: User) => {
    setUserToEdit(user);
    setIsUserEditOpen(true);
  };

  const handleSaveUser = (userData: any) => {
    if (userToEdit) {
      StorageService.updateUser(userToEdit.id, userData);
      showToast(`User ${userData.name} profile updated.`);
    } else {
      StorageService.createUser({
        name: userData.name,
        email: userData.email || `${userData.badgeId?.toLowerCase() || "tech"}@diagnostics.internal`,
        badgeId: userData.badgeId,
        role: userData.role || "GET_TRAINEE",
        status: userData.status || "ACTIVE",
        department: userData.department || "Operations & Maintenance",
        shift: userData.shift || "Morning (06:00-14:00)",
        facility: userData.facility || "GIGA-FACTORY-01",
        line: userData.line || "Line 4 (AMR & Logistics)",
        specialties: userData.specialties || ["AMR"],
        phone: userData.phone,
        avatarColor: userData.avatarColor || "#FACC15",
      });
      showToast(`New staff member ${userData.name} registered.`);
    }
  };

  const handleToggleUserStatus = (userId: string) => {
    StorageService.toggleUserStatus(userId);
    showToast("User status updated.");
  };

  const handleDeleteUser = (userId: string) => {
    if (currentUser.role !== "ADMIN") {
      showToast("Access Denied: Only administrators have permission to delete employee accounts.");
      return;
    }

    const res = StorageService.deleteUser(userId, currentUser);
    if (res.success) {
      showToast("Employee account permanently decommissioned and deleted.");
    } else {
      showToast(res.error || "Failed to delete employee account.");
    }
  };

  const handleVerifyEntry = (entryId: string) => {
    StorageService.verifyEntry(entryId);
    showToast("SOP marked as Verified Solution with Supervisor stamp.");
  };

  const handleUnverifyEntry = (entryId: string) => {
    StorageService.unverifyEntry(entryId);
    showToast("Verification revoked. SOP returned to Draft.");
  };

  const handleDeleteEntry = (entryId: string) => {
    StorageService.deleteEntry(entryId);
    showToast("SOP deleted from knowledge base.");
  };

  const handleResetFactorySeed = () => {
    StorageService.resetToFactorySeed();
    showToast("All diagnostic data reset to initial engineering baseline.");
  };

  const handleToggleHelpful = (entryId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const res = StorageService.toggleHelpful(entryId);
    showToast(
      res.userVotedHelpful
        ? "+1 Confirmed: Works on my machine!"
        : "Vote removed."
    );
  };

  const handleAddComment = (
    entryId: string,
    comment: {
      author: string;
      role: string;
      text: string;
      workedForUser: boolean;
    }
  ) => {
    StorageService.addComment(entryId, comment);
    showToast("Shift feedback added to knowledge base.");
  };

  const handleQuickCaptureSubmit = (
    entryData: Omit<
      TroubleshootingEntry,
      | "id"
      | "createdAt"
      | "updatedAt"
      | "helpfulCount"
      | "comments"
      | "syncStatus"
    >
  ) => {
    const created = StorageService.addEntry(entryData);
    showToast(
      isOnline
        ? "Resolution published live to shared KB!"
        : "Saved to local offline cache! Will auto-sync."
    );
    setSelectedEntry(created);
  };

  const handleExportJSON = () => {
    const jsonStr = StorageService.exportFullSystemJSON();
    const blob = new Blob([jsonStr], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `operation-hub-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast("Complete knowledge base and user registry exported.");
  };

  const handleOpenCopilotWithQuery = (query: string) => {
    setCopilotQuery(query);
    setCopilotEntryContext(null);
    setActiveTab("copilot");
  };

  const handleOpenCopilotWithContext = (entry: TroubleshootingEntry) => {
    setCopilotEntryContext(entry);
    setCopilotQuery(entry.errorCode || entry.title);
    setActiveTab("copilot");
  };

  const handleSelectErrorCode = (code: string) => {
    setFilters((prev) => ({ ...prev, searchQuery: code, selectedDomain: "ALL" }));
    setActiveTab("search");
  };

  const handleSelectDomain = (domain: EquipmentDomain) => {
    setFilters((prev) => ({ ...prev, selectedDomain: domain, searchQuery: "" }));
    setActiveTab("search");
  };

  const verifiedCount = entries.filter((e) => e.verified).length;
  const unverifiedCount = entries.filter((e) => !e.verified).length;
  const verifiedRate =
    entries.length > 0 ? Math.round((verifiedCount / entries.length) * 100) : 0;

  if (!isAuthenticated) {
    return <AuthPage onLoginSuccess={handleLoginSuccess} />;
  }

  return (
    <div className="min-h-screen bg-[#121417] text-gray-200 flex flex-col font-sans selection:bg-[#FACC15] selection:text-[#121417]">
      {/* Header Bar */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isOnline={isOnline}
        pendingSyncCount={pendingSyncCount}
        onManualSync={handleManualSync}
        isSyncing={isSyncing}
        onOpenQuickCapture={() => setIsQuickCaptureOpen(true)}
        shiftInfo={shiftInfo}
        currentUser={currentUser}
        onOpenUserSwitcher={() => setIsUserSwitcherOpen(true)}
        totalEntriesCount={entries.length}
        verifiedRate={verifiedRate}
        unverifiedCount={unverifiedCount}
        onExport={handleExportJSON}
        onLogout={handleLogout}
      />

      {/* Offline & Sync Status Banner */}
      <OfflineSyncBanner
        isOnline={isOnline}
        pendingSyncCount={pendingSyncCount}
        onManualSync={handleManualSync}
        isSyncing={isSyncing}
        onToggleOfflineSimulation={handleToggleOfflineSimulation}
        isSimulatedOffline={isSimulatedOffline}
      />

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 bg-[#1a1d23] text-white text-xs sm:text-sm font-semibold px-4 py-3 rounded-xl shadow-xl border border-[#3d424d] flex items-center gap-2 animate-in slide-in-from-bottom-4 duration-200">
          <CheckCircle2 className="w-4 h-4 text-[#FACC15] shrink-0" />
          <span className="font-mono">{toastMessage}</span>
        </div>
      )}

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-5 sm:py-6">
        {activeTab === "search" && (
          <SearchAndResolveView
            entries={entries}
            filters={filters}
            setFilters={setFilters}
            onSelectEntry={setSelectedEntry}
            onToggleHelpful={handleToggleHelpful}
            onOpenQuickCapture={() => setIsQuickCaptureOpen(true)}
            onOpenCopilotWithQuery={handleOpenCopilotWithQuery}
          />
        )}

        {activeTab === "copilot" && (
          <AIDiagnosticAssistant
            initialQuery={copilotQuery}
            initialEntry={copilotEntryContext}
            onSaveToKB={handleQuickCaptureSubmit}
            shiftInfo={shiftInfo}
          />
        )}

        {activeTab === "training" && (
          <GETTrainingHub
            onOpenQuickCapture={() => setIsQuickCaptureOpen(true)}
            onFilterByDomain={handleSelectDomain}
          />
        )}

        {activeTab === "analytics" && (
          <AnalyticsOverview
            entries={entries}
            onSelectErrorCode={handleSelectErrorCode}
            onSelectDomain={handleSelectDomain}
          />
        )}

        {activeTab === "admin" && (
          <AdminConsole
            currentUser={currentUser}
            users={users}
            entries={entries}
            auditLogs={auditLogs}
            onSelectUser={handleSelectUser}
            onOpenAddUser={handleCreateNewUser}
            onOpenEditUser={handleEditUser}
            onToggleUserStatus={handleToggleUserStatus}
            onDeleteUser={handleDeleteUser}
            onVerifyEntry={handleVerifyEntry}
            onUnverifyEntry={handleUnverifyEntry}
            onDeleteEntry={handleDeleteEntry}
            onSelectEntry={(entry) => setSelectedEntry(entry)}
            onResetFactorySeed={handleResetFactorySeed}
            onExportSystem={handleExportJSON}
          />
        )}
      </main>

      {/* Entry Detail & Resolution Steps Checklist Modal */}
      <EntryDetailModal
        entry={selectedEntry}
        onClose={() => setSelectedEntry(null)}
        onToggleHelpful={handleToggleHelpful}
        onAddComment={handleAddComment}
        shiftInfo={shiftInfo}
        currentUser={currentUser}
        onVerifyEntry={handleVerifyEntry}
        onUnverifyEntry={handleUnverifyEntry}
        onDeleteEntry={handleDeleteEntry}
        onOpenAIWithContext={handleOpenCopilotWithContext}
      />

      {/* <30s Quick Capture Modal */}
      <QuickCaptureModal
        isOpen={isQuickCaptureOpen}
        onClose={() => setIsQuickCaptureOpen(false)}
        onSubmit={handleQuickCaptureSubmit}
        shiftInfo={shiftInfo}
        isOnline={isOnline}
      />

      {/* User Switcher Modal */}
      <UserSwitcherModal
        isOpen={isUserSwitcherOpen}
        onClose={() => setIsUserSwitcherOpen(false)}
        currentUser={currentUser}
        users={users}
        onSelectUser={handleSelectUser}
        onOpenAddUser={handleCreateNewUser}
        onOpenAdminConsole={() => {
          setIsUserSwitcherOpen(false);
          setActiveTab("admin");
        }}
        onLogout={handleLogout}
      />

      {/* User Create/Edit Modal */}
      <UserEditModal
        isOpen={isUserEditOpen}
        onClose={() => {
          setIsUserEditOpen(false);
          setUserToEdit(null);
        }}
        userToEdit={userToEdit}
        onSave={handleSaveUser}
      />

      {/* Operational Footer */}
      <footer className="bg-[#1a1d23] border-t border-[#2d323b] py-4 text-xs text-gray-400 text-center font-mono">
        <div className="max-w-7xl mx-auto px-4 flex flex-wrap items-center justify-between gap-2">
          <span>
            ShopFloor Ops Hub • Field Operations & GET Knowledge Network
          </span>
          <span className="text-gray-400">
            AMR • NETWORKING • COMMISSIONING • FORKLIFT
          </span>
        </div>
      </footer>
    </div>
  );
}

